#!/bin/bash
set -euo pipefail
cd /kaggle/working

echo "=== 1/3 Build llama.cpp (CUDA) ==="
cd llama.cpp && mkdir -p build && cd build
cmake .. -DBUILD_SHARED_LIBS=ON -DLLAMA_CUDA=ON -DLLAMA_CUDA_F16=ON \
    -DLLAMA_VULKAN=OFF -DLLAMA_METAL=OFF \
    -DLLAMA_BUILD_SERVER=OFF -DLLAMA_BUILD_TESTS=OFF \
    -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_TOOLS=OFF
make -j$(nproc) llama 2>&1 | tail -3
echo "OK"

echo "=== 2/3 Build Runner ==="
cd /kaggle/working
INCS="-I. -Irunner -Icollection -Icollection/src -Icollection/rdh \
      -Icollection/core/core -Icollection/geopixel \
      -Icollection/geo_jump_module/include \
      -Icollection/dgls/diamond/include \
      -Illama.cpp -Illama.cpp/ggml/include -Illama.cpp/src"
mkdir -p build

# geo_jump.c dependency
gcc -std=c11 -O2 $INCS -c collection/geo_jump_module/src/geo_jump.c -o build/geo_jump.o

# runner C
gcc -std=c11 -O2 $INCS -c runner/llama_pogls_runner_sid_v2.c -o build/runner.o

# runner C++
g++ -std=c++17 -O2 $INCS -c runner/kv_tensor_access.cpp -o build/kv_tensor_access.o

# link
g++ build/runner.o build/kv_tensor_access.o build/geo_jump.o \
    -Lllama.cpp/build/src -lllama \
    -Lllama.cpp/build/ggml/src -lggml -lggml-base -lggml-cpu \
    -lcuda -lcudart -lm -lpthread -ldl -lstdc++ \
    -Wl,-rpath,llama.cpp/build/src -Wl,-rpath,llama.cpp/build/ggml/src \
    -o build/pogls_runner
echo "OK ($(ls -lh build/pogls_runner | awk '{print $5}'))"

echo "=== 3/3 Inference ==="
echo ""
LD_LIBRARY_PATH="llama.cpp/build/src:llama.cpp/build/ggml/src" \
./build/pogls_runner ./model.framestore \
    --pogls-fs ./model.framestore \
    --sid-disable --ngl 99 \
    --prompt "Hello" --max-new 32 --temp 0 2>&1 | tail -20

echo "=== DONE ==="
