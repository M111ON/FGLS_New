/*
 * geo_o4_test.c — O4 Connector Test + Integration Demo
 * ══════════════════════════════════════════════════════
 * Tests:
 *   T1. tring_roundtrip_verify()        — addr space sanity
 *   T2. o4_roundtrip_verify()           — blob ↔ grid ↔ blob
 *   T3. geo_pixel uniqueness W=27       — O3 proof
 *   T4. full tile pipeline demo         — v18 blob → grid → decode
 *   T5. tring route distribution        — zone spread across image
 *
 * compile:
 *   gcc -O2 -o geo_o4_test geo_o4_test.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "geo_pixel.h"
#include "geo_tring_addr.h"
#include "geo_o4_connector.h"

/* ── simple test framework ──────────────────────────────────────── */
static int g_pass = 0, g_fail = 0;
#define CHECK(label, cond) do { \
    if (cond) { printf("  [PASS] %s\n", label); g_pass++; } \
    else       { printf("  [FAIL] %s\n", label); g_fail++; } \
} while(0)

/* ════════════════════════════════════════════════════════════════════
 * T1 — TRing address space
 * ════════════════════════════════════════════════════════════════════ */
static void test_tring(void) {
    printf("\n[T1] TRing address space\n");

    uint32_t errs = tring_roundtrip_verify();
    CHECK("tring all addrs in [0,6912)", errs == 0);

    /* spot check a few */
    TringAddr a = tring_encode(0, 0, 0);
    CHECK("(0,0,0) addr < 3456 (live zone)", a.addr < 3456);

    TringAddr b = tring_encode(0, 0, 2);
    CHECK("(0,0,2) addr >= 3456 (residual zone)", b.addr >= 3456);

    TringAddr c = tring_encode(3, 5, 1);
    CHECK("pattern_id < 144", c.pattern_id < 144);
    CHECK("zone in [0,2]", c.zone <= 2);

    printf("  sample (3,5,0): addr=%u pid=%u zone=%u\n",
           tring_encode(3,5,0).addr,
           tring_encode(3,5,0).pattern_id,
           tring_encode(3,5,0).zone);
}

/* ════════════════════════════════════════════════════════════════════
 * T2 — O4 roundtrip
 * ════════════════════════════════════════════════════════════════════ */
static void test_o4_roundtrip(void) {
    printf("\n[T2] O4 blob ↔ grid ↔ blob roundtrip\n");

    uint32_t errs = o4_roundtrip_verify();
    CHECK("256B blob roundtrip exact", errs == 0);

    /* test varying sizes */
    for (uint32_t sz = 1; sz <= 81; sz += 10) {
        uint8_t orig[128], rec[128];
        for (uint32_t i = 0; i < sz; i++) orig[i] = (uint8_t)(i * 11u % 256u);

        O4GridCtx ctx;
        o4_encode(orig, sz, 1, 2, &ctx);
        uint32_t nc = (sz + 2u) / 3u;
        o4_decode(&ctx, rec, nc, sz);

        int ok = (memcmp(orig, rec, sz) == 0);
        if (!ok) {
            printf("  [FAIL] sz=%u: first diff at byte ", sz);
            for (uint32_t i = 0; i < sz; i++)
                if (orig[i] != rec[i]) { printf("%u (exp %u got %u)\n", i, orig[i], rec[i]); break; }
            g_fail++;
        } else g_pass++;
    }
    printf("  roundtrip sizes 1..81: all checked\n");

    /* grid dimensions */
    uint8_t blob[300]; memset(blob, 0xAB, 300);
    O4GridCtx ctx; o4_encode(blob, 300, 0, 0, &ctx);
    uint32_t expected_h = (300/3 + 26) / 27;  /* ceil(100/27) = 4 */
    CHECK("grid_h = ceil(n_chunks/27)", ctx.grid_h == expected_h);
    printf("  300B blob → %u chunks → grid 27×%u\n",
           ctx.n_slots, ctx.grid_h);
}

/* ════════════════════════════════════════════════════════════════════
 * T3 — GeoPixel W=27 uniqueness (O3 proof)
 * ════════════════════════════════════════════════════════════════════ */
static void test_geo_pixel_o3(void) {
    printf("\n[T3] GeoPixel W=27 uniqueness (O3 proof)\n");

    /* roundtrip lossless fields */
    uint32_t rt_errs = geo_pixel_roundtrip_verify(27, 1);
    CHECK("W=27 roundtrip: trit/coset/fibo/letter4 lossless", rt_errs == 0);

    /* uniqueness: no two slots share (trit,coset,fibo) */
    uint32_t u_errs = geo_pixel_uniqueness_check(27);
    CHECK("W=27: no collision on (trit,coset,fibo)", u_errs == 0);

    /* show all 27 pixels */
    printf("  slot  trit spoke coset fibo   R    G    B\n");
    printf("  ────  ──── ───── ───── ────  ───  ───  ───\n");
    for (uint32_t i = 0; i < 27; i++) {
        GeoPixel  px = geo_pixel_encode(i, 27);
        GeoFields f  = geo_pixel_decode(px);
        printf("  %4u  %4u %5u %5u %4u  %3u  %3u  %3u\n",
               i, f.trit, f.spoke, f.coset, f.fibo,
               px.r, px.g, px.b);
    }
}

/* ════════════════════════════════════════════════════════════════════
 * T4 — full tile pipeline (simulated v18 blob)
 * ════════════════════════════════════════════════════════════════════ */
static void test_full_pipeline(void) {
    printf("\n[T4] Full tile pipeline demo\n");

    /* simulate a typical v18 GRAD9 tile blob: ~12-20 bytes */
    uint8_t fake_blob[] = {
        0x01,        /* ttype = GRADIENT */
        0x03,        /* bmode = BMODE_GRAD9 */
        0x42,        /* pid */
        /* Y ch: Y0=10, packed dx/dy */
        0x0A, 0x12, 0x34,
        /* Cg ch */
        0x02, 0x00, 0x01,
        /* Co ch */
        0xFF, 0x10, 0x20,
        /* raw stream flags */
        0x00
    };
    uint32_t blob_sz = (uint32_t)sizeof(fake_blob);

    /* encode to grid */
    O4GridCtx ctx;
    o4_encode(fake_blob, blob_sz, 2, 3, &ctx);
    printf("  blob_sz=%u → %u chunks → grid 27×%u\n",
           blob_sz, ctx.n_slots, ctx.grid_h);

    /* check tring route for this tile */
    TringAddr ta = o4_tile_route(2, 3, 0);
    printf("  tring route (2,3,ch=0): addr=%u zone=%u pid=%u\n",
           ta.addr, ta.zone, ta.pattern_id);

    /* get flat RGB buffer */
    uint8_t rgb_buf[27 * O4_MAX_GRID_H * 3];
    uint32_t rgb_sz = o4_grid_to_rgb(&ctx, rgb_buf, sizeof(rgb_buf));
    printf("  grid → RGB: %u bytes (%ux%u pixels)\n",
           rgb_sz, O4_GRID_W, ctx.grid_h);

    /* decode back */
    O4GridCtx ctx2;
    o4_rgb_to_grid(rgb_buf, ctx.grid_h, &ctx2);
    ctx2.n_slots = ctx.n_slots;

    uint8_t recovered[sizeof(fake_blob)];
    o4_decode(&ctx2, recovered, ctx.n_slots, blob_sz);

    int match = (memcmp(fake_blob, recovered, blob_sz) == 0);
    CHECK("full pipeline: blob → grid → RGB → grid → blob exact", match);

    if (!match) {
        printf("  orig:     ");
        for (uint32_t i=0;i<blob_sz;i++) printf("%02x ",fake_blob[i]);
        printf("\n  recovered:");
        for (uint32_t i=0;i<blob_sz;i++) printf("%02x ",recovered[i]);
        printf("\n");
    }
}

/* ════════════════════════════════════════════════════════════════════
 * T5 — TRing zone distribution across 8x8 tile grid (256px image)
 * ════════════════════════════════════════════════════════════════════ */
static void test_tring_distribution(void) {
    printf("\n[T5] TRing zone distribution (8×8 tile grid)\n");

    int zone_cnt[3] = {0};
    int addr_min = 9999, addr_max = 0;

    for (int ty = 0; ty < 8; ty++) {
        for (int tx = 0; tx < 8; tx++) {
            TringAddr a = tring_encode((uint8_t)tx, (uint8_t)ty, 0);
            zone_cnt[a.zone]++;
            if (a.addr < (uint32_t)addr_min) addr_min = a.addr;
            if (a.addr > (uint32_t)addr_max) addr_max = a.addr;
        }
    }

    printf("  64 tiles (ch=0): anchor=%d mid=%d residual=%d\n",
           zone_cnt[0], zone_cnt[1], zone_cnt[2]);
    printf("  addr range: %d..%d\n", addr_min, addr_max);
    CHECK("all 64 addrs in live zone [0,3456)", addr_max < 3456);

    /* show 8x8 zone map */
    printf("  zone map (0=anchor 1=mid 2=edge):\n  ");
    for (int ty = 0; ty < 8; ty++) {
        for (int tx = 0; tx < 8; tx++) {
            TringAddr a = tring_encode((uint8_t)tx, (uint8_t)ty, 0);
            printf("%u", a.zone);
        }
        printf("\n  ");
    }
    printf("\n");
}

/* ════════════════════════════════════════════════════════════════════
 * MAIN
 * ════════════════════════════════════════════════════════════════════ */
int main(void) {
    printf("GeoPixel O4 Connector Tests\n");
    printf("════════════════════════════\n");

    test_tring();
    test_o4_roundtrip();
    test_geo_pixel_o3();
    test_full_pipeline();
    test_tring_distribution();

    printf("\n════════════════════════════\n");
    printf("Results: %d PASS  %d FAIL\n", g_pass, g_fail);
    return (g_fail > 0) ? 1 : 0;
}
