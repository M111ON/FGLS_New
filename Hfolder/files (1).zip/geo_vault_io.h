/*
 * geo_vault_io.h — GeoVault File I/O Layer
 * ══════════════════════════════════════════
 * write folder → .geovault
 * read .geovault → extract files
 *
 * File layout:
 *   [64B]  GeoVaultHeader
 *   [N×32B] GeoVaultFileEntry  (n_files entries)
 *   [N×(path_len+1)] file paths  (null-terminated, sequential)
 *   [8B]   path_block_size (uint64 LE) — size of path block above
 *   [compressed_sz B] zstd(pixel buffer)
 *
 * No malloc in seek path. Full decompress only on bulk extract.
 * ══════════════════════════════════════════
 */

#ifndef GEO_VAULT_IO_H
#define GEO_VAULT_IO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <zstd.h>
#include "geo_vault.h"

#define GV_MAX_FILES     4096
#define GV_MAX_PATH       512
#define GV_ZSTD_LEVEL       3

/* ── Runtime vault context (in-memory after open) ─────────────────── */
typedef struct {
    GeoVaultHeader     hdr;
    GeoVaultFileEntry *entries;      /* malloc'd, hdr.n_files × 32B   */
    char             **paths;        /* malloc'd, hdr.n_files paths    */
    uint8_t           *frames;       /* decompressed pixel buffer      */
    uint64_t           frames_size;  /* n_frames × GV_FRAME_BYTES      */
    /* seek-only: offset of compressed block in file */
    uint64_t           compressed_offset;
    FILE              *fp;           /* kept open for partial reads    */
} GeoVaultCtx;

/* ════════════════════════════════════════════════════════════════════
 * WRITE: pack files into .geovault
 *
 * file_paths[i] = absolute or relative path to source file
 * rel_paths[i]  = path stored in vault (relative name)
 * n             = number of files
 * out_path      = output .geovault path
 *
 * Returns 0 on success, <0 on error
 * ════════════════════════════════════════════════════════════════════ */
int gv_write(const char **file_paths, const char **rel_paths,
             uint32_t n, const char *out_path) {

    if (n > GV_MAX_FILES) return -1;

    /* ── load all files ─────────────────────────────────────────── */
    uint8_t **bufs    = calloc(n, sizeof(uint8_t*));
    uint32_t *sizes   = calloc(n, sizeof(uint32_t));
    uint64_t  total_raw = 0;
    uint32_t  total_slots = 0;

    for (uint32_t i = 0; i < n; i++) {
        FILE *f = fopen(file_paths[i], "rb");
        if (!f) { fprintf(stderr, "gv_write: cannot open %s\n", file_paths[i]); return -2; }
        fseek(f, 0, SEEK_END); sizes[i] = (uint32_t)ftell(f); fseek(f, 0, SEEK_SET);
        bufs[i] = malloc(sizes[i] ? sizes[i] : 1);
        if (sizes[i]) fread(bufs[i], 1, sizes[i], f);
        fclose(f);
        total_raw   += sizes[i];
        total_slots += gv_slots_needed(sizes[i]);
    }

    uint32_t n_frames = (total_slots + GV_RESIDUAL - 1) / GV_RESIDUAL;
    if (n_frames == 0) n_frames = 1;

    /* ── allocate pixel buffer ──────────────────────────────────── */
    uint64_t frames_size = (uint64_t)n_frames * GV_FRAME_BYTES;
    uint8_t *frames = calloc(1, frames_size);

    /* ── build entries + fill pixel buffer ──────────────────────── */
    GeoVaultFileEntry *entries = calloc(n, sizeof(GeoVaultFileEntry));
    uint32_t global_slot = 0;

    /* SHA1 of all data */
    /* simple running XOR as folder fingerprint (full SHA1 optional) */
    uint8_t folder_sha[20] = {0};

    for (uint32_t fi = 0; fi < n; fi++) {
        uint32_t slots = gv_slots_needed(sizes[fi]);
        GeoVaultFileEntry *e = &entries[fi];
        e->name_hash   = gv_fnv1a(rel_paths[fi]);
        e->raw_size    = sizes[fi];
        e->slot_start  = global_slot % GV_RESIDUAL;
        e->slot_count  = slots;
        e->frame_start = global_slot / GV_RESIDUAL;

        /* 12-byte file fingerprint = first 12 bytes of FNV rolling hash */
        uint32_t h = gv_fnv1a(rel_paths[fi]);
        for (uint32_t b = 0; b < sizes[fi]; b++) {
            h ^= bufs[fi][b]; h *= 0x01000193u;
            if (b < 12) e->file_sha[b] = bufs[fi][b] ^ (uint8_t)b;
        }
        /* fold into folder sha */
        for (int b = 0; b < 20; b++) folder_sha[b] ^= (uint8_t)(h >> (b%4*8));

        /* pack chunks */
        for (uint32_t ci = 0; ci < slots; ci++) {
            uint32_t frame    = global_slot / GV_RESIDUAL;
            uint32_t slot_inf = global_slot % GV_RESIDUAL;
            uint8_t *fbuf     = frames + (uint64_t)frame * GV_FRAME_BYTES;
            uint32_t src_off  = ci * GV_CHUNK_BYTES;
            uint32_t remain   = sizes[fi] > src_off ? sizes[fi] - src_off : 0;
            gv_pack_chunk(bufs[fi] + src_off, remain, slot_inf, fbuf);
            global_slot++;
        }
    }

    /* ── compress pixel buffer ──────────────────────────────────── */
    size_t bound = ZSTD_compressBound(frames_size);
    uint8_t *cbuf = malloc(bound);
    size_t csz = ZSTD_compress(cbuf, bound, frames, frames_size, GV_ZSTD_LEVEL);

    /* ── build header ───────────────────────────────────────────── */
    GeoVaultHeader hdr;
    memset(&hdr, 0, sizeof(hdr));
    hdr.magic         = GV_MAGIC;
    hdr.version       = GV_VERSION;
    hdr.flags         = 0x0001;
    hdr.n_files       = n;
    hdr.n_frames      = n_frames;
    hdr.total_raw     = total_raw;
    hdr.compressed_sz = (uint64_t)csz;
    hdr.frame_bytes   = GV_FRAME_BYTES;
    memcpy(hdr.folder_sha, folder_sha, 20);

    /* ── write file ─────────────────────────────────────────────── */
    FILE *out = fopen(out_path, "wb");
    if (!out) { free(frames); free(cbuf); free(entries); return -3; }

    /* header */
    fwrite(&hdr, sizeof(hdr), 1, out);
    /* entries */
    fwrite(entries, sizeof(GeoVaultFileEntry), n, out);
    /* path block */
    uint64_t path_block_size = 0;
    for (uint32_t i = 0; i < n; i++) path_block_size += strlen(rel_paths[i]) + 1;
    fwrite(&path_block_size, 8, 1, out);
    for (uint32_t i = 0; i < n; i++)
        fwrite(rel_paths[i], 1, strlen(rel_paths[i]) + 1, out);
    /* compressed pixel buffer */
    fwrite(cbuf, 1, csz, out);
    fclose(out);

    /* ── report ─────────────────────────────────────────────────── */
    fprintf(stderr, "gv_write: %u files  raw=%llu  frames=%u  "
            "pixel_buf=%llu  compressed=%zu  ratio=%.2fx\n",
            n, (unsigned long long)total_raw, n_frames,
            (unsigned long long)frames_size, csz,
            (double)frames_size / csz);

    /* cleanup */
    for (uint32_t i = 0; i < n; i++) free(bufs[i]);
    free(bufs); free(sizes); free(frames); free(cbuf); free(entries);
    return 0;
}

/* ════════════════════════════════════════════════════════════════════
 * OPEN: load .geovault header + entries (no full decompress)
 * Returns ctx on success, NULL on error. Call gv_close() when done.
 * ════════════════════════════════════════════════════════════════════ */
GeoVaultCtx *gv_open(const char *path) {
    FILE *fp = fopen(path, "rb");
    if (!fp) return NULL;

    GeoVaultCtx *ctx = calloc(1, sizeof(GeoVaultCtx));
    ctx->fp = fp;

    /* header */
    if (fread(&ctx->hdr, sizeof(GeoVaultHeader), 1, fp) != 1) goto fail;
    if (ctx->hdr.magic != GV_MAGIC) goto fail;

    uint32_t n = ctx->hdr.n_files;

    /* entries */
    ctx->entries = malloc(n * sizeof(GeoVaultFileEntry));
    if (fread(ctx->entries, sizeof(GeoVaultFileEntry), n, fp) != n) goto fail;

    /* paths */
    ctx->paths = calloc(n, sizeof(char*));
    uint64_t path_block_size;
    if (fread(&path_block_size, 8, 1, fp) != 1) goto fail;
    char *path_block = malloc(path_block_size);
    if (fread(path_block, 1, path_block_size, fp) != path_block_size) goto fail;
    char *p = path_block;
    for (uint32_t i = 0; i < n; i++) {
        ctx->paths[i] = strdup(p);
        p += strlen(p) + 1;
    }
    free(path_block);

    /* record where compressed block starts (for partial reads later) */
    ctx->compressed_offset = (uint64_t)ftell(fp);
    ctx->frames = NULL;  /* not loaded yet */
    ctx->frames_size = (uint64_t)ctx->hdr.n_frames * GV_FRAME_BYTES;

    return ctx;
fail:
    fclose(fp); free(ctx->entries); free(ctx);
    return NULL;
}

/* ════════════════════════════════════════════════════════════════════
 * LOAD FRAMES: decompress pixel buffer into memory (needed for extract)
 * ════════════════════════════════════════════════════════════════════ */
int gv_load_frames(GeoVaultCtx *ctx) {
    if (ctx->frames) return 0;  /* already loaded */

    fseek(ctx->fp, (long)ctx->compressed_offset, SEEK_SET);
    uint8_t *cbuf = malloc(ctx->hdr.compressed_sz);
    if (fread(cbuf, 1, ctx->hdr.compressed_sz, ctx->fp) != ctx->hdr.compressed_sz) {
        free(cbuf); return -1;
    }

    ctx->frames = malloc(ctx->frames_size);
    size_t r = ZSTD_decompress(ctx->frames, ctx->frames_size,
                                cbuf, ctx->hdr.compressed_sz);
    free(cbuf);
    if (ZSTD_isError(r)) { free(ctx->frames); ctx->frames = NULL; return -2; }
    return 0;
}

/* ════════════════════════════════════════════════════════════════════
 * EXTRACT ONE FILE by index
 * Returns malloc'd buffer of raw_size bytes, NULL on error.
 * Caller must free().
 * ════════════════════════════════════════════════════════════════════ */
uint8_t *gv_extract(GeoVaultCtx *ctx, uint32_t file_idx) {
    if (file_idx >= ctx->hdr.n_files) return NULL;
    if (!ctx->frames && gv_load_frames(ctx) < 0) return NULL;

    GeoVaultFileEntry *e = &ctx->entries[file_idx];
    if (e->raw_size == 0) return calloc(1, 1);

    uint8_t *out = malloc(e->raw_size);
    uint32_t global_slot = e->frame_start * GV_RESIDUAL + e->slot_start;

    for (uint32_t ci = 0; ci < e->slot_count; ci++) {
        uint32_t frame    = global_slot / GV_RESIDUAL;
        uint32_t slot_inf = global_slot % GV_RESIDUAL;
        uint8_t *fbuf     = ctx->frames + (uint64_t)frame * GV_FRAME_BYTES;
        uint32_t dst_off  = ci * GV_CHUNK_BYTES;
        uint32_t remain   = e->raw_size > dst_off ? e->raw_size - dst_off : 0;
        gv_unpack_chunk(fbuf, slot_inf, out + dst_off, remain);
        global_slot++;
    }
    return out;
}

/* ════════════════════════════════════════════════════════════════════
 * FIND FILE by path (linear scan — n_files usually small)
 * Returns file index, or -1 if not found
 * ════════════════════════════════════════════════════════════════════ */
int gv_find(GeoVaultCtx *ctx, const char *rel_path) {
    uint32_t h = gv_fnv1a(rel_path);
    for (uint32_t i = 0; i < ctx->hdr.n_files; i++) {
        if (ctx->entries[i].name_hash == h &&
            strcmp(ctx->paths[i], rel_path) == 0)
            return (int)i;
    }
    return -1;
}

/* ════════════════════════════════════════════════════════════════════
 * LIST: print vault contents
 * ════════════════════════════════════════════════════════════════════ */
void gv_list(GeoVaultCtx *ctx) {
    printf("GeoVault v%u  files=%u  frames=%u  raw=%llu  compressed=%llu\n",
           ctx->hdr.version, ctx->hdr.n_files, ctx->hdr.n_frames,
           (unsigned long long)ctx->hdr.total_raw,
           (unsigned long long)ctx->hdr.compressed_sz);
    printf("  ratio=%.2fx\n",
           (double)((uint64_t)ctx->hdr.n_frames * GV_FRAME_BYTES)
           / ctx->hdr.compressed_sz);
    printf("  %-6s  %-8s  %-6s  %-5s  %-4s  %s\n",
           "idx", "size", "slot", "frame", "cmpd", "path");
    printf("  %-6s  %-8s  %-6s  %-5s  %-4s  %s\n",
           "---", "----", "----", "-----", "----", "----");
    for (uint32_t i = 0; i < ctx->hdr.n_files; i++) {
        GeoVaultFileEntry *e = &ctx->entries[i];
        GeoVaultAddr a = gv_addr(e->slot_start);
        printf("  %-6u  %-8u  %-6u  %-5u  %-4u  %s\n",
               i, e->raw_size, e->slot_start, e->frame_start,
               a.compound, ctx->paths[i]);
    }
}

/* ════════════════════════════════════════════════════════════════════
 * CLOSE
 * ════════════════════════════════════════════════════════════════════ */
void gv_close(GeoVaultCtx *ctx) {
    if (!ctx) return;
    if (ctx->fp)      fclose(ctx->fp);
    if (ctx->frames)  free(ctx->frames);
    if (ctx->entries) free(ctx->entries);
    if (ctx->paths) {
        for (uint32_t i = 0; i < ctx->hdr.n_files; i++) free(ctx->paths[i]);
        free(ctx->paths);
    }
    free(ctx);
}

#endif /* GEO_VAULT_IO_H */
