# SEAM 3 — TRing Walk Patch

## New files
- `geo_tring_walk.h` — stateless O(1) walk enc for tile dispatch ordering
  - `tring_walk_enc(i)`      → enc 0..719
  - `tring_walk_spoke(i)`    → spoke 0..5
  - `tring_walk_polarity(i)` → 0=ROUTE 1=GROUND
  - stride=37 (coprime to 720), spoke imbalance ≤7 for any NT

## Patched: geopixel_v20.c → geopixel_v21.c
3 sites — pixel coords stay raster, enc added for dispatch layer:
  - encode() O4 path     line ~1118: +tile_enc = tring_walk_enc(i)
  - decode_gpx4() recon  line ~1364: +tile_enc = tring_walk_enc(i)
  - decode_gpx()  recon  line ~1537: +tile_enc = tring_walk_enc(i)

tile_enc is (void)'d until integration with tgw_dispatch_v2.

## Test results
test_tring_walk.c: 6/6 PASS
  W01: enc in 0..719 ✓
  W02: spoke in 0..5 ✓
  W03: exact 120/spoke for NT=720 ✓
  W04: imbalance ≤7 for NT=64..1024 ✓
  W05: 50/50 polarity over 720 ✓
  W06: max same-spoke run < 6 ✓

## Next: test_cpu_pipeline.c (integration)
Wire: geopixel tile_enc → tgw_dispatch_v2 → spoke routing verify
