"""
Route all attention weights through bermuda pipeline (no block serialize — just routing).
"""
import sys, torch, time, gc, json, numpy as np
from pathlib import Path

COLLECTION = Path(__file__).resolve().parent
sys.path.insert(0, str(COLLECTION / 'python_src'))
sys.path.insert(0, str(COLLECTION))

from gguf import GGUFReader
from bermuda_router_v1 import DEVICE
from bermuda_pipeline import BermudaPipeline
from bermuda_reshape_v3 import BermudaGate

GGUF_PATH = r"I:\Vault\models\Qwen3-0.6B-Q8_0.gguf"
DIM = 128
BATCH = 32
t_start = time.time()

print("[0] Loading GGUF + gate...")
r = GGUFReader(GGUF_PATH)
gate = BermudaGate(DIM, code_dim=32, gear=2)
gate.load_state_dict(torch.load(COLLECTION / 'build' / 'bermuda_gate_g2_d128.pt',
                                 map_location='cpu', weights_only=True))
gate.to(DEVICE).eval()
pipe = BermudaPipeline(dim=DIM, gear=2)
pipe.router.gate = gate
for m in range(4):
    _ = pipe.process_float(torch.randn(BATCH, DIM, device=DEVICE), m)

# Select attention tensors
tensors = [t for t in r.tensors if t.name.endswith('.weight') and len(t.shape) >= 2 and ('attn_' in t.name or t.name == 'token_embd.weight')]
print(f"[1] {len(tensors)} attention tensors")

n_blocks_needed = (DIM + 31) // 32
results = {}
total_tok = 0
total_time = 0

for idx, t in enumerate(tensors):
    t0 = time.time()
    M, B = t.data.shape
    n_blocks = B // 34

    # Proper Q8_0 dequant: first n_blocks_needed blocks → DIM cols
    blk = t.data.reshape(M, n_blocks, 34)[:, :n_blocks_needed, :]
    i8 = blk[:, :, :32].astype(np.int8).astype(np.float32)
    scale_raw = blk[:, :, 32:34].tobytes()
    scales = np.frombuffer(scale_raw, dtype=np.float16).astype(np.float32).reshape(M, n_blocks_needed, 1)
    dequant = (i8 * scales).reshape(M, n_blocks_needed * 32)[:, :DIM]
    x = torch.from_numpy(dequant).float()
    n = x.shape[0]

    tensor_results = {}
    for mode in range(4):
        mode_name = ["ORBITAL", "CHIRAL", "CROSS", "HUB"][mode]
        total_entries = 0
        total_tokens = 0
        for bi in range(0, min(n, 4096), BATCH):  # cap at 4K rows per tensor
            batch = x[bi:bi+BATCH].to(DEVICE)
            if batch.shape[0] < 2:
                del batch; continue
            r = pipe.process_float(batch, mode)
            total_entries += r['n_real']
            total_tokens += r['verdict'].n_tokens
            del batch, r
        tensor_results[mode_name] = {'tokens': total_tokens, 'entries': total_entries}

    t1 = time.time()
    elapsed = t1 - t0
    actual_rows = min(n, 4096)
    total_tok += actual_rows
    total_time += elapsed
    results[t.name] = {
        'rows': actual_rows,
        'time_s': round(elapsed, 2),
        'tok_s': round(actual_rows / elapsed, 0),
        **{k: v for k, v in tensor_results.items()},
    }
    print(f"  [{idx+1}/{len(tensors)}] {t.name:40s} {actual_rows:>5,}×{DIM}  {elapsed:7.2f}s  {actual_rows/elapsed:>7,.0f} tok/s")

    del dequant, x, blk, i8, scales
    gc.collect()
    if DEVICE.type == 'cuda':
        torch.cuda.empty_cache()

total_s = time.time() - t_start
print(f"\n{'='*60}")
print(f"SUMMARY: {len(tensors)} tensors, {total_tok:,} rows processed (capped at 4K/tensor)")
print(f"Total time: {total_s:.1f}s ({total_s/60:.1f} min)")
avg_tok_s = total_tok / total_time if total_time > 0 else 0
print(f"Avg routing throughput: {avg_tok_s:,.0f} tok/s")

json_path = COLLECTION / 'build' / 'gguf_pipeline_results.json'
with open(json_path, 'w') as f:
    json.dump({
        'model': 'Qwen3-0.6B-Q8_0',
        'total_tensors': len(tensors),
        'total_rows': total_tok,
        'total_time_s': round(total_s, 2),
        'avg_tok_s': round(avg_tok_s, 0),
        'per_tensor': results,
    }, f, indent=2)
print(f"Saved {json_path}")
