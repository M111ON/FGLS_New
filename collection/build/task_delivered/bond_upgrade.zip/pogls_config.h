/*
 * pogls_config.h — minimal session config for pogls_bond.h
 */
#ifndef POGLS_CONFIG_H
#define POGLS_CONFIG_H

#include <stdint.h>

/* ── Verify mask: 32-bit → 1/4B false-positive rate ───────── */
#define POGLS_BOND_VERIFY_BITS    32
#define POGLS_BOND_VERIFY_MASK    UINT64_C(0x00000000FFFFFFFF)
#define POGLS_BOND_VERIFY_TARGET  UINT64_C(0x0000000090090009)

#define POGLS_BOND_VERSION_STR    "1.1.0"

/* ── Session nonce (global, set once at startup) ───────────── */
static uint64_t _pogls_nonce = 0;
static inline void     pogls_config_set_nonce(uint64_t n) { _pogls_nonce = n; }
static inline uint64_t pogls_config_get_nonce(void)       { return _pogls_nonce; }

#endif /* POGLS_CONFIG_H */
