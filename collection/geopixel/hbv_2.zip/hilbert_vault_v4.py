"""
hilbert_vault_v4.py — Folder → single SVG vault with timeline chunking
  - Small folder  : single flat vault (same as v3)
  - Large folder  : auto-chunked into <vault:timeline> inside same SVG
  - Chunk limit   : CHUNK_LIMIT_MB (default 5MB of compressed data per chunk)

usage:
  python hilbert_vault_v4.py encode <folder> [--chunk-mb N]
  python hilbert_vault_v4.py decode <folder.vault.svg> [output_dir]
  python hilbert_vault_v4.py verify <original_folder> <decoded_folder>
"""

import sys, os, hashlib, base64, zlib, re
from pathlib import Path

MAGIC            = 'HILBERT_VAULT_V4'
CHUNK_LIMIT_MB   = 5          # default chunk compressed size cap
CHUNK_LIMIT_BYTES = CHUNK_LIMIT_MB * 1024 * 1024


# ── helpers ──────────────────────────────────────────────────────────────────

def _compress(data: bytes):
    compressed = zlib.compress(data, level=9)
    return compressed, base64.b64encode(compressed).decode()

def _decompress(b64: str) -> bytes:
    return zlib.decompress(base64.b64decode(b64))

def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _file_node_lines(rel, orig_sz, comp_sz, sha, b64) -> list:
    return [
        f'    <vault:file name="{rel}" original_size="{orig_sz}" '
        f'compressed_size="{comp_sz}" sha256="{sha}">',
        f'      {b64}',
        f'    </vault:file>',
    ]


# ── encode ────────────────────────────────────────────────────────────────────

def encode(folderpath, chunk_limit=CHUNK_LIMIT_BYTES):
    folder = Path(folderpath)
    files  = sorted([f for f in folder.rglob('*') if f.is_file()])
    if not files:
        print('no files found'); return

    # build file records
    records = []
    total_orig = total_comp = 0
    for fpath in files:
        data = fpath.read_bytes()
        comp, b64 = _compress(data)
        sha = _sha(data)
        rel = str(fpath.relative_to(folder))
        total_orig += len(data)
        total_comp += len(comp)
        records.append((rel, len(data), len(comp), sha, b64))

    folder_sha = _sha(''.join(r[3] for r in records).encode())

    # decide: flat or timeline
    use_timeline = total_comp > chunk_limit

    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<svg xmlns="http://www.w3.org/2000/svg" xmlns:vault="urn:hilbert-vault" width="64" height="64">',
             '  <metadata>',
             f'    <vault:folder',
             f'      magic="{MAGIC}"',
             f'      name="{folder.name}"',
             f'      files="{len(records)}"',
             f'      original_size="{total_orig}"',
             f'      compressed_size="{total_comp}"',
             f'      sha256="{folder_sha}"',
             f'      chunked="{"true" if use_timeline else "false"}"',
             f'    />',
    ]

    if not use_timeline:
        # ── flat (v3 compatible) ──
        for rel, orig, comp, sha, b64 in records:
            lines += _file_node_lines(rel, orig, comp, sha, b64)
    else:
        # ── timeline chunking ──
        chunks = []
        cur_chunk = []
        cur_size  = 0
        for rec in records:
            comp_sz = rec[2]
            if cur_chunk and cur_size + comp_sz > chunk_limit:
                chunks.append(cur_chunk)
                cur_chunk = []
                cur_size  = 0
            cur_chunk.append(rec)
            cur_size += comp_sz
        if cur_chunk:
            chunks.append(cur_chunk)

        lines.append(f'    <vault:timeline chunks="{len(chunks)}" chunk_limit_bytes="{chunk_limit}">')
        for ci, chunk in enumerate(chunks):
            c_orig = sum(r[1] for r in chunk)
            c_comp = sum(r[2] for r in chunk)
            f0 = chunk[0][0]; fN = chunk[-1][0]
            lines.append(f'      <vault:chunk id="{ci}" files="{len(chunk)}" '
                         f'original_size="{c_orig}" compressed_size="{c_comp}" '
                         f'range_start="{f0}" range_end="{fN}">')
            for rel, orig, comp, sha, b64 in chunk:
                lines += ['  ' + l for l in _file_node_lines(rel, orig, comp, sha, b64)]
            lines.append(f'      </vault:chunk>')
        lines.append(f'    </vault:timeline>')

    lines += [
        '  </metadata>',
        '  <rect width="64" height="64" fill="#0a0a0a"/>',
        f'  <text x="32" y="28" text-anchor="middle" font-size="6" fill="#333">{folder.name}</text>',
        f'  <text x="32" y="38" text-anchor="middle" font-size="5" fill="#222">{len(records)} files</text>',
        f'  <text x="32" y="48" text-anchor="middle" font-size="4" fill="#1a1a1a">'
        f'{"timeline:" + str(len(chunks) if use_timeline else 0) + " chunks" if use_timeline else "flat"}</text>',
        '</svg>',
    ]

    out = str(folder) + '.vault.svg'
    Path(out).write_text('\n'.join(lines), encoding='utf-8')

    svg_sz = os.path.getsize(out)
    ratio  = svg_sz / total_orig if total_orig else 0
    mode   = f'timeline ({len(chunks)} chunks)' if use_timeline else 'flat'
    print(f'encoded  → {out}  [{mode}]')
    print(f'files={len(records)}  original={total_orig}B  compressed={total_comp}B  svg={svg_sz}B  ratio={ratio:.2f}x')
    print(f'folder_sha={folder_sha[:16]}...')


# ── decode ────────────────────────────────────────────────────────────────────

def decode(svgpath, outdir=None):
    content = Path(svgpath).read_text(encoding='utf-8')

    def get_attr(tag, attr):
        idx = content.index(f'{attr}="', content.index(tag)) + len(f'{attr}="')
        return content[idx:content.index('"', idx)]

    folder_name = get_attr('vault:folder', 'name')
    n_files     = int(get_attr('vault:folder', 'files'))
    chunked     = get_attr('vault:folder', 'chunked') == 'true'

    base = Path(outdir) if outdir else Path(svgpath).parent / (folder_name + '_decoded')
    base.mkdir(parents=True, exist_ok=True)

    # extract all vault:file regardless of flat/timeline nesting
    file_blocks = re.findall(r'<vault:file(.*?)>(.*?)</vault:file>', content, re.DOTALL)

    ok_count = 0
    for attrs_str, b64_raw in file_blocks:
        def ga(a):
            m = re.search(f'{a}="([^"]*)"', attrs_str)
            return m.group(1) if m else ''
        rel        = ga('name')
        sha_stored = ga('sha256')
        orig_size  = int(ga('original_size'))
        b64        = b64_raw.strip()

        data       = _decompress(b64)
        sha_actual = _sha(data)
        ok         = sha_actual == sha_stored and len(data) == orig_size

        outpath = base / rel
        outpath.parent.mkdir(parents=True, exist_ok=True)
        outpath.write_bytes(data)

        status = '✓' if ok else '✗'
        print(f'  {status} {rel}  ({len(data)}B)')
        if ok: ok_count += 1

    mode = f'timeline' if chunked else 'flat'
    print(f'\ndecoded [{mode}] → {base}')
    print(f'files={ok_count}/{n_files}  {"✓ ALL PASS" if ok_count == n_files else "✗ SOME FAILED"}')


# ── verify ────────────────────────────────────────────────────────────────────

def verify(orig_folder, decoded_folder):
    orig    = Path(orig_folder)
    decoded = Path(decoded_folder)
    files   = sorted([f for f in orig.rglob('*') if f.is_file()])

    ok = 0
    for f in files:
        rel = f.relative_to(orig)
        d   = decoded / rel
        if not d.exists():
            print(f'  ✗ MISSING {rel}'); continue
        match = _sha(f.read_bytes()) == _sha(d.read_bytes())
        print(f'  {"✓" if match else "✗"} {rel}')
        if match: ok += 1

    print(f'\nverify: {ok}/{len(files)} identical {"✓ ALL PASS" if ok == len(files) else "✗ MISMATCH"}')


# ── main ──────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''

    # parse optional --chunk-mb
    chunk_limit = CHUNK_LIMIT_BYTES
    if '--chunk-mb' in sys.argv:
        idx = sys.argv.index('--chunk-mb')
        chunk_limit = int(sys.argv[idx + 1]) * 1024 * 1024

    if cmd == 'encode' and len(sys.argv) > 2:
        encode(sys.argv[2], chunk_limit)
    elif cmd == 'decode' and len(sys.argv) > 2:
        decode(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
    elif cmd == 'verify' and len(sys.argv) > 3:
        verify(sys.argv[2], sys.argv[3])
    else:
        print('usage:')
        print('  python hilbert_vault_v4.py encode <folder> [--chunk-mb N]')
        print('  python hilbert_vault_v4.py decode <folder.vault.svg> [output_dir]')
        print('  python hilbert_vault_v4.py verify <original_folder> <decoded_folder>')
