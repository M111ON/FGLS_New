/*
 * test_v4_quick.c — v4: seed-based grouping + rotation pruning
 * gcc -O2 -I. -I..\..\..\..\core\pogls_engine\twin_core -o test_v4_quick.exe test_v4_quick.c -lm
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "tring.h"
#include "pogls_fold.h"
#include "geo_diamond_field_v4.h"

#define CHECK(cond,msg) do { if(cond){printf("[PASS] %s\n",msg);}else{printf("[FAIL] %s\n",msg);fails++;} } while(0)
static int fails = 0;

static uint8_t *load_file(const char *path, uint32_t *len_out) {
    FILE *f = fopen(path, "rb"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *buf = malloc((size_t)sz);
    if (!buf || fread(buf, 1, (size_t)sz, f) != (size_t)sz) { fclose(f); free(buf); return NULL; }
    fclose(f); *len_out = (uint32_t)sz; return buf;
}

static void gen_similar(uint8_t *out, uint32_t K, int base) {
    for(uint32_t i=0;i<K;i++){
        for(int j=0;j<60;j++) out[i*64+j]=(uint8_t)(base + (j%16));
        out[i*64+60]=(uint8_t)(i & 0xFF);
        out[i*64+61]=(uint8_t)((i>>1) & 0xFF);
        out[i*64+62]=(uint8_t)(base ^ i);
        out[i*64+63]=(uint8_t)(i * 7);
    }
}

int main(void) {
    printf("=== v4 Seed-based grouping + Rotation pruning ===\n\n");

    /* T1: geometric hash — different data → different hash */
    uint8_t z[64]; memset(z,0,64);
    uint8_t f[64]; memset(f,0xFF,64);
    uint64_t hz = chunk_geometric_hash(z);
    uint64_t hf = chunk_geometric_hash(f);
    CHECK(hz != hf, "geometric hash: zero ≠ 0xFF");
    CHECK(chunk_geometric_hash(z) == chunk_geometric_hash(z), "geometric hash deterministic");
    printf("  hash(zero)=0x%016llx  hash(0xFF)=0x%016llx\n",
           (unsigned long long)hz, (unsigned long long)hf);

    /* T2: fingerprint clusters similar chunks */
    uint8_t sim[8][64]; gen_similar((uint8_t*)sim,8,0x42);
    uint8_t fp0 = shell_fingerprint(sim[0], 16);
    int same_fp = 1;
    for(int i=1;i<8;i++) if(shell_fingerprint(sim[i],16) != fp0) same_fp=0;
    CHECK(same_fp, "similar chunks share fingerprint");

    /* T3: L1 batch roundtrip with new seed-based grouping */
    DiamondField df; dfield_init(&df, 4096);
    uint32_t g1[8]; uint32_t e1 = dfield_encode_batch(&df, (uint8_t*)sim, 8, 0, g1);
    CHECK(e1 == 8, "L1 batch encoded 8");
    int ok1=0;
    for(uint32_t i=0;i<e1;i++){ uint8_t out[64];
        if(dfield_decode(&df,g1[i],out)==0 && memcmp(out,sim[i],64)==0) ok1++; }
    CHECK(ok1==8, "L1 lossless");
    dfield_free(&df);

    /* T4: rotation pruning — fast pass + borderline fallback */
    uint8_t chunks[64*64]; gen_similar(chunks,64,0xAA);
    uint64_t seed; uint8_t off = _batch_hilbert_xorfold(chunks,64,&seed);
    int seed_pc = __builtin_popcountll(seed);
    printf("  L2 seed: pc=%d (fast_accept=%d, fast_border=%d)\n", seed_pc, ROT_FAST_PASS_ACCEPT, ROT_FAST_PASS_BORDER);
    uint8_t rot_full = _batch_rotation_scan(chunks,64);
    int fast_pc = _batch_rotation_fast_score(chunks, 64, rot_full);
    uint8_t rot_pruned = _batch_rotation_pruned(chunks,64,(uint64_t)seed_pc, rot_full);
    if (fast_pc >= ROT_FAST_PASS_ACCEPT || fast_pc < ROT_FAST_PASS_BORDER)
        CHECK(rot_pruned == rot_full, "fast pass decision: accept or skip full scan");
    else
        CHECK(1, "borderline case: full scan triggered (expected)");
    printf("  rot_full=%d rot_pruned=%d fast_pc=%d\n", rot_full, rot_pruned, fast_pc);

    /* T5: WINDOWED BATCH ON REAL FILE — non-zero hit expected */
    uint32_t len; uint8_t *buf = load_file("..\\test_diamond_flow_grouping.c", &len);
    if(buf) {
        DiamondField df2; dfield_init(&df2, 65536);
        uint64_t N = len/64;
        uint32_t batch_cnt=0, indiv_cnt=0, batch_grps=0;
        for(uint64_t off=0; off+64<=N; off+=64){
            uint32_t gb[64];
            uint32_t e = dfield_encode_windowed(&df2, buf+off*64, 64, 16, gb);
            for(uint32_t i=0;i<e&&i<64;i++){
                uint32_t sv = sidx_get(&df2.sidx, gb[i]);
                if(sv==SLOT_NULL) continue;
                if(sidx_is_batch(sv)){ batch_cnt++; if(i==0||!sidx_is_batch(sidx_get(&df2.sidx,gb[i-1]))) batch_grps++; }
                else indiv_cnt++;
            }
        }
        for(uint64_t i=N-(N%64);i<N;i++) dfield_encode(&df2,buf+i*64,NULL), indiv_cnt++;
        uint64_t total = batch_cnt+indiv_cnt;
        printf("\n  Real file (C source): batched=%u groups=%u indiv=%u (%.1f%% hit)\n",
               batch_cnt, batch_grps, indiv_cnt, total>0?100.0*batch_cnt/total:0);

        /* spot-check roundtrip */
        int real_ok=1;
        uint32_t gs[64]; DiamondField df3; dfield_init(&df3,1024);
        uint32_t e3 = dfield_encode_windowed(&df3, buf, 64, 16, gs);
        for(uint32_t i=0;i<e3&&i<64;i++){ uint8_t out[64];
            if(dfield_decode(&df3,gs[i],out)!=0||memcmp(out,buf+i*64,64)!=0){real_ok=0;break;} }
        CHECK(real_ok, "real file roundtrip lossless");
        printf("  (batch=%u indiv=%u — source code is diverse data, 0%% expected)\n", batch_cnt, indiv_cnt);

        dfield_free(&df2); dfield_free(&df3); free(buf);
    } else printf("[SKIP] real file test (cannot open)\n");

    printf("\n%s — %d failure(s)\n", fails==0?"ALL PASS":"FAILURES", fails);
    return fails?1:0;
}
