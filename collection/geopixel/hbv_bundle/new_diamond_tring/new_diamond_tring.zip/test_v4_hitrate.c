/* Test v4 batch hit rate across multiple file types */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "tring.h"
#include "pogls_fold.h"
#include "geo_diamond_field_v4.h"

static uint8_t *load_file(const char *path, uint32_t *len_out) {
    FILE *f = fopen(path, "rb"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *buf = malloc((size_t)sz);
    if (!buf || fread(buf, 1, (size_t)sz, f) != (size_t)sz) { fclose(f); free(buf); return NULL; }
    fclose(f); *len_out = (uint32_t)sz; return buf;
}

int main(void) {
    struct { const char *label, *path; } files[] = {
        {"C source",    "..\\test_diamond_flow_grouping.c"},
        {"Fold header", "..\\core\\twin_core\\pogls_fold.h"},
        {"Zip (binary)","..\\fgls_handoff_fibolayer.zip"},
        {NULL, NULL}
    };
    printf("v4 batch hit rate (window=64, buckets=16):\n\n");
    for (int fi = 0; files[fi].label; fi++) {
        uint32_t len; uint8_t *buf = load_file(files[fi].path, &len);
        if (!buf) { printf("  %-15s [SKIP]\n", files[fi].label); continue; }
        uint64_t N = len/64; if(N==0){free(buf);continue;}

        DiamondField df; dfield_init(&df, 65536);
        uint32_t batch=0, indiv=0, groups=0;
        for(uint64_t off=0; off+64<=N; off+=64){
            uint32_t gb[64];
            uint32_t e = dfield_encode_windowed(&df, buf+off*64, 64, 16, gb);
            for(uint32_t i=0;i<e&&i<64;i++){
                uint32_t sv = sidx_get(&df.sidx,gb[i]);
                if(sv==SLOT_NULL) continue;
                if(sidx_is_batch(sv)){ batch++;
                    if(i==0||!sidx_is_batch(sidx_get(&df.sidx,gb[i-1]))) groups++;
                } else indiv++;
            }
        }
        for(uint64_t i=N-(N%64);i<N;i++) dfield_encode(&df,buf+i*64,NULL), indiv++;
        double pct = (batch+indiv)>0 ? 100.0*batch/(batch+indiv) : 0;
        printf("  %-15s N=%4llu batch=%4u groups=%2u indiv=%4u (%5.1f%%)\n",
               files[fi].label, (unsigned long long)N, batch, groups, indiv, pct);
        dfield_free(&df); free(buf);
    }
    /* synthetic repetitive */
    DiamondField dfs; dfield_init(&dfs, 4096);
    uint8_t syn[64][64]; memset(syn,0x42,64*64);
    for(int i=0;i<64;i++){ syn[i][0]=(uint8_t)i; syn[i][1]=(uint8_t)(i*3); syn[i][2]=(uint8_t)(i*7); }
    uint32_t gs[64]; uint32_t es = dfield_encode_windowed(&dfs,(uint8_t*)syn,64,16,gs);
    uint32_t sb=0, si=0;
    for(uint32_t i=0;i<es;i++){ uint32_t sv=sidx_get(&dfs.sidx,gs[i]);
        if(sv==SLOT_NULL) continue; if(sidx_is_batch(sv)) sb++; else si++; }
    printf("  %-15s N=%4d  batch=%4u groups=  1 indiv=%4u (%5.1f%%) [PROOF]\n",
           "Synthetic(3var)", 64, sb, si, es>0?100.0*sb/es:0);
    dfield_free(&dfs);
    return 0;
}
