#pragma once
/*
 * tring.h — Tring stub (API-compatible with Po's local build)
 * Matches geo_diamond_field_v4.h: Tring type, tring_init/destroy/push/read
 */
#ifndef TRING_H
#define TRING_H
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define TRING_MAX_TICKS (1u << 20)

typedef struct {
    uint8_t  **slots;
    uint32_t  *sizes;
    uint32_t   cap;
    uint32_t   tick;
} Tring;

static inline int tring_init(Tring *t, uint32_t cap) {
    t->cap   = cap ? cap : TRING_MAX_TICKS;
    t->tick  = 0;
    t->slots = (uint8_t**)calloc(t->cap, sizeof(uint8_t*));
    t->sizes = (uint32_t*)calloc(t->cap, sizeof(uint32_t));
    return (t->slots && t->sizes) ? 0 : -1;
}

static inline void tring_destroy(Tring *t) {
    if (!t) return;
    for (uint32_t i = 0; i < t->cap; i++) free(t->slots[i]);
    free(t->slots); free(t->sizes);
    t->slots = NULL; t->sizes = NULL;
}

static inline uint32_t tring_push(Tring *t, const uint8_t *data, uint32_t sz) {
    uint32_t idx = t->tick % t->cap;
    free(t->slots[idx]);
    t->slots[idx] = (uint8_t*)malloc(sz);
    if (t->slots[idx]) { memcpy(t->slots[idx], data, sz); t->sizes[idx] = sz; }
    return t->tick++;
}

static inline const uint8_t *tring_read(const Tring *t, uint32_t tick, uint32_t *out_sz) {
    uint32_t idx = tick % t->cap;
    if (out_sz) *out_sz = t->sizes[idx];
    return t->slots[idx];
}
#endif /* TRING_H */

/* gc scan stub — returns 0 (no-op, safe for roundtrip test) */
typedef int (*tring_ref_fn)(uint32_t tick, void *ctx);
static inline int tring_gc_scan(Tring *t, tring_ref_fn fn, void *ctx) {
    (void)t; (void)fn; (void)ctx; return 0;
}
