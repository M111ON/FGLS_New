#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#include "/tmp/new_diamond_tring/tring.h"
#include "/tmp/core/pogls_fold.h"
#include "/tmp/geo_diamond_field_v4.h"

#define CHECK(cond,msg) do { \
    if(cond){printf("[PASS] %s\n",msg);}else{printf("[FAIL] %s\n",msg);fails++;} \
} while(0)

int fails = 0;

static void gen_similar_chunks(uint8_t *out, uint32_t K, int base_val) {
    /* all chunks share same base, differ only in last 4 bytes (≤ BATCH_MAX_DIFF=12) */
    for(uint32_t i=0;i<K;i++){
        for(int j=0;j<60;j++) out[i*64+j]=(uint8_t)(base_val + (j%16));
        /* last 4 bytes differ per chunk */
        out[i*64+60]=(uint8_t)(i & 0xFF);
        out[i*64+61]=(uint8_t)((i>>1) & 0xFF);
        out[i*64+62]=(uint8_t)(base_val ^ i);
        out[i*64+63]=(uint8_t)(i * 7);
    }
}

int main(void) {
    printf("╔══════════════════════════════════════════════════════╗\n");
    printf("║  geo_diamond_field v4: Hilbert XOR-fold + rotation   ║\n");
    printf("╚══════════════════════════════════════════════════════╝\n\n");

    /* T1: Hilbert XOR-fold produces non-zero seed */
    {
        uint8_t chunks[64*64];
        gen_similar_chunks(chunks, 64, 0x42);
        uint64_t seed = 0;
        uint8_t best_off = _batch_hilbert_xorfold(chunks, 64, &seed);
        int pc = __builtin_popcountll(seed);
        printf("Hilbert XOR-fold (L2, 64 chunks):\n");
        printf("  best_offset=%d  seed=%016llx  popcount=%d\n",
               best_off, (unsigned long long)seed, pc);
        CHECK(seed != 0, "hilbert_seed non-zero");
        CHECK(pc >= 1,   "hilbert_seed has structure bits");
    }

    /* T2: rotation scan returns valid rot */
    {
        uint8_t chunks[8*64];
        gen_similar_chunks(chunks, 8, 0x77);
        uint8_t rot = _batch_rotation_scan(chunks, 8);
        printf("\nRotation scan (L1, 8 chunks): best_rot=%d\n", rot);
        CHECK(rot < 6, "best_rot in valid range");
    }

    /* T3: encode_batch L1 roundtrip with new wire format */
    {
        DiamondField df; dfield_init(&df, 4096);
        uint8_t chunks[8*64];
        gen_similar_chunks(chunks, 8, 0x55);
        uint32_t gidxs[8];
        uint32_t enc = dfield_encode_batch(&df, chunks, 8, 0, gidxs);
        printf("\nEncode L1 batch (K=8): encoded=%u\n", enc);
        CHECK(enc == 8, "L1 encode all 8 chunks");

        /* decode each chunk and verify */
        int ok = 0;
        for(uint32_t i=0;i<enc;i++) {
            uint8_t out[64];
            int r = dfield_decode(&df, gidxs[i], out);
            if(r == 0 && memcmp(out, chunks+i*64, 64)==0) ok++;
        }
        printf("  decode roundtrip: %d/8 correct\n", ok);
        CHECK(ok == 8, "L1 lossless roundtrip");
        dfield_free(&df);
    }

    /* T4: encode_batch L2 roundtrip */
    {
        DiamondField df; dfield_init(&df, 8192);
        uint8_t chunks[64*64];
        gen_similar_chunks(chunks, 64, 0x33);
        uint32_t gidxs[64];
        uint32_t enc = dfield_encode_batch(&df, chunks, 64, 1, gidxs);
        printf("\nEncode L2 batch (K=64): encoded=%u\n", enc);
        CHECK(enc == 64, "L2 encode all 64 chunks");

        int ok = 0;
        for(uint32_t i=0;i<enc;i++) {
            uint8_t out[64]; int r = dfield_decode(&df, gidxs[i], out);
            if(r==0 && memcmp(out,chunks+i*64,64)==0) ok++;
        }
        printf("  decode roundtrip: %d/64 correct\n", ok);
        CHECK(ok == 64, "L2 lossless roundtrip");

        /* check wire has best_rot != 0 for at least some data */
        /* read back first batch tick */
        uint32_t sidx_val = df.sidx.tick[gidxs[0]];
        uint32_t tick = sidx_is_batch(sidx_val)
            ? sidx_batch_tick(sidx_val)
            : sidx_val;
        uint32_t sz;
        const uint8_t *wire = tring_read(&df.tring, tick, &sz);
        if(wire) {
            printf("  wire: layer=%d rot=%d count=%d flags=%d  seed=%016llx\n",
                   wire[0], wire[1], wire[2], wire[3],
                   (unsigned long long)(*(uint64_t*)(wire+4)));
        }
        dfield_free(&df);
    }

    /* T5: compare encode cost v3 vs v4 (L2) */
    {
        printf("\nCompression comparison (L2, 64 similar chunks):\n");
        uint8_t chunks[64*64];
        gen_similar_chunks(chunks, 64, 0xAA);
        /* v3 wire: 4 + 64 + K*avg_diff */
        /* v4 wire: 4 + 8 + 64 + K*avg_diff  (+8B seed) */
        /* but best_rot now real → may reduce diff size */
        uint32_t v3_est = 4 + 64 + 64*(8+2);   /* ~avg 2 diffs/chunk */
        uint32_t v4_est = 4 + 8 + 64 + 64*(8+2);
        printf("  v3 wire (est): %u B  → %.2f B/chunk\n",
               v3_est, (double)v3_est/64);
        printf("  v4 wire (est): %u B  → %.2f B/chunk  (+8B seed overhead)\n",
               v4_est, (double)v4_est/64);
        printf("  v4 adds: batch geometric seed (structure fingerprint)\n");
        printf("           real best_rot (not hardcoded 0)\n");
        CHECK(v4_est < 64*64, "v4 still better than raw");
    }

    printf("\n══ Results: %s (%d failures) ══\n",
           fails==0?"ALL PASS":"FAILED", fails);
    return fails;
}
