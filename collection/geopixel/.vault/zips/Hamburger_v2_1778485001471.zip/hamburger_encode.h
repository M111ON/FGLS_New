/*
 * hamburger_encode.h — H4: hamburger_encode() + H5: hamburger_decode()
 *
 * Single-call encode/decode for the Hamburger Architecture.
 * Wraps H1 (pipe dispatch) + H2 (invert recorder) + LUT build.
 *
 * Encode output = seed + invert chain (not raw pixels)
 * Decode input  = seed + invert chain → reconstruct original
 *
 * Tile classify comes directly from geopixel_v21_o25.c (TTYPE_FLAT/GRAD/EDGE/NOISE).
 * Codec per carrier is selected from pipe table — not hardcoded here.
 *
 * After encode: LUT is frozen → O(1) random access on decode side.
 *
 * Wire order:
 *   encode: input → classify → dispatch(H1) → process → invert_record(H2)
 *           → warm-up 1440 ticks → freeze → build LUT → write gpx5 file
 *   decode: read gpx5 → check LUT_FROZEN → tile_id → invert_ptr (O1)
 *           → reconstruct via carrier codec → output
 *
 * No float in hot path. No malloc inside tick loop.
 * Depends on: gpx5_container.h, hamburger_pipe.h
 */

#pragma once
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "gpx5_container.h"
#include "hamburger_pipe.h"
#include "hamburger_classify.h"

/* ── encode result ───────────────────────────────────── */
#define HB_OK              0
#define HB_ERR_ALLOC      -1
#define HB_ERR_IO         -2
#define HB_ERR_TILES      -3
#define HB_ERR_NO_LUT     -4
#define HB_ERR_CODEC      -5

/* max tiles this encoder handles (stack budget) */
#define HB_MAX_TILES       4096u
#define HB_TILE_SZ_MAX     4896u   /* = GPX5_BLOCK_SZ, one block per tile */

/* ══════════════════════════════════════════════════════
 * TILE INPUT — caller fills this before calling encode
 * ══════════════════════════════════════════════════════ */

/*
 * HbTileIn — one tile's input data.
 * data     : raw tile bytes (caller owns, must outlive encode call)
 * sz       : byte count (≤ HB_TILE_SZ_MAX)
 * tile_id  : index in grid
 * ttype    : GPX5_TTYPE_* — from classify (geopixel_v21 output)
 *            caller runs classify_tile() and passes result here
 *            encoder does not re-classify — trust the caller
 */
typedef struct {
    const uint8_t *data;
    uint32_t       sz;
    uint16_t       tile_id;
    uint8_t        ttype;
    uint8_t        _pad;
} HbTileIn;

/* ══════════════════════════════════════════════════════
 * ENCODE CONTEXT — lives on heap, one per encode session
 * ══════════════════════════════════════════════════════ */

typedef struct {
    /* config (set by caller before hb_encode_init) */
    uint32_t       global_seed;
    uint16_t       tw;             /* tile columns                        */
    uint16_t       th;             /* tile rows                           */
    Gpx5PipeEntry  pipes[3];       /* carrier config                      */
    uint8_t        use_2carrier;   /* 1 = attempt 2-carrier mode          */

    /* runtime (filled by hb_encode_run) */
    HbInvertRecorder rec;
    Gpx5LutEntry    *lut;          /* [n_tiles], allocated on freeze       */
    uint32_t         n_tiles;
    uint32_t         n_active;     /* non-zero invert entries              */
    uint8_t         *inv_stream;   /* serialised invert stream             */
    uint32_t         inv_stream_sz;
    uint8_t          frozen;
} HbEncodeCtx;

/* ── init ──────────────────────────────────────────── */

static inline void hb_encode_init(
        HbEncodeCtx *ctx,
        uint32_t global_seed,
        uint16_t tw, uint16_t th,
        const Gpx5PipeEntry pipes[3],
        uint8_t use_2carrier)
{
    memset(ctx, 0, sizeof(*ctx));
    ctx->global_seed  = global_seed;
    ctx->tw           = tw;
    ctx->th           = th;
    ctx->n_tiles      = (uint32_t)tw * th;
    ctx->use_2carrier = use_2carrier;
    memcpy(ctx->pipes, pipes, sizeof(ctx->pipes));
    hb_invert_init(&ctx->rec);
}

static inline void hb_encode_free(HbEncodeCtx *ctx) {
    free(ctx->lut);
    free(ctx->inv_stream);
    ctx->lut        = NULL;
    ctx->inv_stream = NULL;
}

/* ══════════════════════════════════════════════════════
 * CODEC DISPATCH — apply carrier codec to tile bytes
 *
 * "Process" in hamburger = run tile through its carrier codec.
 * For most codecs: state_before and state_after differ only if
 * tile content changed. The invert recorder picks this up passively.
 *
 * Each codec writes its output to out_buf, returns bytes written.
 * out_buf must be ≥ tile_sz + 8 bytes (small header overhead).
 *
 * Current codecs:
 *   NONE    : copy verbatim (passthrough)
 *   SEED    : if ttype==FLAT, store seed only (4B). Skip tile data.
 *   DELTA   : XOR vs seed-derived prediction. Store residual only.
 *   RICE3   : Rice(k=3) on delta values (count stream)
 *   HILBERT : walk/no-walk bit stream (1 bit per hilbert position)
 *   RAW     : copy verbatim (same as NONE, explicit fallback)
 *
 * FREQ and ZSTD19 are stubs here — H3 plugs in later, no structural change.
 * ══════════════════════════════════════════════════════ */

/* seed-derived prediction byte for position i in tile */
static inline uint8_t hb_predict(uint32_t seed_local, uint32_t i) {
    uint32_t s = seed_local ^ (i * 0x9e3779b9u);
    s ^= s >> 16; s *= 0x85ebca6bu; s ^= s >> 13;
    return (uint8_t)(s & 0xFFu);
}

/* Rice(k=3) encode one value into bit buffer — returns bits written */
static inline uint32_t hb_rice3_encode_val(uint32_t val, uint8_t *buf, uint32_t bit_pos) {
    uint32_t k    = 3u;
    uint32_t q    = val >> k;           /* quotient  */
    uint32_t r    = val & ((1u<<k)-1u); /* remainder */
    /* unary quotient: q ones then a zero */
    for (uint32_t i = 0; i <= q; i++) {
        uint32_t byte_i = bit_pos >> 3;
        uint32_t bit_i  = 7u - (bit_pos & 7u);
        if (i < q) buf[byte_i] |= (1u << bit_i);
        else       buf[byte_i] &= (uint8_t)~(1u << bit_i); /* stop bit = 0 */
        bit_pos++;
    }
    /* binary remainder: k bits MSB first */
    for (int b = (int)k - 1; b >= 0; b--) {
        uint32_t byte_i = bit_pos >> 3;
        uint32_t bit_i  = 7u - (bit_pos & 7u);
        if ((r >> (uint32_t)b) & 1u) buf[byte_i] |= (1u << bit_i);
        else                          buf[byte_i] &= (uint8_t)~(1u << bit_i);
        bit_pos++;
    }
    return bit_pos;
}

/*
 * hb_codec_apply — apply carrier codec to one tile.
 * Returns bytes written to out_buf, or 0 on error.
 * out_buf must be pre-zeroed if Rice/Hilbert is used (bit manipulation).
 */
static inline uint32_t hb_codec_apply(
        uint8_t codec,
        uint8_t ttype,
        const uint8_t *in,
        uint32_t in_sz,
        uint8_t *out,
        uint32_t out_cap,
        uint32_t seed_local)
{
    if (!in || !out || out_cap < 8u) return 0u;

    switch (codec) {

    case GPX5_CODEC_NONE:
    case GPX5_CODEC_RAW:
        if (in_sz > out_cap) return 0u;
        memcpy(out, in, in_sz);
        return in_sz;

    case GPX5_CODEC_SEED:
        /* FLAT tiles: store seed only — 4 bytes */
        if (ttype == GPX5_TTYPE_FLAT) {
            out[0] = (uint8_t)(seed_local >> 24);
            out[1] = (uint8_t)(seed_local >> 16);
            out[2] = (uint8_t)(seed_local >>  8);
            out[3] = (uint8_t)(seed_local);
            return 4u;
        }
        /* non-flat: fall through to delta */
        /* fall through */

    case GPX5_CODEC_DELTA: {
        /* XOR each byte vs seed-derived prediction, store residual */
        if (in_sz + 1u > out_cap) return 0u;
        out[0] = (uint8_t)(in_sz & 0xFFu);   /* length byte */
        for (uint32_t i = 0; i < in_sz; i++)
            out[1 + i] = in[i] ^ hb_predict(seed_local, i);
        return in_sz + 1u;
    }

    case GPX5_CODEC_RICE3: {
        /* Rice(k=3) encode delta values
         * byte[0] = orig_sz; bitstream starts at bit 8 (mirrors decode) */
        if (in_sz + 5u > out_cap) return 0u;
        memset(out, 0, out_cap);
        out[0] = (uint8_t)(in_sz & 0xFFu);   /* orig_sz */
        uint32_t bit_pos = 8u;                /* skip orig_sz byte */
        for (uint32_t i = 0; i < in_sz; i++) {
            uint32_t delta = (uint32_t)(in[i] ^ hb_predict(seed_local, i));
            /* zigzag: map signed to unsigned (0→0, -1→1, 1→2, -2→3 ...) */
            int32_t  sv    = (int32_t)delta - 128;
            uint32_t zz    = (sv < 0) ? (uint32_t)((-sv)*2 - 1) : (uint32_t)(sv*2);
            bit_pos = hb_rice3_encode_val(zz, out, bit_pos);
            if ((bit_pos >> 3) >= out_cap - 4u) {
                /* overflow: fall back to raw */
                memcpy(out, in, in_sz);
                return in_sz;
            }
        }
        return (bit_pos + 7u) >> 3u;   /* round up to bytes */
    }

    case GPX5_CODEC_HILBERT: {
        /* Walk/no-walk bit stream: 1 bit per input byte
         * byte[0] = orig_sz (like DELTA) so decode knows how many bytes to emit
         * bit=1 → byte differs from prediction (store original in aux stream — not yet)
         *       → for now: mark walk, decoder uses prediction (lossless only when delta≈0)
         * bit=0 → matches prediction */
        if (in_sz + 1u > out_cap) return 0u;
        uint32_t n_bits    = in_sz;
        uint32_t bit_bytes = (n_bits + 7u) >> 3u;
        if (1u + bit_bytes > out_cap) return 0u;
        out[0] = (uint8_t)(in_sz & 0xFFu);  /* orig_sz */
        memset(out + 1u, 0, bit_bytes);
        for (uint32_t i = 0; i < n_bits; i++) {
            uint8_t pred = hb_predict(seed_local, i);
            if (in[i] != pred) {
                out[1u + (i >> 3)] |= (uint8_t)(1u << (7u - (i & 7u)));
            }
        }
        return 1u + bit_bytes;
    }

    case GPX5_CODEC_FREQ:
        /* H3 stub — fall back to delta until frequency separation is wired */
        if (in_sz + 1u > out_cap) return 0u;
        out[0] = (uint8_t)(in_sz & 0xFFu);
        for (uint32_t i = 0; i < in_sz; i++)
            out[1 + i] = in[i] ^ hb_predict(seed_local, i);
        return in_sz + 1u;

    case GPX5_CODEC_ZSTD19:
        /* H3 stub — fall back to raw until zstd is linked */
        if (in_sz > out_cap) return 0u;
        memcpy(out, in, in_sz);
        return in_sz;

    default:
        /* unknown codec: raw passthrough */
        if (in_sz > out_cap) return 0u;
        memcpy(out, in, in_sz);
        return in_sz;
    }
}

/* ══════════════════════════════════════════════════════
 * H4: hamburger_encode_run
 *
 * Process all tiles through 1440-tick warm-up.
 * For each tile:
 *   1. derive seed_local from global_seed + tile_id
 *   2. compute hilbert_entry from seed_local
 *   3. dispatch to carrier (H1)
 *   4. apply carrier codec → encoded bytes
 *   5. record invert state (H2)
 *
 * After all tiles: freeze invert recorder, build LUT.
 *
 * tiles[]  : array of HbTileIn, n_tiles entries
 * Returns HB_OK or HB_ERR_*
 * ══════════════════════════════════════════════════════ */

static inline int hb_encode_run(
        HbEncodeCtx *ctx,
        const HbTileIn *tiles,
        uint32_t n_tiles)
{
    if (n_tiles == 0 || n_tiles > HB_MAX_TILES) return HB_ERR_TILES;
    if (ctx->frozen) return HB_ERR_TILES;

    /* per-tile encoded output buffer (reused each tile) */
    uint8_t *enc_buf = (uint8_t *)calloc(1, HB_TILE_SZ_MAX + 16u);
    if (!enc_buf) return HB_ERR_ALLOC;

    /* run 1440 ticks: tick t processes tile (t % n_tiles) */
    for (uint32_t tick = 0; tick < GPX5_TICK_PERIOD; tick++) {
        uint32_t ti = tick % n_tiles;
        const HbTileIn *tile = &tiles[ti];

        /* derive per-tile seed */
        uint32_t seed_local  = gpx5_seed_local(ctx->global_seed, tile->tile_id);
        uint16_t hilbert_pos = gpx5_hilbert_entry(seed_local, tile->tile_id);

        /* H1: dispatch — 2-carrier or 3-carrier */
        HbDispatch disp;
        if (ctx->use_2carrier) {
            disp = hb_dispatch_2carrier(hilbert_pos, ctx->pipes);
            if (disp.carrier_id == 2u) {
                /* band collision: fall back to 3-carrier for this tile */
                disp = hb_dispatch(hilbert_pos, ctx->pipes);
            }
        } else {
            disp = hb_dispatch(hilbert_pos, ctx->pipes);
        }

        /* apply codec */
        memset(enc_buf, 0, HB_TILE_SZ_MAX + 16u);
        uint32_t enc_sz = hb_codec_apply(
            disp.codec, tile->ttype,
            tile->data, tile->sz,
            enc_buf, HB_TILE_SZ_MAX + 16u,
            seed_local);

        /* H2: record state transition */
        uint32_t state_before = hb_tile_state_hash(
            tile->data, tile->sz, tile->tile_id, tick);
        uint32_t state_after  = hb_tile_state_hash(
            enc_buf, enc_sz, tile->tile_id, tick + 1u);
        hb_invert_record(&ctx->rec, tile->tile_id, state_before, state_after, tile->ttype);

        /* drain tick: fence boundary (not stored, just skip) */
        if (gpx5_is_drain_tick(tick)) { /* no-op by design */ }
    }

    free(enc_buf);

    /* freeze invert recorder */
    ctx->n_active = hb_invert_freeze(&ctx->rec);

    /* build invert byte stream */
    ctx->inv_stream_sz = ctx->rec.n_tiles * HB_INVERT_ENTRY_SZ;
    ctx->inv_stream    = (uint8_t *)calloc(1, ctx->inv_stream_sz + 1u);
    if (!ctx->inv_stream) return HB_ERR_ALLOC;
    ctx->inv_stream_sz = hb_invert_write_stream(&ctx->rec, ctx->inv_stream);

    /* build LUT */
    ctx->lut = (Gpx5LutEntry *)calloc(n_tiles, sizeof(Gpx5LutEntry));
    if (!ctx->lut) return HB_ERR_ALLOC;

    /* invert stream starts at: file_hdr + pipe_table + set_table + lut_table
     * estimate: use 0 as base offset here; gpx5_write adjusts real offsets */
    uint32_t inv_base = GPX5_FILE_HDR_SZ
                      + 3u * GPX5_PIPE_ENTRY_SZ
                      + 1u * GPX5_SET_ENTRY_SZ      /* 1 set for this encode */
                      + n_tiles * GPX5_LUT_ENTRY_SZ;

    hb_build_lut(&ctx->rec, ctx->lut, 0u /* set_id=0 */, inv_base);
    ctx->frozen = 1u;
    return HB_OK;
}

/* ══════════════════════════════════════════════════════
 * H4: hamburger_encode — write gpx5 file
 *
 * Combines encode_run + gpx5 file write.
 * path     : output file path
 * Returns HB_OK or HB_ERR_*
 * ══════════════════════════════════════════════════════ */

static inline int hamburger_encode(
        const char *path,
        HbEncodeCtx *ctx,
        const HbTileIn *tiles,
        uint32_t n_tiles)
{
    int r = hb_encode_run(ctx, tiles, n_tiles);
    if (r != HB_OK) return r;

    FILE *f = fopen(path, "wb");
    if (!f) return HB_ERR_IO;

    /* ── file header ── */
    Gpx5FileHdr hdr;
    memset(&hdr, 0, sizeof(hdr));
    hdr.magic       = GPX5_MAGIC;
    hdr.version     = GPX5_VERSION;
    hdr.flags       = GPX5_LUT_WARM | GPX5_LUT_FROZEN;
    hdr.n_sets      = 1u;
    hdr.tw          = ctx->tw;
    hdr.th          = ctx->th;
    hdr.n_tiles     = n_tiles;
    hdr.global_seed = ctx->global_seed;
    hdr.tick_max    = (uint16_t)GPX5_TICK_PERIOD;
    uint8_t hbuf[GPX5_FILE_HDR_SZ];
    gpx5_hdr_write(hbuf, &hdr);
    fwrite(hbuf, 1, GPX5_FILE_HDR_SZ, f);

    /* ── pipe table ── */
    uint8_t pbuf[GPX5_PIPE_ENTRY_SZ];
    for (int i = 0; i < 3; i++) {
        gpx5_pipe_write(pbuf, &ctx->pipes[i]);
        fwrite(pbuf, 1, GPX5_PIPE_ENTRY_SZ, f);
    }

    /* ── set table (1 set) ── */
    uint32_t set_data_offset = GPX5_FILE_HDR_SZ
                             + 3u * GPX5_PIPE_ENTRY_SZ
                             + 1u * GPX5_SET_ENTRY_SZ
                             + n_tiles * GPX5_LUT_ENTRY_SZ;
    Gpx5SetEntry se;
    se.set_id      = 0u;
    se.level       = 0u;
    se.tick_start  = 0u;
    se.tick_end    = (uint16_t)GPX5_TICK_PERIOD;
    se.data_offset = set_data_offset;
    se.data_size   = ctx->inv_stream_sz;
    uint8_t sbuf[GPX5_SET_ENTRY_SZ];
    gpx5_set_write(sbuf, &se);
    fwrite(sbuf, 1, GPX5_SET_ENTRY_SZ, f);

    /* ── LUT table ── */
    uint8_t lbuf[GPX5_LUT_ENTRY_SZ];
    for (uint32_t i = 0; i < n_tiles; i++) {
        gpx5_lut_write(lbuf, &ctx->lut[i]);
        fwrite(lbuf, 1, GPX5_LUT_ENTRY_SZ, f);
    }

    /* ── invert stream (set data) ── */
    if (ctx->inv_stream && ctx->inv_stream_sz > 0)
        fwrite(ctx->inv_stream, 1, ctx->inv_stream_sz, f);

    fclose(f);
    return HB_OK;
}

/* ══════════════════════════════════════════════════════
 * H5: hamburger_decode
 *
 * Read gpx5 file → reconstruct tiles via invert chain.
 * For each tile_id:
 *   1. LUT lookup → invert_offset (O1, no traversal)
 *   2. Read invert value at offset
 *   3. Derive seed_local → dispatch → get codec
 *   4. Reconstruct tile bytes via codec inverse
 *
 * out_tiles : caller-allocated array, n_tiles entries
 *             each entry: uint8_t[HB_TILE_SZ_MAX]
 * Returns HB_OK or HB_ERR_*
 * ══════════════════════════════════════════════════════ */

/* codec inverse: recover original bytes from encoded bytes */
static inline uint32_t hb_codec_invert(
        uint8_t codec,
        uint8_t ttype,
        const uint8_t *enc,
        uint32_t enc_sz,
        uint8_t *out,
        uint32_t out_cap,
        uint32_t seed_local)
{
    if (!enc || !out || out_cap == 0u) return 0u;

    switch (codec) {

    case GPX5_CODEC_NONE:
    case GPX5_CODEC_RAW:
        if (enc_sz > out_cap) return 0u;
        memcpy(out, enc, enc_sz);
        return enc_sz;

    case GPX5_CODEC_SEED:
        if (ttype == GPX5_TTYPE_FLAT) {
            /* FLAT: reconstruct via seed prediction alone */
            for (uint32_t i = 0; i < out_cap; i++)
                out[i] = hb_predict(seed_local, i);
            return out_cap;
        }
        /* fall through to delta */

    case GPX5_CODEC_DELTA: {
        if (enc_sz < 1u) return 0u;
        uint32_t orig_sz = (uint32_t)enc[0];
        if (orig_sz > out_cap || orig_sz + 1u > enc_sz) return 0u;
        for (uint32_t i = 0; i < orig_sz; i++)
            out[i] = enc[1 + i] ^ hb_predict(seed_local, i);
        return orig_sz;
    }

    case GPX5_CODEC_HILBERT: {
        /* byte[0] = orig_sz; remaining = walk-bit stream */
        if (enc_sz < 1u) return 0u;
        uint32_t orig_sz = (uint32_t)enc[0];
        if (orig_sz > out_cap) return 0u;
        for (uint32_t i = 0; i < orig_sz; i++) {
            uint8_t bit  = (enc[1u + (i >> 3)] >> (7u - (i & 7u))) & 1u;
            out[i] = bit ? (uint8_t)(hb_predict(seed_local, i) ^ 0xFFu)
                         : hb_predict(seed_local, i);
            /* NOTE: walk=1 marks mismatch but original byte is lost in bit-only
             * encoding — using XOR flip as best-effort until aux stream is added */
        }
        return orig_sz;
    }

    case GPX5_CODEC_RICE3: {
        /* Rice(k=3) decode: reverse of hb_rice3_encode_val
         * Encoded as: byte[0]=orig_sz, remaining=bitstream */
        if (enc_sz < 1u) return 0u;
        uint32_t orig_sz = (uint32_t)enc[0];
        if (orig_sz > out_cap) return 0u;
        const uint32_t k = 3u;
        const uint32_t k_mask = (1u << k) - 1u;
        uint32_t bit_pos = 0u;
        /* skip orig_sz byte — bits start at bit 8 */
        bit_pos = 8u;
        for (uint32_t i = 0; i < orig_sz; i++) {
            /* read unary quotient: count 1-bits until stop-bit 0 */
            uint32_t q = 0u;
            while (1) {
                uint32_t byte_i = bit_pos >> 3;
                uint32_t bit_i  = 7u - (bit_pos & 7u);
                if (byte_i >= enc_sz) goto rice_done;
                uint8_t b = (enc[byte_i] >> bit_i) & 1u;
                bit_pos++;
                if (!b) break;   /* stop bit */
                q++;
                if (q > 512u) goto rice_done; /* safety */
            }
            /* read k remainder bits MSB first */
            uint32_t r = 0u;
            for (uint32_t rb = 0; rb < k; rb++) {
                uint32_t byte_i = bit_pos >> 3;
                uint32_t bit_i  = 7u - (bit_pos & 7u);
                if (byte_i >= enc_sz) goto rice_done;
                r = (r << 1u) | ((enc[byte_i] >> bit_i) & 1u);
                bit_pos++;
            }
            uint32_t zz = (q << k) | (r & k_mask);
            /* reverse zigzag */
            int32_t sv = (zz & 1u) ? -(int32_t)((zz + 1u) >> 1u)
                                    :  (int32_t)(zz >> 1u);
            int32_t delta = sv + 128;
            /* XOR with prediction to recover original */
            out[i] = (uint8_t)((uint32_t)delta ^ (uint32_t)hb_predict(seed_local, i));
        }
        rice_done:
        return orig_sz;
    }

    case GPX5_CODEC_FREQ:
    case GPX5_CODEC_ZSTD19:
        /* H3 stubs: fall back to raw copy */
        if (enc_sz > out_cap) return 0u;
        memcpy(out, enc, enc_sz);
        return enc_sz;

    default:
        if (enc_sz > out_cap) return 0u;
        memcpy(out, enc, enc_sz);
        return enc_sz;
    }
}

static inline int hamburger_decode(
        const char *path,
        uint8_t **out_tiles,     /* caller alloc: [n_tiles][HB_TILE_SZ_MAX] */
        uint32_t *out_n_tiles,
        uint32_t *out_tile_sz)
{
    Gpx5File gf;
    if (gpx5_open(path, &gf) != 0) return HB_ERR_IO;

    if (!(gf.hdr.flags & GPX5_LUT_WARM)) {
        gpx5_close(&gf);
        return HB_ERR_NO_LUT;
    }

    uint32_t n_tiles = gf.hdr.n_tiles;
    *out_n_tiles     = n_tiles;
    *out_tile_sz     = HB_TILE_SZ_MAX;

    uint8_t *tile_buf = (uint8_t *)calloc(1, HB_TILE_SZ_MAX + 16u);
    if (!tile_buf) { gpx5_close(&gf); return HB_ERR_ALLOC; }

    for (uint32_t ti = 0; ti < n_tiles; ti++) {
        uint8_t *dst = out_tiles[ti];
        if (!dst) continue;

        /* O(1) LUT lookup */
        const uint8_t *inv_ptr = gpx5_tile_invert_ptr(&gf, (uint16_t)ti);

        /* derive seed + hilbert + dispatch */
        uint32_t seed_local  = gpx5_seed_local(gf.hdr.global_seed, (uint32_t)ti);
        uint16_t hilbert_pos = gpx5_hilbert_entry(seed_local, (uint16_t)ti);
        HbDispatch disp      = hb_dispatch(hilbert_pos, gf.pipes);

        if (!inv_ptr || inv_ptr[0] == 0xFF) {
            /* zero invert = tile unchanged = pure prediction */
            for (uint32_t i = 0; i < HB_TILE_SZ_MAX; i++)
                dst[i] = hb_predict(seed_local, i);
            continue;
        }

        /* read invert entry: [tile_id 2B][ttype 1B][invert_val 4B] */
        uint8_t  tile_ttype = inv_ptr[2];
        /* uint16_t chk_id = (uint16_t)((inv_ptr[0]<<8)|inv_ptr[1]); */
        /* uint32_t inv_val = g5r4(inv_ptr+3); (available for verification) */

        /* reconstruct via codec inverse */
        uint32_t set_sz = 0u;
        const uint8_t *set_data = gpx5_tile_set_data(&gf, (uint16_t)ti, &set_sz);
        if (!set_data || set_sz == 0u) {
            memset(dst, 0, HB_TILE_SZ_MAX);
            continue;
        }

        memset(tile_buf, 0, HB_TILE_SZ_MAX + 16u);
        hb_codec_invert(
            disp.codec, tile_ttype,
            set_data, set_sz,
            tile_buf, HB_TILE_SZ_MAX,
            seed_local);
        memcpy(dst, tile_buf, HB_TILE_SZ_MAX);
    }

    free(tile_buf);
    gpx5_close(&gf);
    return HB_OK;
}

/* ══════════════════════════════════════════════════════════
 * hamburger_encode_image — all-in-one: classify → pipe → encode → write
 *
 * HbImageIn  : raw YCgCo int planes + dimensions
 * Internally: classify_batch → auto_pipes → build HbTileIn[] → encode_run → write
 * Caller needs NOTHING pre-classified.
 *
 * img_Y/Cg/Co : int arrays, stride = img_w pixels
 * img_w/h     : full image dimensions
 * tile_w/h    : tile size (recommend 16x16, same as v21 calibration)
 * path        : output .gpx5 file
 * global_seed : root seed
 * use_2carrier: 1 = attempt 2-carrier mode
 *
 * Returns HB_OK or HB_ERR_*
 * ══════════════════════════════════════════════════════════ */

typedef struct {
    const int *Y;     /* luma plane,   stride = w pixels */
    const int *Cg;    /* chroma-green, stride = w pixels */
    const int *Co;    /* chroma-orange,stride = w pixels */
    int        w;     /* image width  in pixels          */
    int        h;     /* image height in pixels          */
    int        tw;    /* tile width   in pixels          */
    int        th;    /* tile height  in pixels          */
} HbImageIn;

static inline int hamburger_encode_image(
        const char   *path,
        const HbImageIn *img,
        uint32_t      global_seed,
        uint8_t       use_2carrier)
{
    if (!img || !img->Y || !img->Cg || !img->Co) return HB_ERR_TILES;
    if (img->tw <= 0 || img->th <= 0)            return HB_ERR_TILES;

    int tiles_x = img->w / img->tw;
    int tiles_y = img->h / img->th;
    uint32_t n_tiles = (uint32_t)(tiles_x * tiles_y);
    if (n_tiles == 0 || n_tiles > HB_MAX_TILES)  return HB_ERR_TILES;

    /* ── Step 1: classify all tiles ── */
    uint8_t *ttypes = (uint8_t *)calloc(n_tiles, 1u);
    if (!ttypes) return HB_ERR_ALLOC;

    hb_classify_batch(
        img->Y, img->Cg, img->Co, img->w,
        img->tw, img->th,
        tiles_x, tiles_y,
        ttypes);

    /* ── Step 2: auto-build pipe table from ttype histogram ── */
    Gpx5PipeEntry pipes[3];
    hb_auto_pipes(ttypes, n_tiles, pipes);

    /* ── Step 3: build HbTileIn[] — point directly into img planes ── */
    /* tile data: pack Y+Cg+Co row-interleaved into per-tile buffers   */
    /* each tile buf = tile_w * tile_h * 3 channels as uint8            */
    uint32_t tile_bytes = (uint32_t)(img->tw * img->th * 3u);
    if (tile_bytes > HB_TILE_SZ_MAX) { free(ttypes); return HB_ERR_TILES; }

    uint8_t *tile_pool = (uint8_t *)calloc(n_tiles, HB_TILE_SZ_MAX);
    HbTileIn *tiles    = (HbTileIn *)calloc(n_tiles, sizeof(HbTileIn));
    if (!tile_pool || !tiles) {
        free(ttypes); free(tile_pool); free(tiles);
        return HB_ERR_ALLOC;
    }

    for (uint32_t ti = 0; ti < n_tiles; ti++) {
        int tx = (int)(ti % (uint32_t)tiles_x);
        int ty = (int)(ti / (uint32_t)tiles_x);
        int x0 = tx * img->tw;
        int y0 = ty * img->th;
        uint8_t *dst = tile_pool + ti * HB_TILE_SZ_MAX;
        uint32_t off = 0u;

        /* pack Y, Cg, Co rows into flat uint8 buffer (clamp 0-255) */
        for (int y = y0; y < y0 + img->th && y < img->h; y++) {
            for (int x = x0; x < x0 + img->tw && x < img->w; x++) {
                int idx = y * img->w + x;
                int yv  = img->Y[idx];  if(yv<0)yv=0; if(yv>255)yv=255;
                int gv  = img->Cg[idx]; if(gv<0)gv=0; if(gv>255)gv=255;
                int ov  = img->Co[idx]; if(ov<0)ov=0; if(ov>255)ov=255;
                dst[off++] = (uint8_t)yv;
                dst[off++] = (uint8_t)gv;
                dst[off++] = (uint8_t)ov;
            }
        }

        tiles[ti].data    = dst;
        tiles[ti].sz      = off;
        tiles[ti].tile_id = (uint16_t)ti;
        tiles[ti].ttype   = ttypes[ti];
    }

    /* ── Step 4: init ctx + encode + write ── */
    HbEncodeCtx ctx;
    hb_encode_init(&ctx, global_seed,
        (uint16_t)tiles_x, (uint16_t)tiles_y,
        pipes, use_2carrier);

    int r = hamburger_encode(path, &ctx, tiles, n_tiles);

    hb_encode_free(&ctx);
    free(ttypes);
    free(tile_pool);
    free(tiles);
    return r;
}

/* ══════════════════════════════════════════════════════════
 * hamburger_decode_image — inverse of encode_image
 *
 * Reads a .gpx5 file → reconstructs YCgCo int planes.
 * Caller must free out->Y / out->Cg / out->Co after use.
 *
 * Returns HB_OK or HB_ERR_*
 * ══════════════════════════════════════════════════════════ */

typedef struct {
    int      *Y;    /* luma plane,    caller must free */
    int      *Cg;   /* chroma-green,  caller must free */
    int      *Co;   /* chroma-orange, caller must free */
    int       w;    /* image width  in pixels          */
    int       h;    /* image height in pixels          */
    int       tw;   /* tile width   used during encode */
    int       th;   /* tile height  used during encode */
} HbImageOut;

static inline int hamburger_decode_image(
        const char  *path,
        HbImageOut  *out,   /* caller alloc struct; func fills w/h and mallocs planes */
        int          img_w,
        int          img_h,
        int          tile_w,
        int          tile_h)
{
    if (!path || !out) return HB_ERR_IO;
    if (tile_w <= 0 || tile_h <= 0 || img_w <= 0 || img_h <= 0)
        return HB_ERR_TILES;

    int tiles_x  = img_w  / tile_w;
    int tiles_y  = img_h  / tile_h;
    uint32_t n_tiles = (uint32_t)(tiles_x * tiles_y);
    if (n_tiles == 0 || n_tiles > HB_MAX_TILES) return HB_ERR_TILES;

    /* ── alloc output tile buffers ── */
    uint8_t **tile_ptrs = (uint8_t **)calloc(n_tiles, sizeof(uint8_t *));
    if (!tile_ptrs) return HB_ERR_ALLOC;
    for (uint32_t i = 0; i < n_tiles; i++) {
        tile_ptrs[i] = (uint8_t *)calloc(1, HB_TILE_SZ_MAX);
        if (!tile_ptrs[i]) {
            for (uint32_t j = 0; j < i; j++) free(tile_ptrs[j]);
            free(tile_ptrs);
            return HB_ERR_ALLOC;
        }
    }

    uint32_t out_n = 0u, out_tsz = 0u;
    int r = hamburger_decode(path, tile_ptrs, &out_n, &out_tsz);
    if (r != HB_OK) {
        for (uint32_t i = 0; i < n_tiles; i++) free(tile_ptrs[i]);
        free(tile_ptrs);
        return r;
    }

    /* ── alloc YCgCo planes ── */
    int npx = img_w * img_h;
    out->Y  = (int *)calloc((size_t)npx, sizeof(int));
    out->Cg = (int *)calloc((size_t)npx, sizeof(int));
    out->Co = (int *)calloc((size_t)npx, sizeof(int));
    if (!out->Y || !out->Cg || !out->Co) {
        free(out->Y); free(out->Cg); free(out->Co);
        for (uint32_t i = 0; i < n_tiles; i++) free(tile_ptrs[i]);
        free(tile_ptrs);
        return HB_ERR_ALLOC;
    }
    out->w = img_w;  out->h = img_h;
    out->tw = tile_w; out->th = tile_h;

    /* ── unpack each tile → YCgCo planes ── */
    uint32_t tile_bytes = (uint32_t)(tile_w * tile_h * 3u);
    for (uint32_t ti = 0; ti < n_tiles && ti < out_n; ti++) {
        int tx = (int)(ti % (uint32_t)tiles_x);
        int ty = (int)(ti / (uint32_t)tiles_x);
        int x0 = tx * tile_w;
        int y0 = ty * tile_h;
        const uint8_t *src = tile_ptrs[ti];
        uint32_t off = 0u;

        for (int y = y0; y < y0 + tile_h && y < img_h; y++) {
            for (int x = x0; x < x0 + tile_w && x < img_w; x++) {
                if (off + 2u >= tile_bytes) goto tile_done;
                int idx = y * img_w + x;
                out->Y [idx] = (int)src[off++];
                out->Cg[idx] = (int)src[off++];
                out->Co[idx] = (int)src[off++];
            }
        }
        tile_done:;
    }

    for (uint32_t i = 0; i < n_tiles; i++) free(tile_ptrs[i]);
    free(tile_ptrs);
    return HB_OK;
}

/* convenience: free HbImageOut planes */
static inline void hb_image_out_free(HbImageOut *img) {
    if (!img) return;
    free(img->Y);  img->Y  = NULL;
    free(img->Cg); img->Cg = NULL;
    free(img->Co); img->Co = NULL;
}
