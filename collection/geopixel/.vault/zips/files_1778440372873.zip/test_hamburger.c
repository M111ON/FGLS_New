/*
 * test_hamburger.c — quick roundtrip test
 * gcc -O2 -o test_hamburger test_hamburger.c && ./test_hamburger
 *
 * No external deps. Tests:
 *   T1: pipe dispatch — 3 tiles go to 3 different carriers
 *   T2: 2-carrier band check — safe pair vs unsafe pair
 *   T3: codec roundtrip — SEED/DELTA/HILBERT encode→decode
 *   T4: invert recorder — zero tile = free, nonzero = active
 *   T5: full encode→file→decode roundtrip (4 dummy tiles)
 *   T6: LUT frozen — O(1) access after warm-up
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "gpx5_container.h"
#include "hamburger_pipe.h"
#include "hamburger_encode.h"

/* ── test helpers ──────────────────────────────────── */
static int g_pass = 0, g_fail = 0;
#define CHECK(label, cond) do { \
    if (cond) { printf("  PASS %s\n", label); g_pass++; } \
    else       { printf("  FAIL %s\n", label); g_fail++; } \
} while(0)

/* ══════════════════════════════════════════════════════
 * T1: pipe dispatch
 * hilbert_pos 0,1,2 → carrier 0,1,2 with default pipes
 * ══════════════════════════════════════════════════════ */
static void t1_dispatch(void) {
    printf("\nT1: pipe dispatch\n");
    Gpx5PipeEntry pipes[3];
    gpx5_default_pipes(pipes);

    HbDispatch d0 = hb_dispatch(0, pipes);
    HbDispatch d1 = hb_dispatch(1, pipes);
    HbDispatch d2 = hb_dispatch(2, pipes);
    HbDispatch d3 = hb_dispatch(3, pipes);  /* wraps: 3%3=0 → carrier 0 */

    CHECK("pos0 → carrier0", d0.carrier_id == 0);
    CHECK("pos1 → carrier1", d1.carrier_id == 1);
    CHECK("pos2 → carrier2", d2.carrier_id == 2);
    CHECK("pos3 → carrier0 (wrap)", d3.carrier_id == 0);
}

/* ══════════════════════════════════════════════════════
 * T2: 2-carrier band check
 * ══════════════════════════════════════════════════════ */
static void t2_band(void) {
    printf("\nT2: 2-carrier band check\n");
    /* safe: FLAT(low) + EDGE(high) */
    CHECK("FLAT+EDGE safe",  hb_2carrier_safe(GPX5_CTYPE_FLAT, GPX5_CTYPE_EDGE));
    /* unsafe: EDGE+NOISE both high */
    CHECK("EDGE+NOISE unsafe", !hb_2carrier_safe(GPX5_CTYPE_EDGE, GPX5_CTYPE_NOISE));
    /* safe: GRAD(low) + VECTOR(vec) */
    CHECK("GRAD+VECTOR safe", hb_2carrier_safe(GPX5_CTYPE_GRAD, GPX5_CTYPE_VECTOR));
    /* unsafe: FLAT+GRAD both low */
    CHECK("FLAT+GRAD unsafe", !hb_2carrier_safe(GPX5_CTYPE_FLAT, GPX5_CTYPE_GRAD));
}

/* ══════════════════════════════════════════════════════
 * T3: codec roundtrip
 * ══════════════════════════════════════════════════════ */
static void t3_codec(void) {
    printf("\nT3: codec roundtrip\n");
    uint32_t seed = 0xDEADBEEFu;

    /* test data: 16 bytes with known pattern */
    uint8_t orig[16] = {0x10,0x20,0x30,0x40,0x50,0x60,0x70,0x80,
                        0x90,0xA0,0xB0,0xC0,0xD0,0xE0,0xF0,0x00};
    uint8_t enc[64]  = {0};
    uint8_t dec[64]  = {0};

    /* DELTA roundtrip */
    uint32_t enc_sz = hb_codec_apply(GPX5_CODEC_DELTA, GPX5_TTYPE_EDGE,
                                     orig, 16, enc, 64, seed);
    uint32_t dec_sz = hb_codec_invert(GPX5_CODEC_DELTA, GPX5_TTYPE_EDGE,
                                      enc, enc_sz, dec, 64, seed);
    CHECK("DELTA enc_sz>0",    enc_sz > 0);
    CHECK("DELTA dec_sz==16",  dec_sz == 16);
    CHECK("DELTA roundtrip",   memcmp(orig, dec, 16) == 0);

    /* SEED roundtrip for FLAT tile */
    memset(enc, 0, 64); memset(dec, 0, 64);
    enc_sz = hb_codec_apply(GPX5_CODEC_SEED, GPX5_TTYPE_FLAT,
                             orig, 16, enc, 64, seed);
    CHECK("SEED flat enc_sz==4", enc_sz == 4);  /* just seed bytes */

    /* HILBERT roundtrip */
    memset(enc, 0, 64); memset(dec, 0, 64);
    enc_sz = hb_codec_apply(GPX5_CODEC_HILBERT, GPX5_TTYPE_EDGE,
                             orig, 16, enc, 64, seed);
    CHECK("HILBERT enc_sz==2",  enc_sz == 2);  /* 16 bits → 2 bytes */

    /* RAW roundtrip */
    memset(enc, 0, 64); memset(dec, 0, 64);
    enc_sz = hb_codec_apply(GPX5_CODEC_RAW, GPX5_TTYPE_NOISE,
                             orig, 16, enc, 64, seed);
    dec_sz = hb_codec_invert(GPX5_CODEC_RAW, GPX5_TTYPE_NOISE,
                              enc, enc_sz, dec, 64, seed);
    CHECK("RAW roundtrip",      memcmp(orig, dec, 16) == 0);
}

/* ══════════════════════════════════════════════════════
 * T4: invert recorder
 * ══════════════════════════════════════════════════════ */
static void t4_invert(void) {
    printf("\nT4: invert recorder\n");
    HbInvertRecorder rec;
    hb_invert_init(&rec);

    /* tile 0: same before/after → zero invert (free) */
    hb_invert_record(&rec, 0, 0xAAAAAAAAu, 0xAAAAAAAAu);
    /* tile 1: different → non-zero invert (active) */
    hb_invert_record(&rec, 1, 0x12345678u, 0x87654321u);
    /* tile 2: zero before, nonzero after */
    hb_invert_record(&rec, 2, 0x00000000u, 0xFFFFFFFFu);

    CHECK("tile0 invert==0 (free)",   hb_invert_get(&rec, 0) == 0);
    CHECK("tile1 invert!=0 (active)", hb_invert_get(&rec, 1) != 0);
    CHECK("tile2 invert==FFFFFFFF",   hb_invert_get(&rec, 2) == 0xFFFFFFFFu);

    uint32_t active = hb_invert_freeze(&rec);
    CHECK("freeze: 2 active entries", active == 2);

    /* write stream: only tile1 + tile2 should appear */
    uint8_t stream[64] = {0};
    uint32_t sz = hb_invert_write_stream(&rec, stream);
    CHECK("stream_sz == 2*6",  sz == 2 * HB_INVERT_ENTRY_SZ);
}

/* ══════════════════════════════════════════════════════
 * T5: full encode → file → decode roundtrip (4 tiles)
 * ══════════════════════════════════════════════════════ */
static void t5_roundtrip(void) {
    printf("\nT5: full encode→file→decode roundtrip\n");

    /* 4 tiles: FLAT, EDGE, GRAD, NOISE — 64 bytes each */
    const uint32_t TSIZ = 64u;
    const uint32_t NT   = 4u;

    uint8_t tile_data[4][64];
    for (uint32_t t = 0; t < NT; t++)
        for (uint32_t b = 0; b < TSIZ; b++)
            tile_data[t][b] = (uint8_t)((t * 64 + b) & 0xFF);

    HbTileIn tiles[4];
    uint8_t ttypes[4] = {GPX5_TTYPE_FLAT, GPX5_TTYPE_EDGE,
                         GPX5_TTYPE_GRADIENT, GPX5_TTYPE_NOISE};
    for (uint32_t t = 0; t < NT; t++) {
        tiles[t].data    = tile_data[t];
        tiles[t].sz      = TSIZ;
        tiles[t].tile_id = (uint16_t)t;
        tiles[t].ttype   = ttypes[t];
    }

    /* setup context */
    Gpx5PipeEntry pipes[3];
    gpx5_default_pipes(pipes);
    pipes[0].ctype = GPX5_CTYPE_FLAT;  pipes[0].codec = GPX5_CODEC_SEED;
    pipes[1].ctype = GPX5_CTYPE_EDGE;  pipes[1].codec = GPX5_CODEC_DELTA;
    pipes[2].ctype = GPX5_CTYPE_NOISE; pipes[2].codec = GPX5_CODEC_RAW;

    HbEncodeCtx ctx;
    hb_encode_init(&ctx, 0xCAFEBABEu, 2, 2, pipes, 0);

    const char *tmpfile = "/tmp/test_hamburger.gpx5";
    int r = hamburger_encode(tmpfile, &ctx, tiles, NT);
    CHECK("encode returns OK",     r == HB_OK);
    CHECK("ctx frozen after enc",  ctx.frozen == 1);
    CHECK("LUT allocated",         ctx.lut != NULL);
    CHECK("n_active > 0",          ctx.n_active > 0);

    hb_encode_free(&ctx);

    /* decode */
    uint8_t *out[4];
    for (int i = 0; i < 4; i++) out[i] = (uint8_t*)calloc(1, HB_TILE_SZ_MAX);
    uint32_t out_n = 0, out_sz = 0;
    r = hamburger_decode(tmpfile, out, &out_n, &out_sz);
    CHECK("decode returns OK",  r == HB_OK);
    CHECK("decode n_tiles==4",  out_n == NT);
    for (int i = 0; i < 4; i++) free(out[i]);
}

/* ══════════════════════════════════════════════════════
 * T6: LUT O(1) access
 * ══════════════════════════════════════════════════════ */
static void t6_lut(void) {
    printf("\nT6: LUT O(1) access\n");
    Gpx5LutEntry lut[4];
    HbInvertRecorder rec;
    hb_invert_init(&rec);

    hb_invert_record(&rec, 0, 0xAAAAu, 0xBBBBu);  /* active */
    hb_invert_record(&rec, 1, 0x1234u, 0x1234u);  /* free   */
    hb_invert_record(&rec, 2, 0x0000u, 0xFFFFu);  /* active */
    hb_invert_record(&rec, 3, 0xDEADu, 0xDEADu);  /* free   */
    hb_invert_freeze(&rec);

    uint32_t active = hb_build_lut(&rec, lut, 0u, 1000u);
    CHECK("2 active LUT entries",       active == 2);
    CHECK("tile0 has offset",           lut[0].invert_offset != 0xFFFFFFFFu);
    CHECK("tile1 is free (0xFFFFFFFF)", lut[1].invert_offset == 0xFFFFFFFFu);
    CHECK("tile2 has offset > tile0",   lut[2].invert_offset > lut[0].invert_offset);
    CHECK("tile3 is free (0xFFFFFFFF)", lut[3].invert_offset == 0xFFFFFFFFu);
}

/* ══════════════════════════════════════════════════════
 * MAIN
 * ══════════════════════════════════════════════════════ */
int main(void) {
    printf("=== hamburger test suite ===\n");
    t1_dispatch();
    t2_band();
    t3_codec();
    t4_invert();
    t5_roundtrip();
    t6_lut();
    printf("\n=== %d PASS / %d FAIL ===\n", g_pass, g_fail);
    return g_fail > 0 ? 1 : 0;
}
