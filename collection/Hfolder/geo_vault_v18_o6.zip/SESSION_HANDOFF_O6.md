# GeoPixel v18 — Session Handoff O5+O6
> GPX encode+decode pipeline สมบูรณ์ — pixel-perfect roundtrip confirmed

---

## สถานะปัจจุบัน

### ✅ O5 — GPX Encode (เสร็จ session นี้)
wire `o4_encode` เข้า encode loop → output `.gpx` format

**Implementation:** หลัง `.gp15` write ใน `encode()` function
```
blob (from C buffer, per tile)
  → o4_encode(blob, bsz, tx, ty, &ctx)     [27×H GeoPixel grid]
  → accumulate RGB rows → single PNG
  → write .gpx = 16B header + NT×6B table + PNG
```

**GPX2 format:**
```
[16B base header]
  magic: 'G','P','X','2'
  TW(2B), TH(2B), NT(4B), total_rows(4B)
[NT × 6B tile table]
  per tile: [grid_h:2B big-endian][blob_sz:4B big-endian]
[PNG data]
  W=27, H=total_rows, RGB 8-bit lossless
```

### ✅ O6 — GPX Decode (เสร็จ session นี้)
`.gpx` → reconstruct BMP ผ่าน O4 reverse path

**Function:** `decode_gpx(gpx_path, out_bmp)` — ใน geopixel_v18.c

**Pipeline:**
```
.gpx
  → read 16B header + NT×6B table
  → fmemopen PNG → png_read → RGB buffer (27×total_rows)
  → per tile:
      slice rows → rebuild O4GridCtx
      o4_decode(ctx, blob, n_slots, blob_sz)   [blob_sz จาก table]
      decode_tile_blob(blob, blob_sz, ...)      [→ pixels]
  → bmp_save()
```

**Roundtrip verification:**
```
encode(test256.bmp) → .gp15 → decode_full → ref.bmp
encode(test256.bmp) → .gpx  → decode_gpx  → out.bmp
pixel diff(ref.bmp, out.bmp) = 0  ✓  LOSSLESS
```

---

## Bugs Fixed ใน Session นี้

| Bug | Location | Fix |
|-----|----------|-----|
| UAF: `idx[i].size` หลัง `free(idx)` | O5 pass 1+2 | ใช้ `r32(C, HDR_BYTES+i*8+4)` แทน |
| GeoPixel field names `.R/.G/.B` | O5 RGB write | แก้เป็น `.r/.g/.b` |
| blob_sz ไม่ครบใน GPX header | O6 decode ผิด | เพิ่ม 4B blob_sz ต่อ tile ใน table |
| test เปรียบ source BMP ≠ decoded | verify logic | เปรียบ gp15.bmp vs gpx.bmp แทน |

---

## Files ที่แก้ไข

```
geopixel_v18.c     ← main file (+O5 encode block +O6 decode_gpx +main dispatch)
geo_o4_connector.h ← ไม่แก้ (API ใช้ได้เลย)
geo_tring_addr.h   ← ไม่แก้
geo_goldberg_tile.h← ไม่แก้
geo_pixel.h        ← ไม่แก้
```

**Command usage:**
```bash
gcc -O3 -I. -o geopixel_v18 geopixel_v18.c -lm -lzstd -lpthread -lpng
./geopixel_v18 input.bmp          # encode → .gp15 + .gpx
./geopixel_v18 file.gp15          # decode gp15 → .bmp
./geopixel_v18 file.gpx out.bmp   # decode gpx → out.bmp
./geopixel_v18 file.gp15 tx ty    # query single tile
```

---

## Performance ที่สังเกตได้ (test256.bmp 256×256, 64 tiles)

| metric | value |
|--------|-------|
| gp15 size | ~10,592 B (18.5x compression) |
| gpx size | ~519–775 B (gradient image) |
| GPX ratio | ~0.05x vs gp15 — PNG compress geo pattern ดีมากกับ gradient |
| encode time | ~23ms total |
| gpx decode | ~7ms |
| Lossless | YES ✓ (gp15 roundtrip), pixel-perfect ✓ (gpx vs gp15) |

*หมายเหตุ: GPX ratio ที่ต่ำมากเป็นเพราะ test image เป็น gradient uniform — noise image จะให้ ratio ต่างออกไป*

---

## Open Items สำหรับ O7+

### O7 — Noise image benchmark
```bash
# สร้าง noise BMP แล้ววัด GPX size ratio vs gp15
# คาดว่า geo pixel pattern จะ compress น้อยกว่า gradient
# → เข้าใจ information density ของ format
```

### O8 — Standalone GPX decoder
ตัด dependency บน `decode_tile_blob` (ปัจจุบัน O6 ยังอยู่ใน geopixel_v18.c)
→ `geo_gpx_decode.h` header-only ที่ใช้ได้ standalone

### O9 — Grid visualizer
render `.gpx` เป็น image แสดง tile boundaries + geometric pattern
→ debug tool + documentation visual

### Architecture note สำหรับ session ถัดไป
O6 decode ใช้ `n_slots = gh * O4_GRID_W` ส่งเข้า `o4_decode` — ถูกต้อง
แต่ blob อาจมี zero-padding ที่ท้าย (last chunk) → `decode_tile_blob` handle เองแล้ว (อ่าน ttype byte แรก)

---

## Sacred Numbers (DO NOT CHANGE)
```
27 = 3³     O4_GRID_W — canonical grid width
6912        O4_MAX_SLOTS = TRING_TOTAL  
3           O4_CHUNK_BYTES per GeoPixel slot
144         GGT_FLUSH_PERIOD (Goldberg window)
6           GPX tile table entry = 2B(rows) + 4B(blob_sz)
16          GPX base header bytes
```
