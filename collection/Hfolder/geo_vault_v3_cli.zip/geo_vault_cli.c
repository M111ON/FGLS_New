/*
 * geo_vault_cli.c — GeoVault command-line tool
 * compile: gcc -O2 -o gvault geo_vault_cli.c -lzstd
 *
 * Usage:
 *   gvault pack         <folder>                         → folder.geovault
 *   gvault unpack       <file.geovault> [outdir]
 *   gvault list         <file.geovault>
 *   gvault verify       <folder> <file.geovault>
 *   gvault cat          <file.geovault> <rel_path>       → stdout
 *   gvault put          <file.geovault> <src> [rel_path]
 *   gvault compact      <file.geovault>
 *   gvault xattr-list   <file.geovault> <rel_path>       → keys
 *   gvault xattr-get    <file.geovault> <rel_path> <key> → value
 *   gvault xattr-set    <file.geovault> <rel_path> <key> <value>
 *   gvault mime-scan    <file.geovault>                  → MIME for every file
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <dirent.h>
#include <errno.h>
#include "geo_vault.h"
#include "geo_vault_io.h"

/* ── madvise hint helpers ─────────────────────────────────────────── */
/* Switch entire mmap region hint: sequential (scan) or random (point lookup) */
static void gv_hint_sequential(GeoVaultCtx *ctx) {
#ifdef MADV_SEQUENTIAL
    if (ctx->mmap_base && ctx->mmap_size)
        madvise(ctx->mmap_base, ctx->mmap_size, MADV_SEQUENTIAL);
#else
    (void)ctx;
#endif
}
static void gv_hint_random(GeoVaultCtx *ctx) {
#ifdef MADV_RANDOM
    if (ctx->mmap_base && ctx->mmap_size)
        madvise(ctx->mmap_base, ctx->mmap_size, MADV_RANDOM);
#else
    (void)ctx;
#endif
}


static char  **g_abs_paths = NULL;
static char  **g_rel_paths = NULL;
static uint32_t g_n = 0;
static uint32_t g_cap = 0;

static void push_file(const char *abs, const char *rel) {
    if (g_n >= g_cap) {
        g_cap = g_cap ? g_cap * 2 : 64;
        g_abs_paths = realloc(g_abs_paths, g_cap * sizeof(char*));
        g_rel_paths = realloc(g_rel_paths, g_cap * sizeof(char*));
    }
    g_abs_paths[g_n] = strdup(abs);
    g_rel_paths[g_n] = strdup(rel);
    g_n++;
}

static void scan_dir(const char *abs_base, const char *rel_base) {
    DIR *d = opendir(abs_base);
    if (!d) return;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (de->d_name[0] == '.') continue;
        char abs[4096], rel[4096];
        snprintf(abs, sizeof(abs), "%s/%s", abs_base, de->d_name);
        if (rel_base[0])
            snprintf(rel, sizeof(rel), "%s/%s", rel_base, de->d_name);
        else
            snprintf(rel, sizeof(rel), "%s", de->d_name);

        struct stat st;
        if (stat(abs, &st) != 0) continue;
        if (S_ISDIR(st.st_mode))  scan_dir(abs, rel);
        else if (S_ISREG(st.st_mode)) push_file(abs, rel);
    }
    closedir(d);
}

static void free_paths(void) {
    for (uint32_t i = 0; i < g_n; i++) { free(g_abs_paths[i]); free(g_rel_paths[i]); }
    free(g_abs_paths); free(g_rel_paths);
    g_abs_paths = g_rel_paths = NULL; g_n = g_cap = 0;
}

/* ── mkdir -p ─────────────────────────────────────────────────────── */
static void mkdirp(const char *path) {
    char tmp[4096]; snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') { *p = 0; mkdir(tmp, 0755); *p = '/'; }
    }
    mkdir(tmp, 0755);
}

/* ── commands ─────────────────────────────────────────────────────── */
static int cmd_pack(const char *folder) {
    /* strip trailing slash */
    char base[4096]; snprintf(base, sizeof(base), "%s", folder);
    size_t bl = strlen(base);
    if (bl && base[bl-1] == '/') base[bl-1] = 0;

    scan_dir(base, "");
    if (g_n == 0) { fprintf(stderr, "No files found in %s\n", folder); return 1; }

    char out[4096]; snprintf(out, sizeof(out), "%s.geovault", base);

    printf("Packing %u files from %s\n", g_n, base);
    int r = gv_write((const char**)g_abs_paths,
                     (const char**)g_rel_paths, g_n, out);
    if (r == 0) printf("Created: %s\n", out);
    else        fprintf(stderr, "Pack failed: %d\n", r);

    free_paths();
    return r == 0 ? 0 : 1;
}

static int cmd_unpack(const char *vault_path, const char *outdir) {
    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open %s\n", vault_path); return 1; }

    /* determine output directory */
    char base[4096];
    if (outdir) {
        snprintf(base, sizeof(base), "%s", outdir);
    } else {
        /* strip .geovault suffix */
        snprintf(base, sizeof(base), "%s", vault_path);
        char *dot = strstr(base, ".geovault");
        if (dot) *dot = 0;
        strcat(base, "_out");
    }
    mkdirp(base);

    printf("Unpacking %u files to %s\n", ctx->hdr.n_files, base);
    gv_hint_sequential(ctx);   /* full scan — prefetch pages in order */
    if (gv_load_frames(ctx) < 0) {
        fprintf(stderr, "Failed to decompress pixel buffer\n");
        gv_close(ctx); return 1;
    }

    uint32_t ok = 0;
    for (uint32_t i = 0; i < ctx->hdr.n_files; i++) {
        uint8_t *data = gv_extract(ctx, i);
        if (!data) { printf("  [!] %s  (extract failed)\n", ctx->paths[i]); continue; }

        char out[4096]; snprintf(out, sizeof(out), "%s/%s", base, ctx->paths[i]);
        /* mkdir parent */
        char parent[4096]; snprintf(parent, sizeof(parent), "%s", out);
        char *slash = strrchr(parent, '/');
        if (slash) { *slash = 0; mkdirp(parent); }

        FILE *f = fopen(out, "wb");
        if (f) { fwrite(data, 1, ctx->entries[i].raw_size, f); fclose(f); ok++; }
        else   { fprintf(stderr, "  [!] cannot write %s\n", out); }

        printf("  [%c] %s (%u B)\n", f ? 'v' : '!', ctx->paths[i],
               ctx->entries[i].raw_size);
        free(data);
    }

    printf("\n%u/%u extracted\n", ok, ctx->hdr.n_files);
    gv_close(ctx);
    return ok == ctx->hdr.n_files ? 0 : 1;
}

static int cmd_list(const char *vault_path) {
    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open %s\n", vault_path); return 1; }
    gv_list(ctx);
    gv_close(ctx);
    return 0;
}

static int cmd_verify(const char *folder, const char *vault_path) {
    /* scan folder */
    char base[4096]; snprintf(base, sizeof(base), "%s", folder);
    size_t bl = strlen(base); if (bl && base[bl-1]=='/') base[bl-1]=0;
    scan_dir(base, "");

    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open %s\n", vault_path); free_paths(); return 1; }
    if (gv_load_frames(ctx) < 0) { gv_close(ctx); free_paths(); return 1; }

    uint32_t ok = 0, total = g_n;
    for (uint32_t i = 0; i < g_n; i++) {
        int idx = gv_find(ctx, g_rel_paths[i]);
        if (idx < 0) { printf("  [MISSING] %s\n", g_rel_paths[i]); continue; }

        /* read original */
        FILE *f = fopen(g_abs_paths[i], "rb");
        if (!f) continue;
        fseek(f, 0, SEEK_END); uint32_t sz = (uint32_t)ftell(f); fseek(f, 0, SEEK_SET);
        uint8_t *orig = malloc(sz); fread(orig, 1, sz, f); fclose(f);

        /* extract from vault */
        uint8_t *dec = gv_extract(ctx, (uint32_t)idx);
        int match = dec && (ctx->entries[idx].raw_size == sz) &&
                    memcmp(orig, dec, sz) == 0;

        printf("  [%s] %s (%u B)\n", match ? "OK" : "FAIL", g_rel_paths[i], sz);
        if (match) ok++;
        free(orig); free(dec);
    }

    printf("\nVerify: %u/%u PASS\n", ok, total);
    gv_close(ctx); free_paths();
    return ok == total ? 0 : 1;
}

static int cmd_cat(const char *vault_path, const char *rel_path) {
    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) return 1;
    int idx = gv_find(ctx, rel_path);
    if (idx < 0) { fprintf(stderr, "Not found: %s\n", rel_path); gv_close(ctx); return 1; }
    gv_hint_random(ctx);   /* single frame point lookup */
    if (gv_load_frames(ctx) < 0) { gv_close(ctx); return 1; }
    uint8_t *data = gv_extract(ctx, (uint32_t)idx);
    if (data) { fwrite(data, 1, ctx->entries[idx].raw_size, stdout); free(data); }
    gv_close(ctx);
    return 0;
}

/* ── xattr commands ───────────────────────────────────────────────── */

/* gvault xattr-list <vault> <rel_path>
 *   Prints all xattr keys for the given file, one per line. */
static int cmd_xattr_list(const char *vault_path, const char *rel_path) {
    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open: %s\n", vault_path); return 1; }

    int idx = gv_find(ctx, rel_path);
    if (idx < 0) {
        fprintf(stderr, "Not found in vault: %s\n", rel_path);
        gv_close(ctx); return 1;
    }

    /* gv_xattr_list returns needed bytes; buf "key\0key\0..." */
    char buf[GV_XATTR_MAX * GV_XATTR_KEY_MAX];
    int total = gv_xattr_list(ctx, idx, buf, sizeof(buf));
    if (total <= 0) {
        printf("(no xattrs)\n");
        gv_close(ctx); return 0;
    }

    int count = 0;
    for (char *p = buf; p < buf + total; p += strlen(p) + 1) {
        printf("%s\n", p);
        count++;
    }
    printf("\n%d attribute(s)\n", count);
    gv_close(ctx);
    return 0;
}

/* gvault xattr-get <vault> <rel_path> <key>
 *   Prints value to stdout (raw bytes). */
static int cmd_xattr_get(const char *vault_path, const char *rel_path,
                         const char *key) {
    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open: %s\n", vault_path); return 1; }

    int idx = gv_find(ctx, rel_path);
    if (idx < 0) {
        fprintf(stderr, "Not found: %s\n", rel_path);
        gv_close(ctx); return 1;
    }

    uint8_t vbuf[GV_XATTR_VAL_MAX];
    int vsz = gv_xattr_get(ctx, idx, key, vbuf, sizeof(vbuf));
    if (vsz < 0) {
        fprintf(stderr, "Key not found: %s\n", key);
        gv_close(ctx); return 1;
    }

    /* print as string if printable, else hex */
    int printable = 1;
    for (int i = 0; i < vsz; i++)
        if (vbuf[i] < 0x09 || vbuf[i] > 0x7E) { printable = 0; break; }

    if (printable) {
        fwrite(vbuf, 1, (size_t)vsz, stdout);
        putchar('\n');
    } else {
        printf("(hex) ");
        for (int i = 0; i < vsz; i++) printf("%02x", vbuf[i]);
        putchar('\n');
    }

    gv_close(ctx);
    return 0;
}

/* gvault xattr-set <vault> <rel_path> <key> <value>
 *   Sets or replaces an xattr, then persists to vault. */
static int cmd_xattr_set(const char *vault_path, const char *rel_path,
                         const char *key, const char *value) {
    GeoVaultCtx *ctx = gv_open_rw(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open rw: %s\n", vault_path); return 1; }

    int idx = gv_find(ctx, rel_path);
    if (idx < 0) {
        fprintf(stderr, "Not found: %s\n", rel_path);
        gv_close(ctx); return 1;
    }

    uint32_t vsz = (uint32_t)strlen(value);
    int r = gv_xattr_set(ctx, idx, key, (const uint8_t *)value, vsz);
    if (r < 0) {
        fprintf(stderr, "xattr-set failed (full? key too long?): %d\n", r);
        gv_close(ctx); return 1;
    }

    /* persist xattr block */
    r = gv_xattr_save(ctx, vault_path);
    gv_close(ctx);

    if (r < 0) { fprintf(stderr, "xattr-save failed: %d\n", r); return 1; }
    printf("xattr set: %s[%s] = \"%s\"\n", rel_path, key, value);
    return 0;
}

/* gvault mime-scan <vault>
 *   Decompress first frame of each file (or use mmap pointer),
 *   run gv_mime_sniff, print table.
 *   Uses MADV_RANDOM — random access, one frame per file. */
static int cmd_mime_scan(const char *vault_path) {
    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open: %s\n", vault_path); return 1; }

    gv_hint_random(ctx);   /* point lookup per file — don't prefetch linearly */

    printf("%-50s  %s\n", "PATH", "MIME");
    printf("%-50s  %s\n", "----", "----");

    int unknown = 0;
    for (uint32_t i = 0; i < ctx->hdr.n_files; i++) {
        uint8_t *data = gv_extract(ctx, i);
        const char *mime;
        if (data) {
            mime = gv_mime_sniff(data, ctx->entries[i].raw_size);
            free(data);
        } else {
            mime = "application/octet-stream";
            unknown++;
        }

        /* check if xattr already has mime cached */
        char cached[128] = {0};
        if (ctx->xattrs) {
            gv_xattr_get(ctx, (int)i, "mime", (uint8_t *)cached, sizeof(cached)-1);
        }

        /* auto-tag xattr if not set yet */
        if (!cached[0] && ctx->xattr_dirty == 0) {
            gv_xattr_set(ctx, (int)i, "mime",
                         (const uint8_t *)mime, (uint32_t)strlen(mime));
        }

        printf("%-50s  %s\n", ctx->paths[i], mime);
    }

    /* persist if we tagged anything new */
    if (ctx->xattr_dirty)
        gv_xattr_save(ctx, vault_path);

    printf("\n%u files scanned", ctx->hdr.n_files);
    if (unknown) printf("  (%d extract failed)", unknown);
    printf("\n");

    gv_close(ctx);
    return 0;
}

/* gvault put <file.geovault> <src_file> [rel_path]
 *   Adds or replaces a file.  Uses in-place if same/smaller, append otherwise. */
static int cmd_put(const char *vault_path, const char *src_file, const char *rel_path) {
    /* read source file */
    FILE *f = fopen(src_file, "rb");
    if (!f) { fprintf(stderr, "Cannot open: %s\n", src_file); return 1; }
    fseek(f, 0, SEEK_END); uint32_t sz = (uint32_t)ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *data = malloc(sz ? sz : 1);
    if (sz) { size_t r = fread(data, 1, sz, f); (void)r; }
    fclose(f);

    /* default rel_path = basename of src_file */
    if (!rel_path) {
        rel_path = strrchr(src_file, '/');
        rel_path = rel_path ? rel_path + 1 : src_file;
    }

    /* open vault in read+write mode with exclusive lock */
    GeoVaultCtx *ctx = gv_open_rw(vault_path);
    if (!ctx) { free(data); fprintf(stderr, "Cannot open vault: %s\n", vault_path); return 1; }

    /* fp is already r+b from gv_open_rw — no need to reopen */

    /* decide strategy */
    int existing = gv_find(ctx, rel_path);
    int r;
    if (existing >= 0 && sz <= ctx->entries[existing].raw_size) {
        /* try in-place first */
        r = gv_update(ctx, rel_path, data, sz);
        if (r == -3) {
            /* compressed grew — fall back to append */
            fprintf(stderr, "gv_put: in-place compressed too large, falling back to append\n");
            r = gv_add(ctx, rel_path, data, sz);
        }
    } else {
        r = gv_add(ctx, rel_path, data, sz);
    }

    free(data);
    gv_close(ctx);

    if (r < 0) { fprintf(stderr, "put failed: %d\n", r); return 1; }
    printf("put: %s → %s  (%u bytes, %s)\n",
           src_file, rel_path, sz,
           (r == 0 && existing < 0) ? "new" :
           (r == 1)                  ? "replaced (append)" : "replaced (in-place)");
    return 0;
}

/* gvault compact <file.geovault>
 *   Rebuild vault, reclaim orphaned frame space. */
static int cmd_compact(const char *vault_path) {
    GeoVaultCtx *ctx = gv_open(vault_path);
    if (!ctx) { fprintf(stderr, "Cannot open: %s\n", vault_path); return 1; }

    /* get file size before */
    fseek(ctx->fp, 0, SEEK_END);
    long before = ftell(ctx->fp);

    int r = gv_compact(ctx, vault_path);
    gv_close(ctx);

    if (r < 0) { fprintf(stderr, "compact failed: %d\n", r); return 1; }

    /* get file size after */
    FILE *f = fopen(vault_path, "rb");
    long after = 0;
    if (f) { fseek(f, 0, SEEK_END); after = ftell(f); fclose(f); }

    printf("compact: %.1f KB → %.1f KB  (saved %.1f KB)\n",
           before/1024.0, after/1024.0, (before-after)/1024.0);
    return 0;
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(int argc, char **argv) {
    if (argc < 3) {
        printf("GeoVault — geometric file container\n");
        printf("  gvault pack         <folder>\n");
        printf("  gvault unpack       <file.geovault> [outdir]\n");
        printf("  gvault list         <file.geovault>\n");
        printf("  gvault verify       <folder> <file.geovault>\n");
        printf("  gvault cat          <file.geovault> <path>\n");
        printf("  gvault put          <file.geovault> <src_file> [rel_path]\n");
        printf("  gvault compact      <file.geovault>\n");
        printf("  gvault xattr-list   <file.geovault> <rel_path>\n");
        printf("  gvault xattr-get    <file.geovault> <rel_path> <key>\n");
        printf("  gvault xattr-set    <file.geovault> <rel_path> <key> <value>\n");
        printf("  gvault mime-scan    <file.geovault>\n");
        return 1;
    }

    const char *cmd = argv[1];
    if      (!strcmp(cmd, "pack")       && argc >= 3) return cmd_pack(argv[2]);
    else if (!strcmp(cmd, "unpack")     && argc >= 3) return cmd_unpack(argv[2], argc>3?argv[3]:NULL);
    else if (!strcmp(cmd, "list")       && argc >= 3) return cmd_list(argv[2]);
    else if (!strcmp(cmd, "verify")     && argc >= 4) return cmd_verify(argv[2], argv[3]);
    else if (!strcmp(cmd, "cat")        && argc >= 4) return cmd_cat(argv[2], argv[3]);
    else if (!strcmp(cmd, "put")        && argc >= 4) return cmd_put(argv[2], argv[3], argc>4?argv[4]:NULL);
    else if (!strcmp(cmd, "compact")    && argc >= 3) return cmd_compact(argv[2]);
    else if (!strcmp(cmd, "xattr-list") && argc >= 4) return cmd_xattr_list(argv[2], argv[3]);
    else if (!strcmp(cmd, "xattr-get")  && argc >= 5) return cmd_xattr_get(argv[2], argv[3], argv[4]);
    else if (!strcmp(cmd, "xattr-set")  && argc >= 6) return cmd_xattr_set(argv[2], argv[3], argv[4], argv[5]);
    else if (!strcmp(cmd, "mime-scan")  && argc >= 3) return cmd_mime_scan(argv[2]);
    else { fprintf(stderr, "Unknown command or wrong args: %s\n", cmd); return 1; }
}
