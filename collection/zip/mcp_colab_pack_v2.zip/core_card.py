"""
core_card.py — Universal CoreCard schema
========================================
MCP server รู้จักแค่ CoreCard fields
Extensions เป็น deck-specific payload

CoreCard:
  entropy           0-255  (ทุก deck ต้องมี)
  stability         0-255
  locality          0-255
  fingerprint       xxh64 int
  version           int (monotonic)
  parent_version    int
  author            str  (model_key หรือ user id)
  timestamp         int  (unix)
  card_schema_version  str  e.g. "zonecard-v2", "intentcard-v1"
  deck              str  prefix namespace
  extensions        dict  (deck-specific, MCP ไม่ parse)
"""

from __future__ import annotations
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional


CORE_CARD_VERSION = "1.0"


@dataclass
class CoreCard:
    # ── Required core fields ──
    deck: str
    author: str
    card_schema_version: str

    # ── Stats (required, 0-255) ──
    entropy: int = 128
    stability: int = 128
    locality: int = 128

    # ── Identity ──
    fingerprint: int = 0
    version: int = 1
    parent_version: int = 0
    timestamp: int = field(default_factory=lambda: int(time.time()))

    # ── Deck-specific payload (MCP ignores) ──
    extensions: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "CoreCard":
        return cls(
            deck=d["deck"],
            author=d["author"],
            card_schema_version=d["card_schema_version"],
            entropy=d.get("entropy", 128),
            stability=d.get("stability", 128),
            locality=d.get("locality", 128),
            fingerprint=d.get("fingerprint", 0),
            version=d.get("version", 1),
            parent_version=d.get("parent_version", 0),
            timestamp=d.get("timestamp", int(time.time())),
            extensions=d.get("extensions", {}),
        )

    def validate(self) -> Optional[str]:
        """Returns error string or None if valid."""
        for f in ("entropy", "stability", "locality"):
            v = getattr(self, f)
            if not (0 <= v <= 255):
                return f"{f}={v} out of range 0-255"
        if not self.deck:
            return "deck is required"
        if not self.card_schema_version:
            return "card_schema_version is required"
        return None


# ── DeckManifest ──

@dataclass
class DeckManifest:
    deck: str
    schema: str            # e.g. "zonecard-v2"
    ruleset: str           # e.g. "route-v46"
    version: int = 1
    description: str = ""
    adapter_from: list = field(default_factory=list)  # decks this can adapt from

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "DeckManifest":
        return cls(
            deck=d["deck"],
            schema=d["schema"],
            ruleset=d["ruleset"],
            version=d.get("version", 1),
            description=d.get("description", ""),
            adapter_from=d.get("adapter_from", []),
        )


# ── Built-in extractors ──

def extract_local(weights, zone_id: int = 0,
                  prev_weights=None,
                  model_key: str = "local") -> CoreCard:
    """
    Extract CoreCard from local weight matrix (numpy array).
    extensions: card_type, pattern, locality_raw
    """
    import numpy as np

    flat = weights.flatten().astype(np.float32)

    # Entropy: normalized Shannon-like from histogram
    hist, _ = np.histogram(flat, bins=256, range=(-4, 4), density=True)
    hist = hist + 1e-10
    ent_raw = -float(np.sum(hist * np.log2(hist + 1e-10)))
    entropy = min(255, int(ent_raw / 8.0 * 255))

    # Stability: cosine distance from prev snapshot
    if prev_weights is not None:
        prev_flat = prev_weights.flatten().astype(np.float32)
        n = min(len(flat), len(prev_flat))
        dot = float(np.dot(flat[:n], prev_flat[:n]))
        na = float(np.linalg.norm(flat[:n])) + 1e-10
        nb = float(np.linalg.norm(prev_flat[:n])) + 1e-10
        stability = int((dot / (na * nb) + 1) / 2 * 255)
    else:
        stability = 128

    # Locality: zone_id normalized
    locality = min(255, int(zone_id / 12 * 255))

    # Fingerprint
    try:
        import xxhash
        fp = xxhash.xxh64(weights.tobytes()).intdigest()
    except ImportError:
        fp = hash(weights.tobytes()) & 0xFFFFFFFFFFFFFFFF

    # Pattern: top-8 sign bits of mean per row
    row_means = weights.mean(axis=1) if len(weights.shape) > 1 else weights[:8]
    pattern = 0
    for i, v in enumerate(row_means[:8]):
        if v > 0:
            pattern |= (1 << i)

    return CoreCard(
        deck="local",
        author=model_key,
        card_schema_version="zonecard-v2",
        entropy=entropy,
        stability=stability,
        locality=locality,
        fingerprint=fp,
        extensions={
            "zone_id": zone_id,
            "pattern": pattern,
            "shape": weights.shape,
        },
    )


def extract_cloud(logits=None,
                  embedding=None,
                  prev_embedding=None,
                  author: str = "cloud",
                  deck: str = "cloud") -> CoreCard:
    """
    Extract CoreCard from cloud model output.
    extensions: confidence, embedding_hash, semantic_distance, route_class
    """
    import numpy as np

    # Entropy from logits distribution
    if logits is not None:
        logits_arr = np.array(logits, dtype=np.float32)
        probs = np.exp(logits_arr - logits_arr.max())
        probs = probs / probs.sum()
        ent_raw = -float(np.sum(probs * np.log2(probs + 1e-10)))
        entropy = min(255, int(ent_raw / np.log2(len(probs) + 1) * 255))
        confidence = int(float(probs.max()) * 255)
    else:
        entropy = 128
        confidence = 128

    # Stability from semantic distance between embeddings
    if embedding is not None and prev_embedding is not None:
        emb = np.array(embedding, dtype=np.float32)
        prev_emb = np.array(prev_embedding, dtype=np.float32)
        n = min(len(emb), len(prev_emb))
        dot = float(np.dot(emb[:n], prev_emb[:n]))
        na = float(np.linalg.norm(emb[:n])) + 1e-10
        nb = float(np.linalg.norm(prev_emb[:n])) + 1e-10
        sem_dist = 1.0 - dot / (na * nb)
        stability = max(0, min(255, int((1 - sem_dist) * 255)))
        semantic_distance = round(sem_dist, 4)
    else:
        stability = 128
        semantic_distance = 0.0

    # Embedding hash
    if embedding is not None:
        emb_arr = np.array(embedding, dtype=np.float32)
        try:
            import xxhash
            emb_hash = xxhash.xxh64(emb_arr.tobytes()).intdigest()
        except ImportError:
            emb_hash = hash(emb_arr.tobytes()) & 0xFFFFFFFFFFFFFFFF
    else:
        emb_hash = 0

    # Route class from entropy bucket
    if entropy < 64:
        route_class = "sparse"
    elif entropy < 160:
        route_class = "batch"
    else:
        route_class = "lz"

    return CoreCard(
        deck=deck,
        author=author,
        card_schema_version="intentcard-v1",
        entropy=entropy,
        stability=stability,
        locality=128,  # cloud has no geometric locality
        fingerprint=emb_hash,
        extensions={
            "confidence": confidence,
            "embedding_hash": emb_hash,
            "semantic_distance": semantic_distance,
            "route_class": route_class,
        },
    )


# ── Cross-deck adapter ──

ADAPTERS: dict[tuple, callable] = {}


def register_adapter(from_schema: str, to_schema: str):
    """Decorator to register a cross-deck adapter."""
    def decorator(fn):
        ADAPTERS[(from_schema, to_schema)] = fn
        return fn
    return decorator


def adapt_card(card: CoreCard, target_schema: str) -> Optional[CoreCard]:
    """Translate card to target schema if adapter exists."""
    fn = ADAPTERS.get((card.card_schema_version, target_schema))
    if fn is None:
        return None
    return fn(card)


# ── Built-in adapters ──

@register_adapter("zonecard-v2", "intentcard-v1")
def zonecard_to_intentcard(card: CoreCard) -> CoreCard:
    ext = card.extensions
    route_class = "sparse" if card.entropy < 64 else \
                  "batch" if card.entropy < 160 else "lz"
    return CoreCard(
        deck="cloud",
        author=card.author,
        card_schema_version="intentcard-v1",
        entropy=card.entropy,
        stability=card.stability,
        locality=card.locality,
        fingerprint=card.fingerprint,
        version=card.version,
        parent_version=card.parent_version,
        extensions={
            "confidence": card.stability,  # proxy
            "embedding_hash": card.fingerprint,
            "semantic_distance": round(1 - card.stability / 255, 4),
            "route_class": route_class,
            "adapted_from": "zonecard-v2",
        },
    )


@register_adapter("intentcard-v1", "zonecard-v2")
def intentcard_to_zonecard(card: CoreCard) -> CoreCard:
    ext = card.extensions
    ct = {"sparse": 0, "batch": 1, "lz": 2}.get(
        ext.get("route_class", "batch"), 1)
    return CoreCard(
        deck="local",
        author=card.author,
        card_schema_version="zonecard-v2",
        entropy=card.entropy,
        stability=card.stability,
        locality=card.locality,
        fingerprint=card.fingerprint,
        version=card.version,
        parent_version=card.parent_version,
        extensions={
            "card_type": ct,
            "pattern": 0,
            "zone_id": 0,
            "adapted_from": "intentcard-v1",
        },
    )
