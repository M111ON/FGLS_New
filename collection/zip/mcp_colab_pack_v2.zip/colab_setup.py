# ═══════════════════════════════════════════
# CELL 1 — Install
# ═══════════════════════════════════════════
# !pip install fastapi uvicorn pydantic gguf numpy xxhash nest_asyncio

# ═══════════════════════════════════════════
# CELL 2 — Upload zip + extract
# ═══════════════════════════════════════════
# from google.colab import files
# uploaded = files.upload()  # upload mcp_colab_pack.zip
# !unzip -q mcp_colab_pack.zip -d /content/mcp
# %cd /content/mcp

# ═══════════════════════════════════════════
# CELL 3 — Download GGUF models
# ═══════════════════════════════════════════
# !mkdir -p /content/models
# SmolLM2 360M F16
# !wget -q -P /content/models/ https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct-GGUF/resolve/main/SmolLM2-360M-Instruct-F16.gguf
# qwen25coder (ถ้าต้องการ)
# !wget -q -P /content/models/ https://huggingface.co/Qwen/Qwen2.5-Coder-0.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-0.5b-instruct-fp16.gguf

# ═══════════════════════════════════════════
# CELL 4 — Build stores
# ═══════════════════════════════════════════
# !python build_scripts/build_smollm2_store.py \
#     --gguf /content/models/SmolLM2-360M-Instruct-F16.gguf \
#     --out  /content/stores/smollm2

# ═══════════════════════════════════════════
# CELL 5 — Run MCP server (background)
# ═══════════════════════════════════════════
# import nest_asyncio, uvicorn, threading
# nest_asyncio.apply()
# import mcp_server_v2 as app_module
# def _run(): uvicorn.run(app_module.app, host="0.0.0.0", port=8765)
# threading.Thread(target=_run, daemon=True).start()
# import time; time.sleep(2); print("MCP server up at :8765")

# ═══════════════════════════════════════════
# CELL 6 — Run scenario test
# ═══════════════════════════════════════════
# !python test_v2_scenario.py

# ═══════════════════════════════════════════
# CELL 7 — Stress test (scale)
# ═══════════════════════════════════════════
# !python stress_test.py --cards 10000 --workers 8
