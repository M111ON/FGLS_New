"""
mcp_server_v2.py — ZoneCard MCP Server v2
==========================================
CoreCard + Deck + Versioning + Event Store + Push/Reject
"""
from __future__ import annotations
import asyncio, json, os, threading, time
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel

STATE_DIR = Path(os.environ.get("MCP_STATE_DIR", "./mcp_state_v2"))
STATE_DIR.mkdir(exist_ok=True)

_lock = threading.RLock()
cards: Dict[str, dict] = {}
events: List[dict] = []
deck_manifests: Dict[str, dict] = {}
exact_cache: Dict[str, dict] = {}
fusion_table: Dict[str, dict] = {}
_global_version = 0
_hits = 0
_misses = 0

def _load_state():
    global cards, events, deck_manifests, exact_cache, fusion_table, _global_version
    files = {
        "cards": STATE_DIR/"cards.json",
        "events": STATE_DIR/"events.json",
        "deck_manifests": STATE_DIR/"decks.json",
        "exact_cache": STATE_DIR/"exact_cache.json",
        "fusion_table": STATE_DIR/"fusion_table.json",
    }
    for name, path in files.items():
        if path.exists():
            try:
                with open(path) as f: data = json.load(f)
                if isinstance(data, list): globals()[name].extend(data)
                else: globals()[name].update(data)
                print(f"[MCPv2] {name}: {len(data)} entries")
            except Exception as e:
                print(f"[MCPv2] warn {path}: {e}")
    if events:
        _global_version = max(e.get("version", 0) for e in events)

def _save_state():
    files = {
        "cards": STATE_DIR/"cards.json",
        "events": STATE_DIR/"events.json",
        "deck_manifests": STATE_DIR/"decks.json",
        "exact_cache": STATE_DIR/"exact_cache.json",
        "fusion_table": STATE_DIR/"fusion_table.json",
    }
    with _lock:
        for name, path in files.items():
            try:
                with open(path, "w") as f: json.dump(globals()[name], f, indent=2)
            except Exception as e:
                print(f"[MCPv2] save warn {path}: {e}")

def _validate_core(card: dict) -> Optional[str]:
    for field in ("entropy", "stability", "locality"):
        v = card.get(field, 128)
        if not (0 <= v <= 255): return f"{field}={v} out of range"
    if not card.get("deck"): return "deck required"
    if not card.get("card_schema_version"): return "card_schema_version required"
    if not card.get("author"): return "author required"
    return None

RULES = [
    dict(priority=91, ct=-1, loc_min=220, decision="cascade-reuse", action="reuse_state"),
    dict(priority=90, ct=-1, loc_min=180, st_min=200, decision="cascade-merge", action="merge_state"),
    dict(priority=85, ct=-1, ent_min=220, st_max=30, decision="crash-plan", action="full_decode"),
    dict(priority=83, ct=0, ent_max=30, st_min=200, decision="skip", action="noop"),
    dict(priority=82, ct=0, ent_max=30, st_min=100, decision="sparse-skip", action="noop"),
    dict(priority=81, ct=0, ent_max=30, decision="sparse-verify", action="sparse_verify"),
    dict(priority=80, ct=0, ent_min=31, ent_max=127, st_min=200, decision="sparse-route", action="sparse_decode"),
    dict(priority=76, ct=1, ent_max=30, st_min=200, decision="batch-skip", action="noop"),
    dict(priority=75, ct=1, ent_max=127, st_min=150, decision="batch-route", action="batch_read"),
    dict(priority=73, ct=1, ent_min=128, st_min=200, decision="batch-full", action="batch_read"),
    dict(priority=70, ct=2, ent_max=30, st_min=200, decision="lz-skip", action="noop"),
    dict(priority=65, ct=2, ent_max=199, st_min=200, decision="lz-route", action="lz_decompress"),
    dict(priority=64, ct=2, ent_max=199, decision="lz-verify", action="lz_verify"),
    dict(priority=1,  ct=-1, decision="fallback", action="full_read"),
]
RULES.sort(key=lambda r: -r["priority"])

def _resolve(card_type, entropy, locality, stability, hash_val=0):
    global _hits, _misses
    hk = str(hash_val)
    if hash_val and hk in exact_cache:
        _hits += 1
        return {**exact_cache[hk], "cache": "exact"}
    for r in RULES:
        ct = r.get("ct", -1)
        if ct >= 0 and card_type != ct: continue
        if not (r.get("ent_min",0) <= entropy <= r.get("ent_max",255)): continue
        if not (r.get("loc_min",0) <= locality <= r.get("loc_max",255)): continue
        if not (r.get("st_min",0) <= stability <= r.get("st_max",255)): continue
        _hits += 1
        return {"decision": r["decision"], "action": r["action"],
                "cache": "rule", "priority": r["priority"]}
    _misses += 1
    return {"decision": "planner", "action": "call_llm", "cache": "miss"}

def _similarity(a: dict, b: dict) -> float:
    score = 0.0
    if a.get("card_schema_version") == b.get("card_schema_version"): score += 0.10
    if a.get("card_type") == b.get("card_type"): score += 0.30
    score += 0.20 * max(0, 1 - abs(a.get("entropy",128)-b.get("entropy",128))/50)
    score += 0.15 * max(0, 1 - abs(a.get("locality",128)-b.get("locality",128))/100)
    score += 0.10 * max(0, 1 - abs(a.get("stability",128)-b.get("stability",128))/100)
    if a.get("fingerprint") and a.get("fingerprint") == b.get("fingerprint"): score += 0.15
    return min(score, 1.0)

app = FastAPI(title="ZoneCard MCP v2", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
async def startup(): _load_state()

@app.on_event("shutdown")
async def shutdown(): _save_state()

@app.get("/sse")
async def sse(request: Request):
    manifest = {"name":"zonecard-mcp-v2","version":"2.0.0","description":"CoreCard MCP — universal AI state bridge"}
    async def stream():
        yield f"event: endpoint\ndata: /messages\n\n"
        yield f"event: manifest\ndata: {json.dumps(manifest)}\n\n"
        while not await request.is_disconnected():
            yield ": keepalive\n\n"
            await asyncio.sleep(15)
    return StreamingResponse(stream(), media_type="text/event-stream")

# ── Push ──
class PushReq(BaseModel):
    key: str
    card: dict
    base_version: int = 0

@app.post("/cards/push")
async def push(req: PushReq):
    global _global_version
    err = _validate_core(req.card)
    if err:
        return JSONResponse({"ok": False, "error": err}, status_code=400)
    with _lock:
        existing = cards.get(req.key)
        if existing:
            sv = existing.get("version", 0)
            if req.base_version < sv:
                return JSONResponse({
                    "ok": False, "error": "version_conflict",
                    "server_version": sv, "your_base": req.base_version,
                    "hint": f"pull v{sv} and rebase first",
                }, status_code=409)
        _global_version += 1
        new_card = {**req.card, "version": _global_version,
                    "parent_version": req.base_version,
                    "server_timestamp": int(time.time())}
        cards[req.key] = new_card
        events.append({
            "version": _global_version, "key": req.key,
            "author": req.card.get("author","?"),
            "deck": req.card.get("deck",""),
            "card_schema_version": req.card.get("card_schema_version",""),
            "parent_version": req.base_version,
            "fingerprint": req.card.get("fingerprint",0),
            "timestamp": int(time.time()),
        })
        # fusion update
        fk = ":".join(req.key.split(":")[:3])
        if fk not in fusion_table: fusion_table[fk] = {}
        author = req.card.get("author","")
        for pk, pc in cards.items():
            if pk == req.key: continue
            if pc.get("deck") != req.card.get("deck"): continue
            sim = _similarity(new_card, pc)
            if sim >= 0.75:
                fusion_table[fk][author] = {"similarity": sim, "peer": pc.get("author",""), "version": _global_version}
    _save_state()
    return JSONResponse({"ok": True, "version": _global_version})

# ── Pull ──
class PullReq(BaseModel):
    since_version: int = 0
    deck: str = ""

@app.post("/cards/pull")
async def pull(req: PullReq):
    with _lock:
        evs = [e for e in events
               if e["version"] > req.since_version
               and (not req.deck or e.get("deck") == req.deck)]
        result = {e["key"]: cards[e["key"]] for e in evs if e["key"] in cards}
    return JSONResponse({"cards": result, "events": evs,
                         "latest_version": _global_version, "count": len(result)})

# ── Get card ──
@app.get("/cards/{deck}/{key:path}")
async def get_card(deck: str, key: str):
    full = f"{deck}:{key}"
    with _lock:
        card = cards.get(full) or cards.get(key)
    if not card: raise HTTPException(404, f"not found: {full}")
    return JSONResponse({"found": True, "card": card})

# ── Resolve route ──
class RouteReq(BaseModel):
    card_type: int = 1
    entropy: int = 128
    locality: int = 128
    stability: int = 128
    hash_val: int = 0

@app.post("/tools/resolve_route")
async def resolve_route(req: RouteReq):
    return JSONResponse(_resolve(req.card_type, req.entropy,
                                 req.locality, req.stability, req.hash_val))

# ── Fusion peer ──
class FusionReq(BaseModel):
    key: str
    threshold: float = 0.75

@app.post("/tools/get_fusion_peer")
async def fusion_peer(req: FusionReq):
    fk = ":".join(req.key.split(":")[:3])
    with _lock:
        entries = fusion_table.get(fk, {})
    best = max(entries.items(), key=lambda x: x[1].get("similarity",0), default=None)
    if not best or best[1].get("similarity",0) < req.threshold:
        return JSONResponse({"found": False})
    return JSONResponse({"found": True, "peer": best[1].get("peer"), "similarity": best[1]["similarity"]})

# ── Decks ──
class DeckReq(BaseModel):  # type: ignore
    deck: str; schema: str; ruleset: str
    version: int = 1; description: str = ""; adapter_from: list = []

@app.get("/decks")
async def list_decks():
    return JSONResponse({"decks": deck_manifests})

@app.post("/decks")
async def reg_deck(req: DeckReq):
    with _lock: deck_manifests[req.deck] = req.dict()
    _save_state()
    return JSONResponse({"registered": True, "deck": req.deck})

# ── Adapt ──
class AdaptReq(BaseModel):
    card: dict; target_schema: str

@app.post("/adapt")
async def adapt(req: AdaptReq):
    try:
        import sys; sys.path.insert(0, "/home/claude")
        from core_card import CoreCard, adapt_card as _adapt
        src = CoreCard.from_dict(req.card)
        result = _adapt(src, req.target_schema)
        if result is None:
            return JSONResponse({"ok": False, "error": f"no adapter {src.card_schema_version}→{req.target_schema}"}, status_code=400)
        return JSONResponse({"ok": True, "card": result.to_dict()})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

# ── Events ──
@app.get("/events")
async def get_events(since: int = 0, deck: str = ""):
    with _lock:
        evs = [e for e in events if e["version"] > since and (not deck or e.get("deck") == deck)]
    return JSONResponse({"events": evs, "latest_version": _global_version})

# ── Stats ──
@app.get("/tools/cache_stats")
async def stats():
    total = _hits + _misses
    with _lock:
        return JSONResponse({
            "hits": _hits, "misses": _misses,
            "hit_rate": round(_hits/max(total,1)*100,1),
            "cards": len(cards), "events": len(events),
            "decks": list(deck_manifests.keys()),
            "global_version": _global_version,
        })

# ── Reset ──
@app.post("/admin/reset")
async def reset():
    global cards, events, deck_manifests, exact_cache, fusion_table, _global_version, _hits, _misses
    with _lock:
        cards.clear(); events.clear(); deck_manifests.clear()
        exact_cache.clear(); fusion_table.clear()
        _global_version = 0; _hits = 0; _misses = 0
    _save_state()
    return JSONResponse({"reset": True})

# ── Dispatcher ──
@app.post("/messages")
async def messages(request: Request):
    body = await request.json()
    tool = body.get("tool") or body.get("name")
    p = body.get("input") or body.get("params") or {}
    if tool == "push_card": return await push(PushReq(**p))
    if tool == "pull_cards": return await pull(PullReq(**p))
    if tool == "resolve_route": return await resolve_route(RouteReq(**p))
    if tool == "get_fusion_peer": return await fusion_peer(FusionReq(**p))
    if tool == "register_deck": return await reg_deck(DeckReq(**p))
    if tool == "adapt_card": return await adapt(AdaptReq(**p))
    return JSONResponse({"error": f"unknown: {tool}"}, status_code=400)

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("MCP_PORT", 8765))
    print(f"[MCPv2] port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port)
