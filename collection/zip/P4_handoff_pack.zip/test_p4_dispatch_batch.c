/*
 * test_p4_dispatch_batch.c — P4 batch dispatch logic test (self-contained)
 * =========================================================================
 * Mocks: TGWCtx/tgw_write/tgw_batch, PayloadStore, FtsTwinStore,
 *        LCTwinGateCtx, geomatrix_batch_verdict, GBBlueprint, TStreamPkt
 *
 * Tests:
 *   T1: GROUND bypass (polarity=1 → pl_write, skip tgw_write)
 *   T2: ROUTE batch accumulate (N pkts → tgw_batch called once when full)
 *   T3: tgw_dispatch_flush drains remainder
 *   T4: batch boundary (exactly 64 pkts → 1 flush, 65 pkts → 2 flushes)
 *   T5: tgwlc_prefilter bitmask matches polarity math
 *   T6: spoke histogram uniform distribution (GEO_WALK encodes 0..719)
 *   T7: mixed GROUND+ROUTE stream — counts consistent
 *   T8: verdict=false → GROUND fallback, flushes pending batch first
 *
 * Compile: gcc -O2 -Wall -o test_p4 test_p4_dispatch_batch.c && ./test_p4
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>

/* ══════════════════════════════════════════════════════════════════
   SACRED CONSTANTS (frozen — match POGLS spec)
   ══════════════════════════════════════════════════════════════════ */
#define TRING_CYCLE        720u
#define PENT_SPAN           60u
#define MIRROR_HALF         30u
#define TRING_SPOKES         6u
#define TSTREAM_DATA_BYTES 4096u
#define TSTREAM_MAX_PKTS   720u
#define GEO_BUNDLE_WORDS     8u
#define TGW_DISPATCH_BATCH_MAX 64u
#define GEOMATRIX_PATHS     18u
#define GEO_SLOTS          576u
#define GEO_BLOCK_BOUNDARY 288u
#define GEO_WINDOW_LO      128
#define GEO_WINDOW_HI      144

/* ══════════════════════════════════════════════════════════════════
   MOCK TYPES
   ══════════════════════════════════════════════════════════════════ */

/* GEO_WALK mock — enc[i] = i * 37 % 720 (deterministic, covers 0..719) */
static uint32_t _mock_geo_walk[720];
static void _init_geo_walk(void) {
    for (int i = 0; i < 720; i++)
        _mock_geo_walk[i] = (uint32_t)((i * 37u) % TRING_CYCLE);
}
#define GEO_WALK _mock_geo_walk

typedef struct { uint32_t enc; uint16_t size; uint16_t crc16;
                 uint8_t data[TSTREAM_DATA_BYTES]; } TStreamPkt;

typedef struct { uint64_t stamp_hash; uint64_t spatial_xor;
                 uint32_t window_id; uint32_t circuit_fired;
                 uint32_t tring_start; uint32_t tring_end;
                 uint32_t tring_span; uint8_t top_gaps[4]; } GBBlueprint;

typedef struct { bool blueprint_ready; GBBlueprint bp; } GoldbergPipeResult;
typedef struct { GoldbergPipeResult gpr; uint32_t ev; } TGWResult;

/* mock counters */
static uint32_t _mock_tgw_write_calls   = 0;
static uint32_t _mock_tgw_batch_calls   = 0;
static uint32_t _mock_tgw_batch_total_n = 0;
static uint32_t _mock_pl_write_calls    = 0;
static uint32_t _mock_fts_write_calls   = 0;
static bool     _mock_verdict_result    = true;   /* control verdict */
static bool     _mock_bp_ready          = true;   /* control blueprint */

/* PayloadStore mock */
typedef struct { uint32_t writes; } PayloadStore;
static inline void pl_init(PayloadStore *ps) { ps->writes = 0; }
static inline void pl_write(PayloadStore *ps, uint64_t a, uint64_t v) {
    (void)a; (void)v; ps->writes++; _mock_pl_write_calls++;
}

/* FtsTwinStore mock */
typedef struct { uint32_t writes; } FtsTwinStore;
typedef struct { uint32_t writes; } FtsTwinStats;
static inline void fts_init(FtsTwinStore *f, uint64_t s) { (void)s; f->writes=0; }
typedef struct { uint64_t merkle_root,sha256_hi,sha256_lo;
                 uint32_t offset,hop_count,segment; } DodecaEntry;
static inline void fts_write(FtsTwinStore *f, uint64_t a, uint64_t v,
                              const DodecaEntry *e) {
    (void)a;(void)v;(void)e; f->writes++; _mock_fts_write_calls++;
}
static inline FtsTwinStats fts_stats(const FtsTwinStore *f) {
    FtsTwinStats s; s.writes=f->writes; return s;
}

/* LCTwinGateCtx mock */
typedef enum { LC_GATE_WARP=0,LC_GATE_ROUTE=1,
               LC_GATE_COLLISION=2,LC_GATE_GROUND=3 } LCGate;
typedef struct { uint8_t sign,mag,rgb,level,angle,letter; uint16_t slope; } LCHdr;
typedef struct { uint32_t gate_counts[4]; uint64_t palette_a,palette_b; } LCTwinGateCtx;
static inline void lc_twin_gate_init(LCTwinGateCtx *lc) { memset(lc,0,sizeof(*lc)); }
static inline LCHdr lc_hdr_encode_addr(uint64_t a) {
    LCHdr h={0}; h.sign=(uint8_t)((a>>63)&1); return h;
}
static inline LCHdr lc_hdr_encode_value(uint64_t v) {
    LCHdr h={0}; h.sign=(uint8_t)((v>>62)&1); return h;
}
static inline LCGate lch_gate(LCHdr hA, LCHdr hB, uint64_t pa, uint64_t pb) {
    (void)pa;(void)pb;
    /* mock: GROUND only if both signs set (complement-like) */
    if (hA.sign && hB.sign) return LC_GATE_GROUND;
    return LC_GATE_ROUTE;
}

/* TGWCtx mock */
typedef struct {
    uint32_t total_writes;
    uint64_t _bundle[GEO_BUNDLE_WORDS];
    uint32_t stream_pkts_rx;
    uint32_t stream_gaps;
    uint32_t blueprint_count;
} TGWCtx;

static inline void tgw_init(TGWCtx *ctx, uint64_t seed) {
    memset(ctx,0,sizeof(*ctx));
    for(int i=0;i<(int)GEO_BUNDLE_WORDS;i++) ctx->_bundle[i]=seed^(uint64_t)i;
}

static inline TGWResult tgw_write(TGWCtx *ctx, uint64_t a, uint64_t v, uint8_t s) {
    (void)a;(void)v;(void)s;
    _mock_tgw_write_calls++;
    ctx->total_writes++;
    TGWResult r={0};
    r.gpr.blueprint_ready = _mock_bp_ready;
    if (_mock_bp_ready) {
        r.gpr.bp.stamp_hash    = a ^ v;
        r.gpr.bp.tring_end     = ctx->total_writes % GEO_SLOTS;
        r.gpr.bp.tring_start   = (ctx->total_writes + 10) % GEO_SLOTS;
        r.gpr.bp.circuit_fired = ctx->total_writes & 0x3u;
        ctx->blueprint_count++;
    }
    return r;
}

static inline void tgw_batch(TGWCtx *ctx, const uint64_t *addrs,
                              const uint64_t *vals, uint32_t n, uint8_t s) {
    (void)addrs;(void)vals;(void)s;
    _mock_tgw_batch_calls++;
    _mock_tgw_batch_total_n += n;
    ctx->total_writes += n;
}

/* GeoPacket + geomatrix mock */
typedef struct { uint8_t phase,bit; uint16_t hpos,idx; uint64_t sig; } GeoPacket;
typedef struct { uint64_t total_packets,sig_mismatches,
                          hilbert_violations,stable_batches; } GeomatrixStatsV3;

static inline uint64_t geo_compute_sig64(const uint64_t *b, uint8_t ph) {
    return b[ph & (GEO_BUNDLE_WORDS-1)] ^ ((uint64_t)ph << 32);
}
static inline bool geomatrix_batch_verdict(const GeoPacket *pkts,
                                            const uint64_t *b,
                                            GeomatrixStatsV3 *s) {
    (void)pkts;(void)b;(void)s; return _mock_verdict_result;
}

/* ══════════════════════════════════════════════════════════════════
   P4 LOGIC UNDER TEST (inlined — mirrors tgw_dispatch.h exactly)
   ══════════════════════════════════════════════════════════════════ */

typedef struct {
    FtsTwinStore fts;
    PayloadStore ps;
    LCTwinGateCtx lc;
    uint64_t pending_addrs[TGW_DISPATCH_BATCH_MAX];
    uint64_t pending_vals [TGW_DISPATCH_BATCH_MAX];
    uint32_t pending_n;
    uint32_t total_dispatched;
    uint32_t route_count;
    uint32_t ground_count;
    uint32_t verdict_fail;
    uint32_t no_blueprint;
    uint32_t batch_flushes;
} TGWDispatch;

static inline void tgw_dispatch_init(TGWDispatch *d, uint64_t seed) {
    memset(d,0,sizeof(*d));
    fts_init(&d->fts, seed); pl_init(&d->ps); lc_twin_gate_init(&d->lc);
}

static inline void _tgwd_flush_batch(TGWDispatch *d, TGWCtx *ctx) {
    if (!d->pending_n) return;
    tgw_batch(ctx, d->pending_addrs, d->pending_vals, d->pending_n, 0);
    d->pending_n = 0;
    d->batch_flushes++;
}

static GeoPacket _tgwd_bp_to_pkt(const GBBlueprint *bp,
                                   const uint64_t *bundle, uint8_t pid) {
    GeoPacket pkt={0};
    pkt.phase = (uint8_t)((bp->circuit_fired + pid) & 0x3u);
    pkt.sig   = geo_compute_sig64(bundle, pkt.phase);
    uint16_t h_end   = (uint16_t)(bp->tring_end   % GEO_SLOTS);
    uint16_t h_start = (uint16_t)(bp->tring_start % GEO_SLOTS);
    pkt.hpos = h_end;
    bool hb = (h_end >= GEO_BLOCK_BOUNDARY), ib = (h_start >= GEO_BLOCK_BOUNDARY);
    pkt.idx = (hb!=ib) ? (hb ? (uint16_t)(h_start+GEO_BLOCK_BOUNDARY)
                              : (uint16_t)(h_start%GEO_BLOCK_BOUNDARY)) : h_start;
    pkt.bit  = (uint8_t)(bp->stamp_hash & 1u);
    return pkt;
}

static DodecaEntry _tgwd_bp_to_dodeca(const GBBlueprint *bp) {
    DodecaEntry e={0};
    e.merkle_root = bp->stamp_hash | ((uint64_t)bp->stamp_hash<<32);
    e.sha256_hi   = bp->spatial_xor; e.sha256_lo = bp->window_id;
    e.offset      = bp->circuit_fired; e.hop_count = bp->tring_span;
    e.segment     = bp->top_gaps[0];
    return e;
}

static inline void tgw_dispatch(TGWDispatch *d, TGWCtx *ctx,
                                  const TGWResult *r, uint64_t addr,
                                  uint64_t value, const uint64_t *bundle) {
    d->total_dispatched++;
    { /* GROUND gate */
        LCHdr hA=lc_hdr_encode_addr(addr), hB=lc_hdr_encode_value(value);
        LCGate gate=lch_gate(hA,hB,d->lc.palette_a,d->lc.palette_b);
        if (gate==LC_GATE_GROUND) {
            pl_write(&d->ps,addr,value);
            d->lc.gate_counts[LC_GATE_GROUND]++;
            d->ground_count++; return;
        }
    }
    if (!r->gpr.blueprint_ready) {
        d->no_blueprint++;
        d->pending_addrs[d->pending_n]=addr;
        d->pending_vals [d->pending_n]=value;
        d->pending_n++;
        if (d->pending_n>=TGW_DISPATCH_BATCH_MAX) _tgwd_flush_batch(d,ctx);
        return;
    }
    const GBBlueprint *bp=&r->gpr.bp;
    GeoPacket batch[GEOMATRIX_PATHS];
    for (int p=0;p<(int)GEOMATRIX_PATHS;p++) batch[p]=_tgwd_bp_to_pkt(bp,bundle,(uint8_t)p);
    GeomatrixStatsV3 st={0};
    bool verdict=geomatrix_batch_verdict(batch,bundle,&st);
    if (verdict) {
        d->pending_addrs[d->pending_n]=addr;
        d->pending_vals [d->pending_n]=value;
        d->pending_n++;
        if (d->pending_n>=TGW_DISPATCH_BATCH_MAX) _tgwd_flush_batch(d,ctx);
        DodecaEntry e=_tgwd_bp_to_dodeca(bp);
        fts_write(&d->fts,(uint64_t)bp->stamp_hash,(uint64_t)bp->spatial_xor,&e);
        d->route_count++;
    } else {
        _tgwd_flush_batch(d,ctx);
        pl_write(&d->ps,addr,value);
        d->verdict_fail++; d->ground_count++;
    }
}

static inline void tgw_dispatch_flush(TGWDispatch *d, TGWCtx *ctx) {
    _tgwd_flush_batch(d,ctx);
}

/* tgwlc_prefilter — polarity bitmask from enc */
static inline uint64_t tgwlc_prefilter(const TStreamPkt *pkts, uint16_t n) {
    uint64_t mask=0; uint16_t lim=(n>64)?64:n;
    for (uint16_t i=0;i<lim;i++) {
        uint16_t pos=(uint16_t)(pkts[i].enc % TRING_CYCLE);
        if ((pos % PENT_SPAN) >= MIRROR_HALF) mask|=(UINT64_C(1)<<i);
    }
    return mask;
}

/* spoke histogram */
static inline void tgwlc_spoke_hist(const TStreamPkt *pkts, uint16_t n,
                                     uint32_t hist[TRING_SPOKES]) {
    for (int s=0;s<(int)TRING_SPOKES;s++) hist[s]=0;
    for (uint16_t i=0;i<n;i++) {
        uint16_t pos=(uint16_t)(pkts[i].enc % TRING_CYCLE);
        hist[(pos/PENT_SPAN)%TRING_SPOKES]++;
    }
}

/* ══════════════════════════════════════════════════════════════════
   TEST RUNNER
   ══════════════════════════════════════════════════════════════════ */
static int _pass=0, _fail=0;
#define CHECK(cond, msg) do { \
    if (cond) { printf("  PASS  %s\n", msg); _pass++; } \
    else      { printf("  FAIL  %s\n", msg); _fail++; } \
} while(0)

static void reset_mocks(void) {
    _mock_tgw_write_calls=0; _mock_tgw_batch_calls=0;
    _mock_tgw_batch_total_n=0; _mock_pl_write_calls=0;
    _mock_fts_write_calls=0;
    _mock_verdict_result=true; _mock_bp_ready=true;
}

/* ── T1: GROUND bypass ─────────────────────────────────────────── */
static void test_t1_ground_bypass(void) {
    printf("\nT1: GROUND bypass (addr/val with both sign bits → pl_write)\n");
    reset_mocks();
    TGWCtx ctx; tgw_init(&ctx, 0xABCD);
    TGWDispatch d; tgw_dispatch_init(&d, 0xABCD);

    /* set both sign bits → lch_gate returns GROUND */
    uint64_t addr  = UINT64_C(1)<<63 | 0x42;
    uint64_t value = UINT64_C(1)<<62 | 0x99;
    TGWResult r={0}; r.gpr.blueprint_ready=false;

    tgw_dispatch(&d, &ctx, &r, addr, value, ctx._bundle);
    tgw_dispatch_flush(&d, &ctx);

    CHECK(d.ground_count == 1,    "ground_count=1");
    CHECK(d.route_count  == 0,    "route_count=0");
    CHECK(_mock_tgw_batch_calls==0, "tgw_batch not called");
    CHECK(_mock_pl_write_calls==1,  "pl_write called once");
    CHECK(d.pending_n == 0,       "pending_n=0 after GROUND");
}

/* ── T2: ROUTE accumulates, batch fires at 64 ─────────────────── */
static void test_t2_batch_accumulate(void) {
    printf("\nT2: ROUTE batch accumulate (64 pkts → 1 tgw_batch)\n");
    reset_mocks();
    TGWCtx ctx; tgw_init(&ctx, 0x1234);
    TGWDispatch d; tgw_dispatch_init(&d, 0x1234);

    for (uint32_t i=0; i<64; i++) {
        uint64_t addr=i*0x100, value=i*0x200;  /* sign bits clear → ROUTE */
        TGWResult r = tgw_write(&ctx, addr, value, 0);
        tgw_dispatch(&d, &ctx, &r, addr, value, ctx._bundle);
    }
    /* batch should have auto-flushed at exactly 64 */
    CHECK(d.batch_flushes == 1,          "1 auto-flush at 64");
    CHECK(_mock_tgw_batch_calls == 1,    "tgw_batch called once");
    CHECK(_mock_tgw_batch_total_n == 64, "64 items in batch");
    CHECK(d.pending_n == 0,              "no pending after flush");
    CHECK(d.route_count == 64,           "route_count=64");

    /* flush remainder (nothing pending) */
    tgw_dispatch_flush(&d, &ctx);
    CHECK(d.batch_flushes == 1, "no extra flush if pending=0");
}

/* ── T3: flush drains remainder ──────────────────────────────── */
static void test_t3_flush_remainder(void) {
    printf("\nT3: flush drains remainder (10 pkts < 64)\n");
    reset_mocks();
    TGWCtx ctx; tgw_init(&ctx, 0x5678);
    TGWDispatch d; tgw_dispatch_init(&d, 0x5678);

    for (uint32_t i=0; i<10; i++) {
        uint64_t addr=i, value=i+100;
        TGWResult r = tgw_write(&ctx, addr, value, 0);
        tgw_dispatch(&d, &ctx, &r, addr, value, ctx._bundle);
    }
    CHECK(d.batch_flushes == 0, "no auto-flush for <64");
    CHECK(d.pending_n == 10,    "10 pending");

    tgw_dispatch_flush(&d, &ctx);
    CHECK(d.batch_flushes == 1,          "1 flush after explicit call");
    CHECK(_mock_tgw_batch_total_n == 10, "10 items flushed");
    CHECK(d.pending_n == 0,              "pending=0 after flush");
}

/* ── T4: boundary 64 vs 65 ─────────────────────────────────── */
static void test_t4_boundary(void) {
    printf("\nT4: batch boundary (64→1 flush, 65→2 flushes)\n");
    reset_mocks();
    TGWCtx ctx; tgw_init(&ctx, 0x9ABC);
    TGWDispatch d; tgw_dispatch_init(&d, 0x9ABC);

    for (uint32_t i=0; i<65; i++) {
        uint64_t addr=i*2, value=i*3;
        TGWResult r = tgw_write(&ctx, addr, value, 0);
        tgw_dispatch(&d, &ctx, &r, addr, value, ctx._bundle);
    }
    /* 64 auto-flush, then 1 remaining */
    CHECK(d.batch_flushes == 1, "1 auto-flush at 64");
    CHECK(d.pending_n == 1,     "1 remaining after 65");

    tgw_dispatch_flush(&d, &ctx);
    CHECK(d.batch_flushes == 2,          "2 total flushes");
    CHECK(_mock_tgw_batch_total_n == 65, "65 total in batches");
}

/* ── T5: prefilter bitmask matches polarity ─────────────────── */
static void test_t5_prefilter(void) {
    printf("\nT5: tgwlc_prefilter bitmask correctness\n");
    _init_geo_walk();

    /* build 16 pkts with known enc values */
    TStreamPkt pkts[16];
    memset(pkts, 0, sizeof(pkts));
    uint64_t expected_mask = 0;
    for (int i=0; i<16; i++) {
        pkts[i].enc = _mock_geo_walk[i];
        uint16_t pos = (uint16_t)(pkts[i].enc % TRING_CYCLE);
        if ((pos % PENT_SPAN) >= MIRROR_HALF)
            expected_mask |= (UINT64_C(1) << i);
    }

    uint64_t mask = tgwlc_prefilter(pkts, 16);
    CHECK(mask == expected_mask, "prefilter mask matches polarity math");

    /* count GROUND bits */
    uint32_t ground_n = (uint32_t)__builtin_popcountll(mask);
    uint32_t route_n  = 16 - ground_n;
    printf("  INFO  GROUND=%u ROUTE=%u (of 16)\n", ground_n, route_n);
    CHECK(ground_n + route_n == 16, "GROUND+ROUTE = total");
}

/* ── T6: spoke histogram (GEO_WALK covers 6 spokes) ─────────── */
static void test_t6_spoke_hist(void) {
    printf("\nT6: spoke histogram uniform (720 pkts, 6 spokes)\n");
    _init_geo_walk();

    static TStreamPkt pkts[720];
    memset(pkts, 0, sizeof(pkts));
    for (int i=0; i<720; i++) pkts[i].enc = _mock_geo_walk[i];

    uint32_t hist[6]={0};
    tgwlc_spoke_hist(pkts, 720, hist);

    uint32_t total=0;
    for (int s=0;s<6;s++) total+=hist[s];
    CHECK(total==720, "histogram total=720");

    /* each spoke should have exactly 120 (720/6) */
    bool uniform=true;
    for (int s=0;s<6;s++) {
        printf("  INFO  spoke[%d]=%u\n", s, hist[s]);
        if (hist[s]!=120) uniform=false;
    }
    CHECK(uniform, "each spoke=120 (uniform distribution)");
}

/* ── T7: mixed GROUND+ROUTE stream consistency ───────────────── */
static void test_t7_mixed_stream(void) {
    printf("\nT7: mixed GROUND+ROUTE stream — counts consistent\n");
    reset_mocks();
    _init_geo_walk();

    TGWCtx ctx; tgw_init(&ctx, 0xDEAD);
    TGWDispatch d; tgw_dispatch_init(&d, 0xDEAD);

    /* 60 pkts: alternating ROUTE addr (sign=0) and GROUND addr (both signs) */
    uint32_t expect_ground=0, expect_route=0;
    for (uint32_t i=0; i<60; i++) {
        uint64_t addr, value;
        if (i%2==0) {
            /* ROUTE: clear sign bits */
            addr=i*0x1000; value=i*0x2000;
            expect_route++;
        } else {
            /* GROUND: set both sign bits */
            addr=(UINT64_C(1)<<63)|i; value=(UINT64_C(1)<<62)|i;
            expect_ground++;
        }
        TGWResult r = tgw_write(&ctx, addr, value, 0);
        tgw_dispatch(&d, &ctx, &r, addr, value, ctx._bundle);
    }
    tgw_dispatch_flush(&d, &ctx);

    CHECK(d.ground_count == expect_ground, "ground_count matches");
    CHECK(d.route_count  == expect_route,  "route_count matches");
    CHECK(d.total_dispatched == 60,        "total_dispatched=60");
    CHECK(d.ground_count + d.route_count == d.total_dispatched,
          "ground+route=total");
}

/* ── T8: verdict=false → GROUND fallback, flush pending ─────── */
static void test_t8_verdict_false(void) {
    printf("\nT8: verdict=false flushes pending batch before GROUND\n");
    reset_mocks();
    _mock_verdict_result = false;   /* force all verdicts to fail */

    TGWCtx ctx; tgw_init(&ctx, 0xF00D);
    TGWDispatch d; tgw_dispatch_init(&d, 0xF00D);

    /* send 5 ROUTE pkts (will queue as no_blueprint first) */
    _mock_bp_ready = false;
    for (uint32_t i=0; i<5; i++) {
        uint64_t addr=i, value=i+10;
        TGWResult r = tgw_write(&ctx, addr, value, 0);
        tgw_dispatch(&d, &ctx, &r, addr, value, ctx._bundle);
    }
    CHECK(d.pending_n == 5, "5 pending (no_blueprint path)");

    /* now send 1 pkt with blueprint but verdict=false */
    _mock_bp_ready = true;
    {
        uint64_t addr=99, value=199;
        TGWResult r = tgw_write(&ctx, addr, value, 0);
        tgw_dispatch(&d, &ctx, &r, addr, value, ctx._bundle);
    }
    /* verdict=false should flush pending 5 first, then pl_write */
    CHECK(d.batch_flushes == 1,          "pending flushed on verdict=false");
    CHECK(_mock_tgw_batch_total_n == 5,  "5 items in flushed batch");
    CHECK(d.verdict_fail == 1,           "verdict_fail=1");
    CHECK(d.ground_count == 1,           "ground_count=1 (verdict fallback)");
    CHECK(d.pending_n == 0,              "pending=0 after verdict flush");

    tgw_dispatch_flush(&d, &ctx);
}

/* ══════════════════════════════════════════════════════════════════
   MAIN
   ══════════════════════════════════════════════════════════════════ */
int main(void) {
    printf("=== P4 Dispatch Batch Test Suite ===\n");
    printf("TGW_DISPATCH_BATCH_MAX=%u  TRING_CYCLE=%u  SPOKES=%u\n\n",
           TGW_DISPATCH_BATCH_MAX, TRING_CYCLE, TRING_SPOKES);

    test_t1_ground_bypass();
    test_t2_batch_accumulate();
    test_t3_flush_remainder();
    test_t4_boundary();
    test_t5_prefilter();
    test_t6_spoke_hist();
    test_t7_mixed_stream();
    test_t8_verdict_false();

    printf("\n=== RESULT: %d PASS  %d FAIL ===\n", _pass, _fail);
    return _fail ? 1 : 0;
}
