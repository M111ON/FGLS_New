/*
 * test_p4_real_lc.c — P4 dispatch logic + real lc_hdr.h
 * เทสเฉพาะ lc_hdr.h round-trip และ tgwlc_bridge functions
 * กับ real header (ไม่ใช่ mock)
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "lc_hdr.h"

static int _pass=0, _fail=0;
#define CHECK(cond, msg) do { \
    if(cond){printf("  PASS  %s\n",msg);_pass++;} \
    else    {printf("  FAIL  %s  [line %d]\n",msg,__LINE__);_fail++;} \
} while(0)

/* Sacred constants */
#define TRING_CYCLE  720u
#define PENT_SPAN     60u
#define MIRROR_HALF   30u
#define TRING_SPOKES   6u
#define ANG_STEPS    512u

/* tgwlc functions (copy from tgw_lc_bridge.h — real version) */
static inline uint16_t tgwlc_enc_to_pos(uint32_t enc) {
    return (uint16_t)(enc % TRING_CYCLE);
}
static inline uint8_t tgwlc_pos_to_spoke(uint16_t pos) {
    return (uint8_t)((pos / PENT_SPAN) % TRING_SPOKES);
}
static inline uint8_t tgwlc_pos_to_polarity(uint16_t pos) {
    return (uint8_t)((pos % PENT_SPAN) >= MIRROR_HALF);
}
static inline LCHdr tgwlc_enc_to_node_hdr(uint32_t enc) {
    uint16_t pos      = tgwlc_enc_to_pos(enc);
    uint8_t  spoke    = tgwlc_pos_to_spoke(pos);
    uint8_t  polarity = tgwlc_pos_to_polarity(pos);
    uint16_t angle    = (uint16_t)((uint32_t)pos * ANG_STEPS / TRING_CYCLE);
    return lch_pack(polarity, 1u,
        (uint8_t)(spoke % 8), (uint8_t)(pos % 8), (uint8_t)(enc % 8),
        LC_LEVEL_0, angle, (uint8_t)(spoke % 4));
}

/* ── T1: lch_pack/unpack round-trip ────────────── */
void test_t1_roundtrip(void) {
    printf("\nT1: lch_pack → accessors round-trip\n");
    LCHdr h = lch_pack(1, 64, 5, 3, 2, LC_LEVEL_1, 300, 2);
    CHECK(lch_sign(h)  == 1,   "sign=1");
    CHECK(lch_mag(h)   == 64,  "mag=64");
    CHECK(lch_r(h)     == 5,   "r=5");
    CHECK(lch_g(h)     == 3,   "g=3");
    CHECK(lch_b(h)     == 2,   "b=2");
    CHECK(lch_level(h) == LC_LEVEL_1, "level=L1");
    CHECK(lch_angle(h) == 300, "angle=300");
    CHECK(lch_face(h)  == 2,   "face=2");
}

/* ── T2: ghost rule ─────────────────────────────── */
void test_t2_ghost(void) {
    printf("\nT2: ghost rule (mag=0)\n");
    LCHdr ghost  = lch_pack(0, 0, 7, 7, 7, LC_LEVEL_0, 255, 3);
    LCHdr active = lch_pack(0, 1, 7, 7, 7, LC_LEVEL_0, 255, 3);
    CHECK(lch_is_ghost(ghost),    "mag=0 → ghost");
    CHECK(!lch_is_ghost(active),  "mag=1 → not ghost");
    CHECK(!lch_is_active(ghost),  "ghost not active");
    CHECK(lch_is_active(active),  "mag=1 → active");
}

/* ── T3: complement rule ────────────────────────── */
void test_t3_complement(void) {
    printf("\nT3: complement (R+R=7, G+G=7, B+B=7, S!=S)\n");
    LCHdr a = lch_pack(0, 64, 5, 3, 1, LC_LEVEL_0, 0, 0);
    LCHdr b = lch_pack(1, 64, 2, 4, 6, LC_LEVEL_0, 0, 0); /* 5+2=7,3+4=7,1+6=7 */
    CHECK(lch_is_complement(a, b), "complement pair detected");

    LCHdr c = lch_pack(0, 64, 5, 3, 1, LC_LEVEL_0, 0, 0); /* same sign → not complement */
    CHECK(!lch_is_complement(a, c), "same sign → not complement");

    LCHdr d = lch_pack(1, 0, 2, 4, 6, LC_LEVEL_0, 0, 0); /* ghost → not complement */
    CHECK(!lch_is_complement(a, d), "ghost → not complement");
}

/* ── T4: tring_pos math ─────────────────────────── */
void test_t4_tring_pos(void) {
    printf("\nT4: lch_tring_pos = angle*720/512, maps 0..719\n");
    /* angle=0 → pos=0, angle=511 → pos=719 */
    LCHdr h0   = lch_pack(0,1,0,0,0,LC_LEVEL_0, 0,   0);
    LCHdr h255 = lch_pack(0,1,0,0,0,LC_LEVEL_0, 255, 0);
    LCHdr h511 = lch_pack(0,1,0,0,0,LC_LEVEL_0, 511, 0);
    uint16_t p0   = lch_tring_pos(h0);
    uint16_t p255 = lch_tring_pos(h255);
    uint16_t p511 = lch_tring_pos(h511);
    CHECK(p0   == 0,   "angle=0   → tring_pos=0");
    CHECK(p255 == 358, "angle=255 → tring_pos=358");
    CHECK(p511 == 718, "angle=511 → tring_pos=719");
    printf("  INFO  angle=255 → tring_pos=%u (expect 357)\n", p255);
}

/* ── T5: enc→node_hdr spoke/polarity invariant ── */
void test_t5_bridge_invariant(void) {
    printf("\nT5: enc→node_hdr spoke+polarity invariant (0..719)\n");
    uint32_t mismatch=0;
    for (uint32_t enc=0; enc<720; enc++) {
        uint16_t pos      = tgwlc_enc_to_pos(enc);
        uint8_t  spoke_d  = tgwlc_pos_to_spoke(pos);
        uint8_t  pol_d    = tgwlc_pos_to_polarity(pos);

        LCHdr h = tgwlc_enc_to_node_hdr(enc);
        uint8_t spoke_h   = lch_r(h);     /* stored in R field */
        uint8_t pol_h     = lch_sign(h);  /* stored in sign */

        if (spoke_h != spoke_d || pol_h != pol_d) mismatch++;
    }
    CHECK(mismatch==0, "all 720 enc: spoke+polarity round-trip exact");
    printf("  INFO  tested enc 0..719, mismatches=%u\n", mismatch);
}

/* ── T6: angle→tring_pos covers full 720 cycle ── */
void test_t6_angle_coverage(void) {
    printf("\nT6: angle 0..511 covers tring_pos 0..719 without gaps\n");
    uint8_t seen[720]={0};
    for (uint16_t a=0; a<512; a++) {
        LCHdr h = lch_pack(0,1,0,0,0,LC_LEVEL_0,a,0);
        uint16_t pos = lch_tring_pos(h);
        if (pos<720) seen[pos]=1;
    }
    uint32_t covered=0;
    for (int i=0;i<720;i++) if(seen[i]) covered++;
    printf("  INFO  covered %u/720 tring positions\n", covered);
    /* 512 steps → can't cover all 720, expect ~512 unique */
    CHECK(covered >= 510, "≥510 positions covered by 512 angle steps");
    CHECK(covered <= 512, "≤512 (no duplicates beyond mapping)");
}

/* ── T7: chiral pair (A + 256) % 512 ────────────── */
void test_t7_chiral(void) {
    printf("\nT7: chiral pair angle=(A+256)%%512\n");
    for (uint16_t a=0; a<512; a+=64) {
        LCHdr h = lch_pack(0,1,0,0,0,LC_LEVEL_0,a,0);
        uint16_t chiral = lch_chiral(h);
        CHECK(chiral == (a+256)%512, "chiral=(a+256)%512");
    }
}

/* ── T8: polarity split ~50% over 720 positions ─ */
void test_t8_polarity_split(void) {
    printf("\nT8: polarity split over 720 enc positions\n");
    uint32_t ground=0, route=0;
    for (uint32_t enc=0; enc<720; enc++) {
        uint16_t pos = (uint16_t)(enc % TRING_CYCLE);
        if ((pos % PENT_SPAN) >= MIRROR_HALF) ground++;
        else route++;
    }
    printf("  INFO  ROUTE=%u GROUND=%u total=%u\n", route, ground, route+ground);
    CHECK(route  == 360, "ROUTE=360 (exactly 50%)");
    CHECK(ground == 360, "GROUND=360 (exactly 50%)");
}

int main(void) {
    printf("=== P4 Real LC Header Test ===\n");
    printf("LCHdr=uint32_t, TRING_CYCLE=%u, ANG_STEPS=%u\n\n",
           TRING_CYCLE, ANG_STEPS);
    test_t1_roundtrip();
    test_t2_ghost();
    test_t3_complement();
    test_t4_tring_pos();
    test_t5_bridge_invariant();
    test_t6_angle_coverage();
    test_t7_chiral();
    test_t8_polarity_split();
    printf("\n=== RESULT: %d PASS  %d FAIL ===\n", _pass, _fail);
    return _fail ? 1 : 0;
}
