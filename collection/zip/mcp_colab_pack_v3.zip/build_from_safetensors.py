import os
import json
import torch
import argparse
from safetensors import safe_open

def build_store(model_path, model_name, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    raw_dir = os.path.join(out_dir, f'{model_name}_tensors_raw')
    os.makedirs(raw_dir, exist_ok=True)

    gsidx = []
    offset = 0

    # List all safetensors files
    files = [f for f in os.listdir(model_path) if f.endswith('.safetensors')]

    for filename in sorted(files):
        file_path = os.path.join(model_path, filename)
        with safe_open(file_path, framework='pt', device='cpu') as f:
            for key in f.keys():
                tensor = f.get_tensor(key)

                # Handle BFloat16 conversion for NumPy compatibility
                is_bf16 = (tensor.dtype == torch.bfloat16)
                if is_bf16:
                    tensor = tensor.to(torch.float32)

                # Determine zone (Simplified logic for Qwen architecture)
                zone = 0
                if 'layers' in key:
                    try:
                        layer_num = int(key.split('layers.')[1].split('.')[0])
                        zone = layer_num % 12
                    except: pass

                # Save raw qdat (numpy format emulation)
                out_name = f'{key}.qdat'
                out_path = os.path.join(raw_dir, out_name)
                # Explicitly cast to numpy after potential dtype change
                tensor.detach().cpu().numpy().tofile(out_path)

                nbytes = tensor.element_size() * tensor.nelement()

                gsidx.append({
                    'name': key,
                    'shape': list(tensor.shape),
                    'dtype': 0 if not is_bf16 and tensor.dtype == torch.float32 else 1,
                    'offset': offset,
                    'nbytes': nbytes,
                    'path': os.path.relpath(out_path, out_dir),
                    'geo_key': hash(key) & 0xFFFFFFFFFFFFFFFF,
                    'zone': zone
                })
                offset += nbytes

    idx_path = os.path.join(out_dir, f'{model_name}_geom.gsidx')
    with open(idx_path, 'w') as f:
        json.dump(gsidx, f, indent=2)

    print(f'Done! {len(gsidx)} tensors processed.')
    print(f'Index: {idx_path}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--model-name', required=True)
    parser.add_argument('--out', default='build/')
    args = parser.parse_args()
    build_store(args.model, args.model_name, args.out)