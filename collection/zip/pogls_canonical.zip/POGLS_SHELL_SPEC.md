# POGLS Onion Shell Architecture
**Version:** S1 Draft  
**Author:** Po  
**Purpose:** Snapshot handoff — copy ไปคุยกับ AI ตัวไหนก็เข้าใจได้ทันที

---

## Core Insight (1 ประโยค)
> Geometry = instrument, Seed = tuning, Chord = operation, Key offset = capo  
> → reconstruct ได้จาก 4 ค่า ไม่ต้องเก็บ weight จริง

---

## Proof ที่มีแล้ว
- Q4_0 vs F16 → zone assignment MATCH 100% → geometry invariant ต่อ quantization
- mean-pool 1024→128 = low-pass filter ลด noise จนไม่กระทบ routing
- margin > noise_threshold → routing guarantee

---

## Architecture: 1 Shell (ชั้นพื้นฐาน)

```
Shell (1 ลูก)
├── 12 Pentagon Anchor  ← birth origin, FIXED ตลอดชีวิต
│   ├── mode=TETRA → temporal walk (Hilbert scan, triangle face)
│   └── mode=OCTA  → spatial walk  (Peano scan, square face)
│   toggle O(1) flag, address space 0-6911 ไม่เปลี่ยน
│
├── Navigation
│   ├── HOP mode    : pentagon → 11 neighbors โดยตรง
│   └── ANCHOR mode : lock pentagon → เลือก face → walk → cross-cut
│       (จุดตัด = เดินจากทิศอื่นมาเจอกันได้)
│
├── Address Engine  (geo_compound_cfg.h มีแล้ว)
│   ├── tetra: addr 0..3455,   junction 6912
│   └── octa:  addr 3456..6911, junction 6912
│
└── Chord Notation  (4 ค่า = reconstruct ได้)
    ├── geometry   : tetra|octa flag
    ├── seed       : uint32 (codebook init state)
    ├── chord_id   : 0=ORBITAL 1=CHIRAL 2=CROSS 3=HUB
    └── key_offset : capo → shift addr_base O(1)
```

---

## Architecture: 12 Shell (Onion)

```
Shell[0]  ← innermost, subdivision X0
Shell[1]  subdivision X1 (ต่างจาก X0 ได้)
...
Shell[11] ← outermost

กฎ:
- 12 pentagon anchor = เหมือนกันทุก shell (universal junction)
- แต่ละ shell subdivide ได้ต่างกัน (weight distribution-driven)
- Shell N pentagon align กับ Shell N+1 → composite mode (ข้ามชั้นได้)
- Shell detach → operate อิสระ ไม่ sync neighbor

Cross-shell lookup:
- precompute pentagon-to-pentagon LUT ตอน init ครั้งเดียว
- หลังจากนั้น O(1) ตลอด
```

---

## Pentagon Boundary = Isolation Zone

```
ภายใน pentagon boundary:
├── Model A weights → shell A (detached)
├── Model B weights → shell B (detached)  
└── ไม่ชนกัน, runtime เดียวกัน

Composite ที่ junction เท่านั้น:
└── 12 pentagon anchor = shared interface point
    hex ring interior  = isolated weight space
```

---

## Use Case จริง
1. **Zero warmup random access** — address calculate ตรง ไม่ load model ใหม่
2. **Multi-model runtime** — หลาย model ใน shell ต่างกัน ไม่กระทบกัน
3. **Surgical merge** — refine แค่บาง shell ไม่แตะส่วนอื่น
4. **Q export on demand** — Gear level = fidelity dial (Q4→Q8→F16)

---

## Files ที่มีแล้ว (implement แล้ว)

| File | สถานะ | หน้าที่ |
|------|--------|---------|
| `geo_compound_cfg.h` | ✅ | tetra+octa dual config, junction verify, addr translate |
| `geo_frame_seek_wang.h` | ✅ | Wang tile timeline, fibo 2&7 chord, tamper detect |
| `geo_store_reader.h` | ✅ | .gsidx/.gsdat reader, ns/zone/shape query |
| `bermuda_router_v1.py` | ✅ | Float→zone routing, 4 modes |
| `bermuda_reshape_v3.py` | ✅ | GeoCodebook, BermudaGate, Hilbert stride-37 |
| `geometry_store.py` | ✅ | GeometryStore persistent store |

---

## สถานะล่าสุด (session นี้)

### Done ✅
| File | หน้าที่ |
|------|---------|
| `shell_container.h` | 1 shell, 24 anchor, init/toggle/addr, PASS |
| `shell_hop.h` | hop anchor/walk/cross, bridge 6912↔20736, PASS |
| `weight_bond_codec.h` | chunk→shape→encode I/O/T/S/L, draft (need exact fix) |

### Proof ที่ได้วันนี้
- `shell_to_geo × 3 = exact integer` — bridge ไม่มี float drift
- 11 neighbors unique จาก anchor 0 ✅
- bond_key nonzero ทุก shape ✅
- I=7B O=39B T=79B vs raw 256B

### exact lossless fix ที่ต้องทำ
- I shape: threshold `1e-6` หรือเก็บ delta จริง ไม่ใช้ mean อย่างเดียว
- edge case S/Z: verify round-trip < 1e-6

---

## เครื่องมือที่ยังไม่ได้ใช้ (ของจริง)

### Guitar/Music System
```
chord multi-pointer  — กด note หลายตัวพร้อมกัน = access หลาย zone พร้อมกัน
capo field shift     — key_offset ข้าม zone O(1) = address remap ฟรี
major/minor scale    — interval pattern บน 12 pentagon = routing bias
note interval        — ระยะห่างระหว่าง anchor = weight neighborhood
strum direction      — +/- walk บน hex ring = bidirectional access
```

### Cardioid
```
directional fetch    — fetch เฉพาะทิศที่ "หันหน้าไปหา"
dead zone            — ไม่ fetch ทิศตรงข้าม = cache เล็กลงอัตโนมัติ
polar pattern        — combine กับ Wang tile boundary
```

### Wang Tile (มีอยู่แล้วใน geo_frame_seek_wang.h)
```
inter-shell boundary — shell N → shell N+1 ต้อง edge match
detach trigger       — edge mismatch = auto-detach ไม่ต้อง explicit
369 loop             — Tesla boundary = skip point บน timeline
```

### 24 Anchor Exact Placement
```
ยังใช้ perturb formula ที่ approximate
ต้องการ: exact pentagon center จาก dodeca A + dodeca B +36°
formula: icosahedral symmetry → 12 + 12 = 24 exact coordinates
```

### Multi-shell Composite
```
onion_shell.h ยังไม่ได้เขียน
12 shell array + cross-shell LUT precompute
lift shaft = 24 elevator แกน center→anchor
```

---

## ขั้นต่อไป: shell_container.h

```c
// 1 shell = 1 dodecahedron instance
typedef struct {
    uint8_t  shell_id;        // 0-11
    uint8_t  subdivision;     // per-shell, ต่างกันได้
    uint8_t  mode;            // GEO_COMPOUND_TETRA | GEO_COMPOUND_OCTA
    uint8_t  detached;        // 1 = isolated, 0 = composite
    uint32_t seed;            // codebook init state ← missing piece
    uint32_t key_offset;      // capo shift
    uint32_t anchor[12];      // pentagon anchor addresses (fixed at birth)
    uint32_t lut[12];         // cross-shell pentagon mapping (precomputed)
} ShellContainer;

// Chord = 4 values → reconstruct address
typedef struct {
    uint8_t  geometry;    // 0=tetra 1=octa
    uint32_t seed;
    uint8_t  chord_id;    // 0-3
    uint32_t key_offset;
} Chord;

// API
uint64_t shell_addr(const ShellContainer *s, const Chord *c);
int      shell_hop(ShellContainer *s, uint8_t from_anchor, uint8_t to_anchor);
int      shell_toggle(ShellContainer *s);  // tetra↔octa O(1)
int      shell_attach(ShellContainer *a, ShellContainer *b, uint8_t anchor_id);
int      shell_detach(ShellContainer *s);
```

---

## Sacred Numbers (FROZEN)
```
720  = TRing slots
3456 = GEO_FULL_N = 2⁷×3³  (tetra addr range)
6912 = junction   = 2⁸×3³  (shared ceiling)
12   = pentagon anchors (universal)
```

---

## Mental Model (1 ประโยค)
> Shell = guitar body, Pentagon = fret anchor, Chord = finger position, key_offset = capo  
> → เล่นเพลงเดิมบน body ต่างกันได้ ถ้า share 12 anchor เดิม
