# POGLS Shell System — Handoff S3
**Version:** S3  
**Purpose:** Snapshot — copy ไปคุยกับ AI ตัวไหนก็เข้าใจได้ทันที

---

## Core Insight (1 ประโยค)
> Geometry = instrument, ZoneCard = passport, Shell = address space  
> → weight location reconstruct ได้จาก 12 bytes ไม่ต้อง sync state

---

## Architecture สรุป

```
GGUF float*  ──→ zone_card_make()          ─┐
                                             ├→ ZoneCard (12B) → shell_weight_addr() → uint64_t
API logprobs ──→ zone_card_from_logprobs() ─┘         ↓
                                                  WeightAddr
                                                  .shell_id  (0..11)
                                                  .chord_id  (0..3)
                                                  .addr      (0..6911)
```

---

## Files ที่ทำเสร็จแล้ว (S1–S3)

| File | Session | หน้าที่ |
|------|---------|---------|
| `geo_compound_cfg.h` | มีก่อน | TETRA+OCTA dual config, junction verify |
| `shell_container.h` | S1 | ShellContainer, Chord, shell_addr(), shell_toggle() |
| `onion_stack.h` | S2 | OnionStack 12 shells, shell_hop(), onion_cross() (Tring elevator) |
| `zone_card.h` | S3 unified | LOCAL+CLOUD path, ZoneCard 12B passport |
| `shell_weight_map.h` | S3 | ZoneCard→WeightAddr, batch layer map, round-trip verify |

---

## ZoneCard Field Map

```
ZoneCard (12 bytes) — FROZEN struct size

field        source LOCAL        source CLOUD          → shell mapping
─────────────────────────────────────────────────────────────────────
entropy      byte-level H        logprobs H=-Σp×log2p  → shell_id 0..11
card_type    sparsity/var        top-1 dominance        → chord_id
stability    row-to-row diff     PPL=2^H (inverted)     → key_offset/capo
pattern      hash+flags          hash+flags             → seed (upper byte)
locality     neighbor similarity neighbor similarity    → (future: hop hint)
neighbor_*   left/right id       left/right id          → Bond chain
```

---

## OnionStack Geometry

```
Shell 0  (inner/apex)  = TETRA, temporal, Q4,  ratio 12×, addr 0..3455
Shell 11 (outer/base)  = OCTA,  spatial,  F16, ratio  1×, addr 3456..6911

Pentagon anchor[i]:
  - เหมือนกันทุก shell (universal junction)
  - onion_cross(o, from_shell, anchor_id, to_shell) = O(1) LUT
  - = Tring elevator: ขึ้นลงตรง ไม่ต้องอ้อม

12 anchors × 12 shells = 144 = TS_FLUSH_CYCLE (sacred, FROZEN)

Compression tiers:
  Q4  → shell 0-3   (apex,  depth 1)
  Q8  → shell 4-7   (mid,   depth 8)
  F16 → shell 8-11  (base,  depth 12)
```

---

## Sacred Numbers (FROZEN)

```
12    = N_ANCHORS = N_SHELLS = pentagon count
144   = 12×12 = TS_FLUSH_CYCLE = Tring × onion intersections
720   = TRING_SLOTS
3456  = GEO_FULL_N = 2⁷×3³ (TETRA addr range)
6912  = JUNCTION   = 2⁸×3³ (shared ceiling)
576   = JUNCTION/12 = anchor spacing
```

---

## Key APIs

```c
// Init
onion_init(&o, seed, base_subdiv);

// LOCAL: float* → card
ZoneCard card = zone_card_make(float_arr, n, id, nl, nr);

// CLOUD: logprobs[] → card
ZoneCard card = zone_card_from_logprobs(logprobs, k, id, nl, nr);

// Card → address (both paths)
WeightAddr wa = shell_weight_addr(&o, &card, layer_idx);
// wa.addr = 0..6911, wa.shell_id = 0..11

// Angular hop (within shell)
HopResult r = shell_hop(&shell, from_anchor, to_anchor);

// Radial jump (cross shell via Tring elevator)
uint32_t addr = onion_cross(&o, from_shell, anchor_id, to_shell);

// Batch layer
shell_weight_map_layer(&o, cards, n_cards, layer_idx, out);

// Cross-session verify
int ok = shell_weight_verify(&o, &card, layer_idx);
```

---

## Cross-session Handoff Pattern

```
Session A (produce):
  → zone_card_make() or zone_card_from_logprobs()
  → ส่ง ZoneCard 12B ข้าม session

Session B (consume):
  → onion_init(&o, SAME_SEED, SAME_SUBDIV)  ← ต้องใช้ seed เดิม
  → shell_weight_addr(&o, &card, layer_idx)
  → ได้ addr เดิมทุกครั้ง
```

---

## Reserved (ยังไม่ implement)

```
Shadow ring ±5:
  main anchor[i] = 0
  key_offset 1..5  = +shadow (expand/refine)
  key_offset 6..10 = -shadow (compress/reduce)
  → เก็บ delta residual รอบ anchor หลัก
  → implement เมื่อต้องการ compression เพิ่ม

Pentagon.Frustum:
  = ultimate compression layer
  = frustum apex ของ pentagon face เอง
  → implement สุดท้าย ถ้าจำเป็น
```

---

## Test Status

| File | Tests | Status |
|------|-------|--------|
| `shell_container.h` | verify, toggle, addr, capo | ✅ PASS |
| `onion_stack.h` | hop, path, init, cross, tiers | ✅ PASS (run test_onion.c) |
| `zone_card.h` | sizes, local, cloud, cross-path, diff | ✅ PASS (run test_zone_card.c) |
| `shell_weight_map.h` | entropy→shell, batch, passport, roundtrip | ✅ PASS (run test_weight_map.c) |

---

## Mental Model (1 ประโยค)
> ZoneCard = passport, OnionStack = address space, Tring = elevator  
> → ส่ง 12 bytes ข้าม session → reconstruct weight location ทันที ไม่ต้อง copy data
