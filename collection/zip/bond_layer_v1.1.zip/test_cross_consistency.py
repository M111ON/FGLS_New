"""Verify Python ctypes bridge ↔ C consistency (supersedes pure-Python v1.0 mirror)"""
import sys, os
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
os.environ.setdefault("POGLS_SO_PATH", str(HERE.parent / "pogls_bond.dll"))

from pogls_bridge import PoglsBridge, FACE_E, FACE_W
br = PoglsBridge()
ok = True

# Test 1: fibo_addr matches C exactly
seed = 0xDEADBEEFCAFE0001
addr = br.fibo_addr(seed)
expected = 0xfd705adbdc1ecf71
match = addr == expected
print(f"[1] fibo_addr(0xDEADBEEFCAFE0001)")
print(f"    Python(ctypes): {addr:016x}")
print(f"    C expected:     {expected:016x}")
print(f"    MATCH:  {match}")
ok = ok and match

# Test 2: wallet bridge matches C
fp_A = "a3f0b2c1d4e5f6a7"
pA = br.make_piece(br.seed_from_fp(fp_A), axis=1)
geo_match = pA.geo_key == 0x9feda551bcd6a336
shape_match = pA.shape_char == "I"
print(f"\n[2] piece_from_wallet(fp_A={fp_A}, axis=1)")
print(f"    Python(ctypes): geo={pA.geo_key:016x}  shape={pA.shape_char}")
print(f"    C expected:      geo=9feda551bcd6a336  shape=I")
print(f"    GEO:    {geo_match}  SHAPE:  {shape_match}")
ok = ok and geo_match and shape_match

# Test 3: bond verify works for same-session pieces
base = 0x9009009009009009
pieces = []
axes = [1, 3, 1, 6]
for i in range(4):
    origin = br.fibo_addr(base ^ i)
    piece = br.make_piece(origin, axes[i])
    pieces.append(piece)

print(f"\n[3] Bond verify (same base=0x9009009009009009)")
for i in range(4):
    print(f"    Piece {['A','B','C','D'][i]}: geo={pieces[i].geo_key:016x} "
          f"shape={pieces[i].shape_char} bond_key={pieces[i].bond_key:016x}")

# Coordinate shift breaks bond
A_shifted = br.make_piece(pieces[0].geo_key ^ 1, 1)
bk_orig = pieces[0].bond_key
bk_shifted = A_shifted.bond_key
bond_broken = bk_orig != bk_shifted
print(f"    Coord shift changes bond_key: {bond_broken}")
ok = ok and bond_broken

# Test 4: plug chain A─B─C─D
print(f"\n[4] Plug chain A─B─C─D:")
slots = [br.make_slot(i, br.fibo_addr(0x9009009009009009 ^ i), axes[i]) for i in range(4)]
br.plug_connect(slots[0], FACE_E, slots[1], FACE_W, 64)
br.plug_connect(slots[1], FACE_E, slots[2], FACE_W, 64)
br.plug_connect(slots[2], FACE_E, slots[3], FACE_W, 64)
a_e_active = slots[0]._raw.plugs[FACE_E].active
d_w_active = slots[3]._raw.plugs[FACE_W].active
print(f"    A.E active: {bool(a_e_active)}")
print(f"    D.W active: {bool(d_w_active)}")
ok = ok and a_e_active and d_w_active

# Test 5: Omega reroute
from pogls_bridge import FAULT_OVERFLOW
slot_r = br.make_slot(99, br.fibo_addr(0xDEAD0000BEEF0000), 1)
orig_bl = slot_r._raw.piece.bond_L
orig_br = slot_r._raw.piece.bond_R
orig_geo = slot_r._raw.piece.geo_key
br.reroute(slot_r, FAULT_OVERFLOW)
shape_ok = slot_r.shape_char == "I"
rerouted_ok = slot_r.rerouted == 1
geo_changed = slot_r._raw.piece.geo_key != orig_geo
bond_survived = (slot_r._raw.piece.bond_L == orig_bl and
                 slot_r._raw.piece.bond_R == orig_br)
print(f"\n[5] Omega reroute (OVERFLOW):")
print(f"    shape->OMEGA_COMPRESS: {shape_ok}")
print(f"    rerouted=1:            {rerouted_ok}")
print(f"    geo_key changed:       {geo_changed}")
print(f"    bond_L/R unchanged:    {bond_survived}")
ok = ok and shape_ok and rerouted_ok and geo_changed and bond_survived

# Test 6: fibo_addr determinism
a1 = br.fibo_addr(seed)
a2 = br.fibo_addr(seed)
a3 = br.fibo_addr(seed ^ 1)
det_ok = (a1 == a2) and (a1 != a3)
print(f"\n[6] fibo_addr determinism:")
print(f"    same seed -> same: {a1 == a2}")
print(f"    seed^1 -> diff:    {a1 != a3}")
ok = ok and det_ok

# Test 7: piece factory axis->shape
axis_shapes = [(1,'I'), (2,'O'), (3,'T'), (4,'S'), (5,'Z'), (6,'L'), (7,'J')]
for ax, sh in axis_shapes:
    p = br.make_piece(br.fibo_addr(0x9009000000000001 ^ ax), ax)
    if p.shape_char != sh:
        print(f"\n[7] axis {ax} -> shape: FAIL (got {p.shape_char}, expected {sh})")
        ok = False
        break
else:
    print(f"\n[7] axis->shape: all 7 mappings correct")

# Test 8: cross-wallet bond verify
fp_B = "b1e2f3a4c5d6e7f8"
pB = br.make_piece(br.seed_from_fp(fp_B), 3)
valid, bk = br.bond_verify(pA, pB)
print(f"\n[8] Cross-wallet bond verify:")
print(f"    bond_key: {bk:016x}")
print(f"    valid:    {valid}")

print(f"\n{'='*50}")
print(f"  CROSS-LANGUAGE (ctypes): {'ALL PASS' if ok else 'SOME FAILED'}")
print(f"{'='*50}")
sys.exit(0 if ok else 1)
