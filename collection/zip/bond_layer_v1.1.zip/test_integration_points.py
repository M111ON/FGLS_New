"""
Test all POGLS ↔ Bond ↔ Smart Folder integration points
Shows the actual data flow from end to end.
"""
import sys, os, tempfile, shutil, hashlib, json
from pathlib import Path

COLLECTION = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(COLLECTION / "python_src"))
_pogls_py = os.environ.get("POGLS_PYTHON", r"I:\ZGLS\POGLS_SRC\master_extracted\python")
sys.path.insert(0, _pogls_py)
os.environ["SMART_FOLDER_POGLS_PY"] = _pogls_py

# ══════════════════════════════════════════════════════════════════════════
# A.  POGLS ADDRESS CODEC — encode/decode deterministic address
# ══════════════════════════════════════════════════════════════════════════
print("═" * 60)
print("A.  POGLS ADDRESS CODEC (pogls_addr_codec.py)")
print("═" * 60)

from pogls_addr_codec import encode, decode

addr = 0x00039a5f00000001
encoded = encode(addr)
decoded = decode(encoded)
print(f"  addr = {addr:#018x}")
print(f"  encode → '{encoded}'")
print(f"  decode → {decoded:#018x}")
print(f"  roundtrip: {addr == decoded}")

# ══════════════════════════════════════════════════════════════════════════
# B.  POGLS FILE COORD — topology scan of real data
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "═" * 60)
print("B.  POGLS TOPOLOGY SCAN (pogls_file_coord.py)")
print("═" * 60)

from pogls_file_coord import topology_scan_multiscale, file_encode, topology_classify

data = b"Fibonacci closure: 144 cycles, Dodeca face: 3, spoke 2, slot 17" * 20
result = topology_scan_multiscale(data)
print(f"  data        : {len(data)} bytes")
print(f"  content_type: {result['content_type']}")
print(f"  routing_hint: {result['routing_hint']}")
print(f"  best_scale  : {result['best_scale']}")
print(f"  intra_dedup : {result['intra_dedup']:.2%}")
print(f"  access_mode : {result.get('access_mode','?')}")

# ══════════════════════════════════════════════════════════════════════════
# C.  POGLS WALLET — build binary wallet from file
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "═" * 60)
print("C.  POGLS WALLET (pogls_wallet_py.py)")
print("═" * 60)

from pogls_wallet_py import WalletBuilder, WALLET_MODE_PATH

builder = WalletBuilder(mode=WALLET_MODE_PATH)
h = hashlib.sha256(data).hexdigest()
fid = builder.add_file("geo_report.bin", len(data), int(h[:8], 16), h)
for i in range(min(8, len(data) // 32)):
    builder.add_coord(fid, i * 32, i * 0xFF + 0x100, 0x1234, i * 0x1000)
wallet_blob = builder.seal()
print(f"  wallet size : {len(wallet_blob)} bytes")
print(f"  magic       : {wallet_blob[:4]} (expected b'WLTG')")
print(f"  format      : [Header 128B][FileEntry 64B][StringPool][CoordRecord 40B][Footer 16B]")

# ══════════════════════════════════════════════════════════════════════════
# D.  BOND LAYER — piece from wallet topology_fp
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "═" * 60)
print("D.  BOND LAYER (pogls_bond_py.py)")
print("═" * 60)

from pogls_bond_py import (
    seed_from_fp, make_piece, bond_key, bond_verify,
    make_slot, plug_connect, PLUG_E, PLUG_W,
)

fp = h[:16]
seed = seed_from_fp(fp)
piece = make_piece(seed, 3)
print(f"  topology_fp: {fp}")
print(f"  seed       : {seed:#018x}")
print(f"  geo_key    : {piece['geo_key']:#018x}")
print(f"  shape      : {piece['shape']} (axis=3 → T-splitter)")
print(f"  bond_key   : {bond_key(piece):#018x}")

# Create multiple pieces and verify bond
pieces = {}
agents_def = [("A", 1), ("B", 3), ("C", 1), ("D", 6)]
for i, (aid, axis) in enumerate(agents_def):
    s = seed_from_fp(h[:16]) ^ (i * 0x100)
    pieces[aid] = make_piece(s, axis)
    print(f"  Agent-{aid}: shape={pieces[aid]['shape']} "
          f"geo={pieces[aid]['geo_key']:#018x} "
          f"bond={bond_key(pieces[aid]):#018x}")

bv = bond_verify(pieces["A"], pieces["B"])
print(f"  bond_verify(A,B): key={bv['bond_key']:#018x} valid={bv['valid']}")

# ══════════════════════════════════════════════════════════════════════════
# E.  SMART FOLDER — ingest, ghost, reconstruct with bond wallet
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "═" * 60)
print("E.  SMART FOLDER (store.py) — full cycle")
print("═" * 60)

sys.path.insert(0, r"I:\ZGLS")
from smart_folder_mvp.store import SmartFolderStore

ws = Path(tempfile.mkdtemp(prefix="pogls_integration_"))
store = SmartFolderStore(ws)
store.init()

# Ingest a file (auto creates coord_wallet with topology_fp)
fpath = ws / "test_pogls.bin"
fpath.write_bytes(data)
result = store.ingest_file(fpath, virtual_path="geo/test_pogls.bin")
print(f"  ingested  : {result.virtual_path} (v{result.version_id})")
print(f"  blob_hash : {result.blob_hash[:16]}...")

# Get coord wallet
manifest = store._load()
entry = manifest.files["geo/test_pogls.bin"]
version = entry.current()
wallet = version.coord_wallet
print(f"  coord_wallet: workspace={wallet['workspace_id'][:8]}...")
print(f"                offset={wallet['offset']}")
print(f"                topology_fp={wallet['topology_fp'][:16]}...")

# Ghost delete
store.delete_file("geo/test_pogls.bin", mode="ghost")
status = store.status()
print(f"  ghost_files: {status['ghost_files']}  tracked_files: {status['tracked_files']}")

# Reconstruct
recon_path = ws / "reconstructed.bin"
recon = store.reconstruct_from_coord_wallet(wallet, out_path=recon_path)
print(f"  reconstruct: {recon['reconstruct_source']}  exact={recon['exact_restore']}")

# ══════════════════════════════════════════════════════════════════════════
# F.  FULL PIPELINE — topology_fp → bond piece → wallet → ghost → reconstruct
# ══════════════════════════════════════════════════════════════════════════
print("\n" + "═" * 60)
print("F.  FULL PIPELINE — data flow summary")
print("═" * 60)

print("""
  DATA FLOW:
                                    ┌──────────────────┐
  file bytes ──→ topology_scan ──→  │  topology_fp     │
                                    │  (16B hex string)│
                                    └────────┬─────────┘
                                             │
                               seed_from_fp()│
                                             ▼
                                    ┌──────────────────┐
                                    │  origin_seed      │
                                    │  (uint64)         │
                                    └────────┬─────────┘
                                             │
                               make_piece()  │
                                             ▼
                                    ┌──────────────────┐
                                    │  PoglsPiece      │
                                    │  geo_key: uint64 │
                                    │  shape:  I/O/T.. │
                                    │  bond_L: uint64  │
                                    │  bond_R: uint64  │
                                    └────────┬─────────┘
                                             │
                               bond_verify() │  plug_connect()
                                             ▼
                                    ┌──────────────────┐
                                    │  SmartFolderStore │
                                    │  ingest → ghost  │
                                    │  → reconstruct   │
                                    └──────────────────┘

  ACTUAL CALLS (verified working):
    pogls_addr_codec.encode()              → base62 address
    pogls_file_coord.topology_scan_multiscale() → topology_fp
    pogls_wallet_py.WalletBuilder()          → binary wallet blob
    pogls_bond_py.make_piece()               → PoglsPiece (25B)
    smart_folder_mvp.store.SmartFolderStore  → full lifecycle

  MISSING BRIDGE (geofield ↔ bond):
    geo_field_demo.exe encodes 64B chunks
    but NOT YET wired to pogls_bond_py.py
""")

shutil.rmtree(ws, ignore_errors=True)
print("  (workspace cleaned up)")
