/*
 * test_p2_pipeline.c — P2: Full L3→L2→L5 Pipeline Integration
 * ════════════════════════════════════════════════════════════
 * Verifies:
 *   T1: stream dispatch fires (pkts sliced, received, routed)
 *   T2: polarity split (ROUTE/GROUND) matches TRing geometry
 *   T3: total_dispatched = route + ground + no_bp + verdict_fail
 *   T4: 720-chunk full cycle → perfect spoke distribution via stream
 *   T5: bridge (tgw_lc_bridge) route matches stream dispatch polarity
 *   T6: no ghost LCNodeHdr from any stream enc
 */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "geo_tring_goldberg_wire.h"
#include "fgls_twin_store.h"
#include "tgw_dispatch.h"
#include "tgw_stream_dispatch.h"
#include "tgw_lc_bridge.h"

static int pass = 0, fail = 0;
#define CHK(cond, msg) do { \
    if (cond) { printf("  ✓ %s\n", msg); pass++; } \
    else      { printf("  ✗ FAIL: %s\n", msg); fail++; } \
} while(0)

/* ── helpers ── */
static void init_all(TGWCtx *ctx, TGWDispatch *d, TGWStreamDispatch *sd)
{
    GeoSeed seed = {0xDEADBEEF12345678ULL, 0x0123456789ABCDEFULL};
    uint64_t bundle[GEO_BUNDLE_WORDS];
    for (int i = 0; i < GEO_BUNDLE_WORDS; i++)
        bundle[i] = 0x1111111111111111ULL * (uint64_t)(i + 1);
    tgw_init(ctx, seed, bundle);
    tgw_dispatch_init(d, seed.gen2);
    tgw_stream_dispatch_init(sd);
}

int main(void)
{
    printf("╔══════════════════════════════════════════════════╗\n");
    printf("║  P2: Full L3→L2→L5 Pipeline Integration Test   ║\n");
    printf("╚══════════════════════════════════════════════════╝\n\n");

    /* ── T1: basic stream dispatch fires ── */
    printf("▶ T1: stream dispatch fires (8×4KB = 8 pkts)\n");
    {
        TGWCtx ctx; TGWDispatch d; TGWStreamDispatch sd;
        init_all(&ctx, &d, &sd);

        /* 8 chunks × 4096 = 32768 bytes */
        static uint8_t data[8 * 4096];
        for (int i = 0; i < (int)sizeof(data); i++) data[i] = (uint8_t)(i & 0xFF);

        uint16_t n = tgw_stream_dispatch(&ctx, &d, &sd, data, sizeof(data));
        CHK(n == 8, "8 pkts sliced from 32KB");

        TGWDispatchStats s = tgw_dispatch_stats(&d);
        uint32_t accounted = s.route_count + s.no_blueprint
                           + s.verdict_fail + s.ground_count;
        CHK(s.total_dispatched == accounted,
            "total = route + ground + no_bp + verdict_fail");
        CHK(sd.ss.pkts_rx > 0, "stream pkts_rx > 0");
        CHK(sd.ss.pkts_gap == 0, "no gap pkts (sequential encs are valid)");
        printf("    total=%u route=%u ground=%u no_bp=%u gap=%u\n",
               s.total_dispatched, s.route_count, s.ground_count,
               s.no_blueprint, sd.ss.pkts_gap);
    }

    /* ── T2: polarity split via 60-chunk stream ── */
    printf("\n▶ T2: polarity split — 60 pkts, expect ≥1 ROUTE + ≥1 GROUND\n");
    {
        TGWCtx ctx; TGWDispatch d; TGWStreamDispatch sd;
        init_all(&ctx, &d, &sd);

        static uint8_t data60[60 * 4096];
        memset(data60, 0xAB, sizeof(data60));

        uint16_t n = tgw_stream_dispatch(&ctx, &d, &sd, data60, sizeof(data60));
        CHK(n == 60, "60 pkts sliced");

        /* GEO_WALK[0..59] covers first pentagon (pos 0..59)
         * pos 0..29 → polarity=0 (ROUTE), pos 30..59 → polarity=1 (GROUND)
         * Expected: ~30 ROUTE, ~30 GROUND (some may be gap/no_bp) */
        TGWDispatchStats s = tgw_dispatch_stats(&d);
        CHK(s.ground_count >= 1, "≥1 GROUND from mirror half of pentagon");
        CHK(s.route_count + s.no_blueprint >= 1, "≥1 ROUTE-path attempt");
        printf("    n=%u route=%u ground=%u no_bp=%u gap=%u\n",
               n, s.route_count, s.ground_count, s.no_blueprint, sd.ss.pkts_gap);
    }

    /* ── T3: accounting invariant (all paths add up) ── */
    printf("\n▶ T3: accounting invariant over 120 pkts\n");
    {
        TGWCtx ctx; TGWDispatch d; TGWStreamDispatch sd;
        init_all(&ctx, &d, &sd);

        static uint8_t data120[120 * 4096];
        for (int i = 0; i < (int)sizeof(data120); i++) data120[i] = (uint8_t)(i*3 & 0xFF);

        tgw_stream_dispatch(&ctx, &d, &sd, data120, sizeof(data120));

        TGWDispatchStats s = tgw_dispatch_stats(&d);
        uint32_t accounted = s.route_count + s.no_blueprint
                           + s.verdict_fail + s.ground_count;
        CHK(s.total_dispatched == accounted, "total == sum of all paths");
        printf("    total=%u (route=%u + ground=%u + no_bp=%u + vfail=%u)\n",
               s.total_dispatched, s.route_count, s.ground_count,
               s.no_blueprint, s.verdict_fail);
    }

    /* ── T4: LUT inverse invariant — tring_pos(GEO_WALK[i]) == i ── */
    printf("\n▶ T4: LUT inverse invariant tring_pos(GEO_WALK[i])==i for 720\n");
    {
        int bad = 0;
        for (int i = 0; i < 720; i++) {
            TRingRoute rt = tring_route_from_enc(GEO_WALK[i]);
            if (rt.pos != (uint16_t)i) { bad++; }
        }
        CHK(bad == 0, "tring_pos(GEO_WALK[i])==i: LUT is perfect inverse of walk");

        /* Also: bridge enc%720 polarity is self-consistent (independent system) */
        int br_bad = 0;
        for (int i = 0; i < 720; i++) {
            TGWLCRoute br = tgwlc_route(GEO_WALK[i]);
            uint8_t exp = tgwlc_pos_to_polarity(tgwlc_enc_to_pos(GEO_WALK[i]));
            if (br.polarity != exp) br_bad++;
        }
        CHK(br_bad == 0, "bridge enc%%720 polarity self-consistent for all GEO_WALK[i]");
    }

    /* ── T5: no ghost nodes from valid stream encs ── */
    printf("\n▶ T5: bridge produces active nodes for GEO_WALK[0..59]\n");
    {
        int ghosts = 0;
        for (int i = 0; i < 60; i++) {
            uint32_t enc = GEO_WALK[i];
            LCNodeHdr hdr = tgwlc_enc_to_node_hdr(enc);
            if (lch_is_ghost(hdr)) ghosts++;
        }
        CHK(ghosts == 0, "0 ghost nodes from GEO_WALK[0..59]");
    }

    /* ── T6: stream gap=0 for all 720-chunk full cycle ── */
    printf("\n▶ T6: 720-chunk full cycle — gap=0 (all encs valid)\n");
    {
        TGWCtx ctx; TGWDispatch d; TGWStreamDispatch sd;
        init_all(&ctx, &d, &sd);

        /* 720 chunks × 4096 = 2.9MB static buffer */
        static uint8_t data720[720 * 4096];
        memset(data720, 0x55, sizeof(data720));

        uint16_t n = tgw_stream_dispatch(&ctx, &d, &sd, data720, sizeof(data720));
        CHK(n == 720, "720 pkts from full TRing cycle");
        CHK(sd.ss.pkts_gap == 0, "0 gap pkts — all GEO_WALK encs LUT-valid");

        TGWDispatchStats s = tgw_dispatch_stats(&d);
        uint32_t total_path = s.route_count + s.ground_count
                            + s.no_blueprint + s.verdict_fail;
        CHK(s.total_dispatched == 720, "720 total dispatched");
        CHK(s.total_dispatched == total_path, "accounting: total == path sum");
        printf("    route=%u ground=%u no_bp=%u gap=%u\n",
               s.route_count, s.ground_count, s.no_blueprint, sd.ss.pkts_gap);
    }

    /* ── summary ── */
    printf("\n══════════════════════════════════════════════════\n");
    printf("  PASS: %d   FAIL: %d\n", pass, fail);
    if (!fail) printf("✅ P2 All PASS — L3→L2→L5 pipeline locked\n");
    else       printf("❌ %d FAIL\n", fail);
    return fail ? 1 : 0;
}
