/*
 * tgw_lc_bridge.h — TGW ↔ LC Bridge (thin adapter)
 * ══════════════════════════════════════════════════
 * Bridges TGW enc routing with LC node header encoding.
 * Uses lc_hdr_renamed.h (LCNodeHdr=uint32_t) — no conflict with lc_twin_gate.h.
 * No malloc. No heap. No modification to TGW or TRing source headers.
 */

#ifndef TGW_LC_BRIDGE_H
#define TGW_LC_BRIDGE_H

#include <stdint.h>
#include "lc_hdr_renamed.h"

/* ── constants ── */
#define TGWLC_TRING_CYCLE  720u
#define TGWLC_PENTAGON_SZ   60u
#define TGWLC_SPOKES         6u
#define TGWLC_ANG_STEPS    512u

/* ── enc → TRing pos (modulo, bridge-local — not LUT) ── */
static inline uint16_t tgwlc_enc_to_pos(uint32_t enc) {
    return (uint16_t)(enc % TGWLC_TRING_CYCLE);
}

/* ── pos → spoke (0..5) ── */
static inline uint8_t tgwlc_pos_to_spoke(uint16_t pos) {
    return (uint8_t)((pos / TGWLC_PENTAGON_SZ) % TGWLC_SPOKES);
}

/* ── pos → polarity (0=ROUTE, 1=GROUND) ── */
static inline uint8_t tgwlc_pos_to_polarity(uint16_t pos) {
    return (uint8_t)((pos % TGWLC_PENTAGON_SZ) >= (TGWLC_PENTAGON_SZ / 2u));
}

/* ── enc → LCNodeHdr (uint32 packed header) ── */
static inline LCNodeHdr tgwlc_enc_to_node_hdr(uint32_t enc) {
    uint16_t pos      = tgwlc_enc_to_pos(enc);
    uint8_t  spoke    = tgwlc_pos_to_spoke(pos);
    uint8_t  polarity = tgwlc_pos_to_polarity(pos);
    uint16_t angle    = (uint16_t)((uint32_t)pos * TGWLC_ANG_STEPS / TGWLC_TRING_CYCLE);

    return lch_pack(
        polarity,
        1u,
        (uint8_t)(spoke % 8u),
        (uint8_t)(pos   % 8u),
        (uint8_t)(enc   % 8u),
        LC_LEVEL_0,
        angle,
        (uint8_t)(spoke % 4u)
    );
}

/* ── route result ── */
typedef struct {
    uint8_t  spoke;
    uint8_t  polarity;
    uint16_t tring_pos;
} TGWLCRoute;

static inline TGWLCRoute tgwlc_node_hdr_to_route(LCNodeHdr hdr) {
    TGWLCRoute r;
    r.tring_pos = lch_tring_pos(hdr);
    r.spoke     = lch_r(hdr);
    r.polarity  = lch_sign(hdr);
    return r;
}

static inline TGWLCRoute tgwlc_route(uint32_t enc) {
    return tgwlc_node_hdr_to_route(tgwlc_enc_to_node_hdr(enc));
}

/* ── gate ── */
typedef enum {
    BRIDGE_GATE_WARP      = 0,
    BRIDGE_GATE_ROUTE     = 1,
    BRIDGE_GATE_COLLISION = 2,
    BRIDGE_GATE_GROUND    = 3,
} BridgeGate;

static inline BridgeGate tgwlc_gate(uint32_t enc_addr, uint32_t enc_value) {
    LCNodeHdr hA = tgwlc_enc_to_node_hdr(enc_addr);
    LCNodeHdr hB = tgwlc_enc_to_node_hdr(enc_value);
    if (lch_is_ghost(hA) || lch_is_ghost(hB)) return BRIDGE_GATE_GROUND;
    if (lch_sign(hA) != lch_sign(hB))         return BRIDGE_GATE_GROUND;
    if (lch_is_complement(hA, hB))             return BRIDGE_GATE_WARP;
    return BRIDGE_GATE_ROUTE;
}

#endif /* TGW_LC_BRIDGE_H */
