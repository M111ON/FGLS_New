/*
 * geo_field_climate.h — Geometric Tensor Field + Capo
 * ══════════════════════════════════════════════════════════════
 *
 * Field = seed + key + tensor_descriptor
 *   seed:   geo_jump origin (region anchor)
 *   key:    capo shift (domain transfer operator)
 *   field:  attractor map (implicit structure, e.g. "2 fish")
 *
 * Capo = frame-of-reference shift
 *   same tensor topology, different address region
 *   music analogy: same chord, different key
 *   geometry analogy: same shape, translated centroid
 *
 * Field topology encodes entity count + relations implicitly:
 *   1 attractor  → single entity
 *   2 attractors → pair relationship (fish A ↔ fish B)
 *   N attractors → N entities + pairwise relations
 *   centroid of attractors = field anchor (auto-stable)
 *
 * Modality:
 *   TEXT/AUDIO: sparse 1D field (sequential attractors)
 *   IMAGE:      dense 2D field  (spatial attractor map)
 *   VIDEO:      delta chain     (Δtensor per fibo tick)
 *
 * No malloc. No float. No global state. Frozen.
 * ══════════════════════════════════════════════════════════════
 */
#pragma once
#include <stdint.h>
#include <string.h>
#include "geo_jump.h"
#include "geo_shell_fold.h"

/* ── Constants ───────────────────────────────────────────────── */
#define CLIMATE_MAX_ATTRACTORS   8u    /* max entities per field    */
#define CLIMATE_KEY_BITS         8u    /* capo range 0-255          */
#define CLIMATE_MODALITY_TEXT    0u
#define CLIMATE_MODALITY_AUDIO   1u
#define CLIMATE_MODALITY_IMAGE   2u
#define CLIMATE_MODALITY_VIDEO   3u
#define CLIMATE_MODALITY_GEO     4u    /* raw geo_jump address      */

/* ── Attractor: one entity in field space ────────────────────── */
typedef struct {
    uint32_t node;        /* geo_jump address of attractor center  */
    uint8_t  weight;      /* relative strength 0-255               */
    uint8_t  layer;       /* shell layer (0-11)                    */
    uint8_t  pent_id;     /* nearest pentagon axis (0-11)          */
    uint8_t  flags;       /* bit0=hot_path bit1=boundary bit2=peak */
} ClimateAttractor;      /* 8B                                     */

#define CLIMATE_FLAG_HOT      (1u<<0)  /* on pentagon axis          */
#define CLIMATE_FLAG_BOUNDARY (1u<<1)  /* near ring edge            */
#define CLIMATE_FLAG_PEAK     (1u<<2)  /* local maximum             */

/* ── Field descriptor ────────────────────────────────────────── */
typedef struct {
    uint32_t seed;        /* region origin — geo_jump start node   */
    uint8_t  key;         /* capo: domain shift 0-255              */
    uint8_t  modality;    /* CLIMATE_MODALITY_*                    */
    uint8_t  n_attract;   /* number of attractors (1-8)            */
    uint8_t  globe;       /* 0=A 1=B                               */
    uint32_t tick;        /* fibo clock position                   */
    uint32_t centroid;    /* mean of attractor nodes (cached)      */
    ClimateAttractor attract[CLIMATE_MAX_ATTRACTORS];
} ClimateField;           /* 4+1+1+1+1+4+4 + 8*8 = 80B             */

/* ── Capo shift ──────────────────────────────────────────────── */
/*
 * climate_capo — apply key shift to field
 * Translates centroid by key*GEO_MOD_PRIME in address space.
 * All attractors shift by same delta → topology preserved.
 * = domain transfer: same structure, different region.
 */
static inline void climate_capo(ClimateField *f, uint8_t new_key) {
    if (new_key == f->key) return;
    uint32_t old_offset = GEO_WRAP((uint64_t)f->key     * GEO_MOD_PRIME);
    uint32_t new_offset = GEO_WRAP((uint64_t)new_key    * GEO_MOD_PRIME);
    uint32_t delta      = GEO_WRAP(GEO_FULL + new_offset - old_offset);
    /* shift all attractors */
    for (uint8_t i = 0; i < f->n_attract && i < CLIMATE_MAX_ATTRACTORS; i++)
        f->attract[i].node = GEO_WRAP(f->attract[i].node + delta);
    f->centroid = GEO_WRAP(f->centroid + delta);
    f->seed     = GEO_WRAP(f->seed     + delta);
    f->key      = new_key;
}

/* ── Centroid calculation ────────────────────────────────────── */
/*
 * climate_update_centroid — recompute weighted centroid
 * In geo_jump space: weighted average of attractor nodes.
 * pentagon hot path: centroid on pent axis → O(1) tunnel access
 */
static inline void climate_update_centroid(ClimateField *f) {
    if (f->n_attract == 0u) return;
    uint64_t sum = 0; uint32_t total_w = 0;
    for (uint8_t i = 0; i < f->n_attract && i < CLIMATE_MAX_ATTRACTORS; i++) {
        sum     += (uint64_t)f->attract[i].node * f->attract[i].weight;
        total_w += f->attract[i].weight;
    }
    f->centroid = (total_w > 0u) ? GEO_WRAP(sum / total_w) : f->seed;
}

/* ── Init ────────────────────────────────────────────────────── */
static inline void climate_init(ClimateField *f,
                                 uint32_t seed,
                                 uint8_t  key,
                                 uint8_t  modality,
                                 uint8_t  globe,
                                 uint32_t tick) {
    memset(f, 0, sizeof(*f));
    f->seed     = seed % GEO_FULL;
    f->key      = key;
    f->modality = modality;
    f->globe    = globe & 1u;
    f->tick     = tick;
    f->centroid = f->seed;
}

/* ── Add attractor ───────────────────────────────────────────── */
static inline int climate_add(ClimateField *f,
                               uint32_t node,
                               uint8_t  weight) {
    if (f->n_attract >= CLIMATE_MAX_ATTRACTORS) return -1;
    uint8_t i = f->n_attract++;
    f->attract[i].node    = node % GEO_FULL;
    f->attract[i].weight  = weight;
    f->attract[i].layer   = (uint8_t)geo_shell_level(node);
    f->attract[i].pent_id = (uint8_t)(geo_pentagon_id(node) - 1u);
    /* hot path: attractor is on pentagon axis */
    f->attract[i].flags = (node % RING_FACE_SPAN < (uint32_t)DODECA_FACES)
                        ? CLIMATE_FLAG_HOT : 0u;
    climate_update_centroid(f);
    return 0;
}

/* ── Temporal delta (VIDEO) ──────────────────────────────────── */
/*
 * ClimateFrame: lightweight delta for video/streaming
 * Store only Δ from previous frame — geo_jump chain reconstruct
 */
typedef struct {
    uint32_t tick;
    uint8_t  n_deltas;
    uint8_t  _pad[3];
    struct { uint8_t idx; int8_t node_delta_hi; uint8_t node_delta_lo;
             int8_t weight_delta; } delta[CLIMATE_MAX_ATTRACTORS];
} ClimateDelta;   /* 4+1+3 + 8*4 = 40B */

static inline void climate_apply_delta(ClimateField *f,
                                        const ClimateDelta *d) {
    f->tick = d->tick;
    for (uint8_t i = 0; i < d->n_deltas && i < CLIMATE_MAX_ATTRACTORS; i++) {
        uint8_t idx = d->delta[i].idx % CLIMATE_MAX_ATTRACTORS;
        if (idx >= f->n_attract) continue;
        int32_t nd = (int32_t)d->delta[i].node_delta_hi * 256
                   + d->delta[i].node_delta_lo;
        f->attract[idx].node = GEO_WRAP((uint32_t)((int32_t)f->attract[idx].node + nd));
        int32_t nw = (int32_t)f->attract[idx].weight + d->delta[i].weight_delta;
        f->attract[idx].weight = (uint8_t)(nw < 0 ? 0 : nw > 255 ? 255 : nw);
    }
    climate_update_centroid(f);
}

/* ── Similarity: field topology overlap ──────────────────────── */
/*
 * climate_similarity — compare two fields without loading data
 * Uses centroid distance + attractor count match.
 * Returns 0-255 (255=identical topology).
 *
 * Fast path: same key → same domain → compare directly
 * Slow path: key differs → transpose one field first
 */
static inline uint8_t climate_similarity(const ClimateField *a,
                                          const ClimateField *b) {
    /* attractor count match */
    /* centroid distance: 0=identical, GEO_FULL/2=opposite */
    uint32_t ca = a->centroid, cb = b->centroid;
    uint32_t dist = (ca > cb) ? ca - cb : cb - ca;
    if (dist > GEO_FULL / 2u) dist = GEO_FULL - dist;
    /* proximity: 0 dist→255, max dist→0 */
    uint8_t prox = (uint8_t)(255u - (dist * 255u) / (GEO_FULL / 2u));
    /* count bonus: same count +32, different 0 */
    uint8_t cnt_bonus = (a->n_attract == b->n_attract) ? 32u : 0u;
    uint32_t score = (uint32_t)prox + cnt_bonus;
    return (uint8_t)(score > 255u ? 255u : score);
}

/* ── Validate ────────────────────────────────────────────────── */
static inline int climate_valid(const ClimateField *f) {
    if (f->n_attract > CLIMATE_MAX_ATTRACTORS) return 0;
    if (f->globe > 1u)                          return 0;
    if (f->centroid >= GEO_FULL)                return 0;
    for (uint8_t i = 0; i < f->n_attract; i++)
        if (f->attract[i].node >= GEO_FULL)     return 0;
    return 1;
}
