/*
 * geo_shell_fold.h — Fibonacci Shell Fold + Ring↔geo_jump Bridge
 * ══════════════════════════════════════════════════════════════
 * Provides:
 *   shell_fold_nearest()   — fibo hole fallback (shared by ring+hex)
 *   ring_to_node()         — RingPos → geo_jump node_id
 *   node_to_ring()         — geo_jump node_id → RingPos
 *   ring_jump()            — ring_step + JUMP_PENTAGON integration
 *
 * Depends on: geo_jump.h, geo_dodeca_ring.h
 * No malloc. No float. Frozen.
 * ══════════════════════════════════════════════════════════════
 */
#pragma once
#include <stdint.h>
#include "geo_jump.h"
#include "geo_dodeca_ring.h"

/* ── Fibonacci table (F(0)..F(11)) ─────────────────────────── */
static const uint16_t GEO_FIBO[12] = {1,1,2,3,5,8,13,21,34,55,89,144};

/* ── shell_fold_nearest ─────────────────────────────────────── */
/*
 * Layer exists only when tick % fibo[layer] == 0.
 * If target layer is frozen (doesn't exist at tick),
 * walk outward then inward to find nearest live layer.
 * Returns live layer id (0-11).
 *
 * Pentagon hot path (pent_axis=1) bypasses this check entirely —
 * hot path is time-invariant (fixed point of A5 group).
 */
static inline uint8_t shell_fold_nearest(uint8_t layer,
                                          uint32_t tick,
                                          uint8_t  pent_axis) {
    if (pent_axis) return layer;  /* hot path: always live */
    layer %= 12u;
    /* quick check: already live? */
    if (tick % GEO_FIBO[layer] == 0) return layer;
    /* search: try layer-1, layer+1, layer-2, layer+2 ... */
    for (uint8_t delta = 1u; delta < 12u; delta++) {
        if (layer >= delta) {
            uint8_t lo = layer - delta;
            if (tick % GEO_FIBO[lo] == 0) return lo;
        }
        uint8_t hi = layer + delta;
        if (hi < 12u && tick % GEO_FIBO[hi] == 0) return hi;
    }
    return 0u;  /* layer 0 always live (fibo=1) */
}

/* layer existence check */
static inline uint8_t shell_layer_live(uint8_t layer, uint32_t tick) {
    return (tick % GEO_FIBO[layer % 12u] == 0) ? 1u : 0u;
}

/* ── ring_to_node ───────────────────────────────────────────── */
/*
 * Map RingPos (dodeca, flower, face) → geo_jump node_id
 *
 * Layout within GEO_FULL=20736:
 *   Each dodeca occupies GEO_FULL/5 = 4147 nodes (≈)
 *   Aligned to GEO_TOWER=144 boundaries:
 *   dodeca_base = dodeca * (GEO_FULL / RING_DODECA)
 *               = dodeca * 4147 → round to 144-aligned
 *               = dodeca * 4032  (4032 = 28×144)
 *
 *   flower offset = flower * (4032 / 2) = flower * 2016
 *   face   offset = face   * (2016 / 12) = face * 168
 *                 = face   * (GEO_TOWER + 24)
 *
 *   node = (dodeca*4032 + flower*2016 + face*168) % GEO_FULL
 *
 * Pentagon centroid = face*168 + GEO_BLOCK/2 = face*168 + 24
 */
#define RING_DODECA_SPAN  4032u   /* 28 × GEO_TOWER, per dodeca   */
#define RING_FLOWER_SPAN  2016u   /* 14 × GEO_TOWER, per flower   */
#define RING_FACE_SPAN     168u   /* face granularity (168=8×21)  */

static inline uint32_t ring_to_node(RingPos pos, uint8_t globe) {
    uint32_t base = (uint32_t)pos.dodeca * RING_DODECA_SPAN
                  + (uint32_t)pos.flower * RING_FLOWER_SPAN
                  + (uint32_t)pos.face   * RING_FACE_SPAN;
    return GEO_WRAP(base + dodeca_globe_offset(globe));
}

/* pentagon centroid node within a face */
static inline uint32_t ring_pent_node(RingPos pos, uint8_t globe) {
    return GEO_WRAP(ring_to_node(pos, globe) + (GEO_BLOCK / 2u));
}

/* ── node_to_ring ───────────────────────────────────────────── */
static inline RingPos node_to_ring(uint32_t node, uint8_t globe) {
    node = GEO_WRAP(node - dodeca_globe_offset(globe)
                  + GEO_FULL) % GEO_FULL;
    RingPos p;
    p.dodeca = (uint8_t)(node / RING_DODECA_SPAN) % RING_DODECA;
    uint32_t r = node % RING_DODECA_SPAN;
    p.flower = (uint8_t)(r / RING_FLOWER_SPAN) % RING_FLOWERS;
    p.face   = (uint8_t)((r % RING_FLOWER_SPAN) / RING_FACE_SPAN)
               % DODECA_FACES;
    return p;
}

/* ── ring_jump ──────────────────────────────────────────────── */
/*
 * Unified ring + geo_jump router.
 *
 * JUMP_PENTAGON → use dodeca edge adjacency (cross-face)
 * JUMP_HILBERT  → intra-face spatial (stays in same face span)
 * JUMP_PEANO    → intra-face temporal (same)
 * JUMP_MOD      → scatter across full ring
 * JUMP_INVERT   → mirror face within dodeca
 *
 * tick=0 → skip fibo check (used for direct access)
 */
typedef struct {
    uint32_t node;     /* geo_jump node_id result        */
    RingPos  ring;     /* decoded ring position          */
    uint8_t  layer;    /* shell layer (0-11)             */
    uint8_t  live;     /* 1=layer exists at this tick    */
} RingJumpResult;

static inline RingJumpResult ring_jump(uint32_t    node,
                                        GeoJumpType type,
                                        uint32_t    param,
                                        uint8_t     globe,
                                        uint8_t     layer,
                                        uint32_t    tick) {
    RingJumpResult r;
    uint8_t live_layer = (tick > 0u)
                       ? shell_fold_nearest(layer, tick, 0u)
                       : layer;

    if (type == JUMP_PENTAGON) {
        /* cross-face via dodeca edge adjacency */
        RingPos pos  = node_to_ring(node, globe);
        uint8_t edge = (uint8_t)(param % DODECA_EDGES);
        RingPos next = ring_step(pos, edge);
        r.node  = ring_to_node(next, globe);
        r.ring  = next;
    } else {
        /* intra-face: delegate to geo_jump arithmetic */
        r.node = geo_jump(node, type, param);
        r.ring = node_to_ring(r.node, globe);
    }

    r.layer = live_layer;
    r.live  = shell_layer_live(live_layer, tick > 0u ? tick : 1u);
    return r;
}

/* ── Hot path: pentagon axis O(1) ───────────────────────────── */
/*
 * Direct access via pentagon centroid — bypasses fibo check,
 * bypasses hex routing, invariant under all layer changes.
 * pent_id: 0-11 (which pentagon anchor)
 * layer:   0-11 (which onion shell)
 */
static inline uint32_t ring_hot_path(uint8_t pent_id,
                                      uint8_t layer,
                                      uint8_t globe) {
    /* hot path = layer*12 + pent_id in base space, then globe offset */
    uint32_t base = (uint32_t)layer * DODECA_FACES
                  + (uint32_t)(pent_id % DODECA_FACES);
    /* scale to geo_jump space: base * RING_FACE_SPAN */
    return GEO_WRAP(base * RING_FACE_SPAN
                  + dodeca_globe_offset(globe));
}
/* 144 hot path addresses = 12 pent × 12 layers ✓ */

/* ── Hex routing (layer >= 6) ───────────────────────────────── */
/*
 * hex_jump — 6-neighbor routing via vertex regions
 * Converts current face → vertex → adjacent face
 * Used when ring_use_hex(layer) == 1
 */
static inline RingJumpResult hex_jump(uint32_t node,
                                       uint8_t  globe,
                                       uint8_t  layer,
                                       uint32_t tick,
                                       uint8_t  hex_dir) {
    RingPos pos   = node_to_ring(node, globe);
    /* face → vertex (one of 5) → adjacent face */
    uint8_t vert  = ring_to_hex(pos.face, hex_dir % DODECA_EDGES);
    /* vertex → first adjacent face (coarse routing) */
    uint8_t nface = hex_to_face(vert, hex_dir % 3u);
    RingPos next  = {pos.dodeca, dodeca_flower(nface), nface};
    uint8_t live  = shell_fold_nearest(layer, tick, 0u);
    return (RingJumpResult){
        ring_to_node(next, globe), next, live,
        shell_layer_live(live, tick > 0u ? tick : 1u)
    };
}
