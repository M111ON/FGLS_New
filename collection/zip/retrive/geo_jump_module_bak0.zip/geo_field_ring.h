/*
 * geo_field_ring.h — Ring 120 Classifier + Full Pipeline Wire
 * ══════════════════════════════════════════════════════════════
 * Pipeline: [Ring 120] → [Junction 30] → [Core 24] → [geo_jump]
 *
 * Ring = outermost shell, first contact layer
 *   classify incoming field modality + density
 *   route to correct globe/face/anchor
 *   120 states = 5 dodeca × 2 flowers × 12 faces
 *
 * Depends on: geo_dodeca_ring.h, geo_shell_fold.h, geo_field_climate.h
 * No malloc. No float. Frozen.
 * ══════════════════════════════════════════════════════════════
 */
#pragma once
#include <stdint.h>
#include "geo_dodeca_ring.h"
#include "geo_shell_fold.h"
#include "geo_field_climate.h"

/* ── Modality density thresholds ─────────────────────────────── */
#define RING_DENSITY_TEXT    48u    /* sparse 1D                   */
#define RING_DENSITY_AUDIO   96u    /* 1D + amplitude              */
#define RING_DENSITY_VIDEO  160u    /* 2D delta chain              */
#define RING_DENSITY_IMAGE  200u    /* dense 2D inverse problem    */

/* Route decision */
#define RING_ROUTE_HOTPATH  0u     /* pentagon axis → O(1) direct  */
#define RING_ROUTE_JUNCTION 1u     /* via 30-vertex layer          */
#define RING_ROUTE_CAPO     2u     /* no match → capo shift        */
#define RING_ROUTE_GLOBEB   3u     /* → Globe B address space      */

/* ── Ring classifier state ───────────────────────────────────── */
typedef struct {
    uint8_t  state;       /* 0-119 ring position                   */
    uint8_t  modality;    /* CLIMATE_MODALITY_*                    */
    uint8_t  route;       /* RING_ROUTE_*                          */
    uint8_t  globe;       /* 0=A 1=B                               */
    uint8_t  confidence;  /* 0-255                                 */
    uint8_t  layer;       /* resolved shell layer 0-11             */
    uint8_t  pent_id;     /* nearest pentagon 0-11                 */
    uint8_t  _pad;
    uint32_t node;        /* final geo_jump node_id                */
    RingPos  ring;        /* decoded ring position                 */
} RingClassified;         /* 16B                                   */

/* ── Classify modality from density + temporal flag ─────────── */
static inline uint8_t ring_classify_modality(uint8_t density,
                                              uint8_t is_temporal) {
    if (!is_temporal) return CLIMATE_MODALITY_IMAGE;
    if (density < RING_DENSITY_TEXT)  return CLIMATE_MODALITY_TEXT;
    if (density < RING_DENSITY_AUDIO) return CLIMATE_MODALITY_AUDIO;
    return CLIMATE_MODALITY_VIDEO;
}

/* ── Core classifier ─────────────────────────────────────────── */
/*
 * ring_classify — map ring state (0-119) to routing decision
 *
 * Logic:
 *   pent_id < 12 AND on axis  → HOTPATH
 *   chirality (state >= 60)   → GLOBE_B
 *   face == 0 (north/south)   → JUNCTION (anchor face)
 *   default                   → JUNCTION via hilbert
 */
static inline RingClassified ring_classify(uint8_t  state,
                                            uint8_t  density,
                                            uint8_t  is_temporal,
                                            uint8_t  layer,
                                            uint32_t tick) {
    RingClassified rc;
    state %= RING_TOTAL;

    RingPos pos  = ring_decode(state);
    uint8_t globe = (state >= 60u) ? 1u : 0u;
    uint8_t live  = (tick > 0u)
                  ? shell_fold_nearest(layer, tick, 0u)
                  : layer;

    rc.state    = state;
    rc.modality = ring_classify_modality(density, is_temporal);
    rc.globe    = globe;
    rc.layer    = live;
    rc.ring     = pos;
    rc.pent_id  = pos.face % DODECA_FACES;

    /* pentagon axis check: face 0 (north) or 11 (south) = pole faces */
    uint8_t on_axis = (pos.face == 0u || pos.face == 11u) ? 1u : 0u;

    if (on_axis) {
        rc.route      = RING_ROUTE_HOTPATH;
        rc.confidence = 255u;
        rc.node       = ring_hot_path(pos.face % DODECA_FACES,
                                       live, globe);
    } else if (globe) {
        rc.route      = RING_ROUTE_GLOBEB;
        rc.confidence = 200u;
        rc.node       = ring_to_node(pos, 1u);
    } else if (pos.flower == 0u && pos.dodeca == 0u) {
        rc.route      = RING_ROUTE_JUNCTION;
        rc.confidence = 220u;
        rc.node       = ring_pent_node(pos, 0u);
    } else {
        rc.route      = RING_ROUTE_JUNCTION;
        rc.confidence = 180u;
        rc.node       = ring_to_node(pos, 0u);
    }

    return rc;
}

/* ── Junction 30: icosidodecahedron layer ────────────────────── */
/*
 * junction_route — refine from ring (120) to junction (30)
 * 120/4 = 30: group by (dodeca % 5, flower, face/2)
 * Returns junction node in [0,29]
 */
static inline uint8_t junction_encode(RingPos pos) {
    return (uint8_t)((pos.dodeca * 6u
                    + pos.flower * 3u
                    + (pos.face % 6u) / 2u) % 30u);
}

/* junction node → geo_jump node */
static inline uint32_t junction_to_node(uint8_t junc, uint8_t globe) {
    RingPos p = {
        .dodeca = junc / 6u,
        .flower = (junc % 6u) / 3u,
        .face   = (junc % 3u) * 2u
    };
    return ring_pent_node(p, globe);
}

/* ── Full pipeline ───────────────────────────────────────────── */
/*
 * pipeline_route — Ring → Junction → Core → geo_jump
 *
 * Stage 1: Ring classifier  (120 states → route decision)
 * Stage 2: Junction refine  (→ 30 junction nodes)
 * Stage 3: Core resolve     (→ 24 origins via pentagon)
 * Stage 4: geo_jump         (→ final node_id)
 */
typedef struct {
    uint32_t       node;        /* final geo_jump address           */
    uint8_t        junction;    /* junction node 0-29               */
    uint8_t        origin;      /* core origin 0-23 (globe*12+pent) */
    uint8_t        route;       /* RING_ROUTE_*                     */
    uint8_t        confidence;  /* 0-255                            */
    RingClassified ring;        /* stage 1 result                   */
} PipelineResult;               /* 8 + 16 = 24B                     */

static inline PipelineResult pipeline_route(uint8_t  ring_state,
                                             uint8_t  density,
                                             uint8_t  is_temporal,
                                             uint8_t  layer,
                                             uint32_t tick,
                                             uint32_t seed_node) {
    PipelineResult pr;

    /* Stage 1: Ring */
    pr.ring = ring_classify(ring_state, density, is_temporal, layer, tick);

    /* Stage 2: Junction */
    pr.junction = junction_encode(pr.ring.ring);

    /* Stage 3: Core origin = globe*12 + pent_id */
    pr.origin = (uint8_t)(pr.ring.globe * 12u + pr.ring.pent_id);

    /* Stage 4: geo_jump */
    if (pr.ring.route == RING_ROUTE_HOTPATH) {
        /* O(1) direct — bypass all stages */
        pr.node       = pr.ring.node;
        pr.confidence = 255u;
    } else {
        /* use ring node as geo_jump starting point, then walk */
        GeoJumpType jtype = (pr.ring.modality == CLIMATE_MODALITY_IMAGE)
                          ? JUMP_HILBERT : JUMP_PEANO;
        pr.node = geo_jump(pr.ring.node, jtype,
                           seed_node % GEO_BLOCK);
        pr.confidence = pr.ring.confidence;
    }

    pr.route = pr.ring.route;
    return pr;
}

/* ── shell_container bridge ──────────────────────────────────── */
/*
 * shell_addr_ring — replacement for shell_container shell_addr()
 * Delegates to pipeline_route instead of stride arithmetic.
 * Drop-in: same inputs (shell_id, chord_id, seed), same output (node).
 *
 * Eliminates JUNCTION=6912 and stride 37/41 hack entirely.
 */
static inline uint32_t shell_addr_ring(uint8_t  shell_id,
                                        uint8_t  chord_id,
                                        uint32_t seed,
                                        uint8_t  globe,
                                        uint32_t tick) {
    /* map shell_id (0-11) + chord_id (0-3) → ring state */
    uint8_t ring_state = (uint8_t)((shell_id * 10u
                                  + chord_id * 3u
                                  + (seed % 7u)) % RING_TOTAL);
    /* density from chord: HUB=dense, ORBITAL=sparse */
    uint8_t density    = (chord_id == 3u) ? RING_DENSITY_IMAGE
                       : (chord_id == 2u) ? RING_DENSITY_AUDIO
                       : RING_DENSITY_TEXT;
    uint8_t temporal   = (chord_id <= 1u) ? 1u : 0u;

    PipelineResult pr = pipeline_route(ring_state, density, temporal,
                                        shell_id, tick, seed);
    (void)globe;  /* globe encoded in ring_state >= 60 */
    return pr.node;
}

/* ── ClimateField → pipeline ─────────────────────────────────── */
/*
 * climate_route — route a ClimateField through full pipeline
 * Uses field centroid as entry point into Ring classifier.
 */
static inline PipelineResult climate_route(const ClimateField *f,
                                            uint8_t layer) {
    /* centroid → ring state via geo_pentagon_id */
    uint8_t pent     = (uint8_t)((geo_pentagon_id(f->centroid) - 1u)
                                % DODECA_FACES);
    uint8_t dodeca   = (uint8_t)(f->centroid / RING_DODECA_SPAN
                                % RING_DODECA);
    uint8_t flower   = (uint8_t)((f->centroid % RING_DODECA_SPAN)
                                / RING_FLOWER_SPAN % RING_FLOWERS);
    uint8_t ring_state = ring_encode(dodeca, flower, pent);

    uint8_t density  = (f->modality == CLIMATE_MODALITY_IMAGE) ? 220u
                     : (f->modality == CLIMATE_MODALITY_VIDEO) ? 160u
                     : 40u;
    uint8_t temporal = (f->modality != CLIMATE_MODALITY_IMAGE) ? 1u : 0u;

    return pipeline_route(ring_state, density, temporal,
                          layer, f->tick, f->seed);
}
