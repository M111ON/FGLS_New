/*
 * geo_dodeca_ring.h — Pentagon Ring: Full Topology
 * ══════════════════════════════════════════════════════════════
 *
 * Derived from exact phi-based dodecahedron vertex coordinates.
 * Verified: symmetry_errors=0, BFS diameter=3 (face graph),
 *           ring diameter=10 (5-dodeca ring), unreachable=0
 *
 * Architecture position:
 *   [Ring 120] → [Junction 30] → [Core 24] → [geo_jump]
 *
 * Ring structure:
 *   5 dodecahedra × 2 flowers × 12 faces = 120 positions
 *   Globe B: same adjacency topology, offset by GEO_FULL/2
 *
 * Edge convention: CCW around face centroid, icosa-axis aligned
 * Globe B: 36° = dodecahedron symmetry → ADJ_A == ADJ_B (verified)
 *
 * No malloc. No float. Frozen constants.
 * ══════════════════════════════════════════════════════════════
 */
#pragma once
#include <stdint.h>

/* ── Constants ───────────────────────────────────────────────── */
#define DODECA_FACES        12u
#define DODECA_EDGES         5u
#define DODECA_VERTS        20u
#define DODECA_GLOBE         2u
#define DODECA_DIST_MAX      3u   /* face graph diameter          */
#define RING_DODECA          5u   /* dodecahedra in ring          */
#define RING_FLOWERS         2u   /* flowers per dodeca           */
#define RING_TOTAL         120u   /* 5×2×12                       */
#define RING_DUAL          240u   /* ×2 globes                    */
#define RING_DIAMETER       10u   /* full ring BFS diameter       */
#define GEO_FULL_HALF    10368u   /* GEO_FULL/2 — Globe B offset  */

/* ── Core types ──────────────────────────────────────────────── */
typedef struct { uint8_t face; uint8_t edge; } DodecaAdj;
typedef struct { uint8_t face; uint8_t edge; } DodecaPos;
typedef struct { uint8_t dodeca; uint8_t flower; uint8_t face; } RingPos;

/* ── Dodecahedron adjacency (Globe A = Globe B, verified) ─────── */
static const DodecaAdj DODECA_ADJ_A[12][5] = {
    [ 0] = {{1,0},{2,2},{4,1},{6,1},{3,2}},  /* z=+1.171 */
    [ 1] = {{0,0},{2,3},{5,1},{7,1},{3,3}},  /* z=+1.171 */
    [ 2] = {{8,0},{4,2},{0,1},{1,1},{5,2}},  /* z=+0.724 */
    [ 3] = {{9,0},{6,2},{0,4},{1,4},{7,2}},  /* z=+0.724 */
    [ 4] = {{6,0},{0,2},{2,1},{8,1},{10,2}}, /* z=+0.000 */
    [ 5] = {{7,0},{1,2},{2,4},{8,4},{11,2}}, /* z=+0.000 */
    [ 6] = {{4,0},{0,3},{3,1},{9,1},{10,3}}, /* z=+0.000 */
    [ 7] = {{5,0},{1,3},{3,4},{9,4},{11,3}}, /* z=+0.000 */
    [ 8] = {{2,0},{4,3},{10,1},{11,1},{5,3}},/* z=-0.724 */
    [ 9] = {{3,0},{6,3},{10,4},{11,4},{7,3}},/* z=-0.724 */
    [10] = {{11,0},{8,2},{4,4},{6,4},{9,2}}, /* z=-1.171 */
    [11] = {{10,0},{8,3},{5,4},{7,4},{9,3}}, /* z=-1.171 */
};

/* ── BFS distance table (face graph, diameter=3) ─────────────── */
static const uint8_t DODECA_DIST[12][12] = {
    {0,1,1,1,1,1,2,2,2,2,3,2},
    {1,0,1,2,2,1,1,2,2,3,2,2},
    {1,1,0,1,1,2,2,2,1,2,2,2},
    {1,2,1,0,1,2,2,2,2,1,2,2},
    {1,2,1,1,0,2,2,1,1,2,1,2},
    {1,1,2,2,2,0,1,1,2,2,2,1},
    {2,1,2,2,2,1,0,2,2,1,1,2},
    {2,2,2,2,1,1,2,0,2,2,1,1},
    {2,2,1,2,1,2,2,2,0,1,1,1},
    {2,3,2,1,2,2,1,2,1,0,1,1},
    {3,2,2,2,1,2,1,1,1,1,0,1},
    {2,2,2,2,2,1,2,1,1,1,1,0},
};

/* ── Flower classification ───────────────────────────────────── */
/* flower 0: faces 0-5 (north), flower 1: faces 6-11 (south)    */
static inline uint8_t dodeca_flower(uint8_t face) {
    return (face < 6u) ? 0u : 1u;
}

/* ── Boundary vs internal edge ───────────────────────────────── */
static inline uint8_t dodeca_edge_is_boundary(uint8_t face, uint8_t edge) {
    uint8_t nb = DODECA_ADJ_A[face % DODECA_FACES][edge % DODECA_EDGES].face;
    return (dodeca_flower(face) != dodeca_flower(nb)) ? 1u : 0u;
}

/* ── Hex conversion tables ───────────────────────────────────── */
/* 20 vertices, each shared by 3 faces (z-sorted north→south)   */
static const uint8_t DODECA_VERT_FACES[20][3] = {
    [ 0] = {0,1,2},  /* z=+1.618 */ [ 1] = {0,1,3},  /* z=+1.618 */
    [ 2] = {0,2,4},  /* z=+1.000 */ [ 3] = {0,3,6},  /* z=+1.000 */
    [ 4] = {1,2,5},  /* z=+1.000 */ [ 5] = {1,3,7},  /* z=+1.000 */
    [ 6] = {0,4,6},  /* z=+0.618 */ [ 7] = {1,5,7},  /* z=+0.618 */
    [ 8] = {2,4,8},  /* z=+0.000 */ [ 9] = {3,6,9},  /* z=+0.000 */
    [10] = {2,5,8},  /* z=+0.000 */ [11] = {3,7,9},  /* z=+0.000 */
    [12] = {4,6,10}, /* z=-0.618 */ [13] = {5,7,11}, /* z=-0.618 */
    [14] = {4,8,10}, /* z=-1.000 */ [15] = {6,9,10}, /* z=-1.000 */
    [16] = {5,8,11}, /* z=-1.000 */ [17] = {7,9,11}, /* z=-1.000 */
    [18] = {8,10,11},/* z=-1.618 */ [19] = {9,10,11},/* z=-1.618 */
};

/* 5 vertices per face (CCW order) */
static const uint8_t DODECA_FACE_VERTS[12][5] = {
    [ 0]={1,0,2,6,3},  [ 1]={1,0,4,7,5},  [ 2]={10,8,2,0,4},
    [ 3]={11,9,3,1,5}, [ 4]={12,6,2,8,14},[ 5]={13,7,4,10,16},
    [ 6]={12,6,3,9,15},[ 7]={13,7,5,11,17},[ 8]={10,8,14,18,16},
    [ 9]={11,9,15,19,17},[ 10]={19,18,14,12,15},[ 11]={19,18,16,13,17},
};

/* ── Ring encode/decode ──────────────────────────────────────── */
static inline uint8_t ring_encode(uint8_t dodeca,
                                   uint8_t flower,
                                   uint8_t face) {
    return (uint8_t)(dodeca * (RING_FLOWERS * DODECA_FACES)
                   + flower * DODECA_FACES
                   + face % DODECA_FACES);
}

static inline RingPos ring_decode(uint8_t idx) {
    RingPos p;
    idx    %= RING_TOTAL;
    p.dodeca = idx / (RING_FLOWERS * DODECA_FACES);
    uint8_t r = idx % (RING_FLOWERS * DODECA_FACES);
    p.flower = r / DODECA_FACES;
    p.face   = r % DODECA_FACES;
    return p;
}

/* ── Main adjacency API ──────────────────────────────────────── */
/* Globe B: same topology, different address space (verified)    */
static inline DodecaAdj dodeca_adj(uint8_t globe,
                                    uint8_t face,
                                    uint8_t edge) {
    (void)globe;
    return DODECA_ADJ_A[face % DODECA_FACES][edge % DODECA_EDGES];
}

static inline uint32_t dodeca_globe_offset(uint8_t globe) {
    return globe ? GEO_FULL_HALF : 0u;
}

static inline uint8_t dodeca_face_dist(uint8_t f0, uint8_t f1) {
    return DODECA_DIST[f0 % DODECA_FACES][f1 % DODECA_FACES];
}

/* ── Cross-face walk ─────────────────────────────────────────── */
static inline DodecaPos dodeca_walk(uint8_t globe,
                                     uint8_t start_face,
                                     uint8_t start_edge,
                                     uint8_t hops) {
    DodecaPos p = {start_face, start_edge};
    for (uint8_t i = 0; i < hops; i++) {
        DodecaAdj nb = dodeca_adj(globe, p.face, p.edge);
        p.face = nb.face; p.edge = nb.edge;
    }
    return p;
}

/* ── Ring cross-dodeca routing ───────────────────────────────── */
/*
 * ring_step — advance one step in the 5-dodeca ring
 * Boundary edge → cross to next dodeca (circular mod 5)
 * Internal edge → stay in same dodeca, cross flower
 */
static inline RingPos ring_step(RingPos pos, uint8_t edge) {
    DodecaAdj nb = dodeca_adj(0, pos.face, edge);
    uint8_t nb_flower = dodeca_flower(nb.face);

    if (nb_flower == pos.flower) {
        /* internal: same dodeca, same flower */
        return (RingPos){pos.dodeca, pos.flower, nb.face};
    } else if (dodeca_edge_is_boundary(pos.face, edge)) {
        /* boundary cross-flower within same dodeca */
        if (pos.flower == 1u) {
            /* flower1 → flower0 of next dodeca */
            uint8_t next_d = (pos.dodeca + 1u) % RING_DODECA;
            return (RingPos){next_d, 0u, nb.face};
        } else {
            /* flower0 → flower1 same dodeca */
            return (RingPos){pos.dodeca, 1u, nb.face};
        }
    }
    return (RingPos){pos.dodeca, pos.flower, nb.face};
}

/* ── Frustum gate: 5 tri between subdivision layers ─────────── */
/*
 * Each pentagon edge = 1 tri gate between shell layers
 * Returns neighbor (face,edge) for cross-layer jump routing
 */
static inline DodecaAdj dodeca_frustum_gate(uint8_t face, uint8_t edge) {
    return DODECA_ADJ_A[face % DODECA_FACES][edge % DODECA_EDGES];
}

/* ── 120→20 hex conversion ───────────────────────────────────── */
/*
 * ring_to_hex — collapse face-centered (120) to vertex-centered (20)
 * Pentagon anchor → vertex index (3-face meeting point)
 * Use at Fibonacci layer >= 6 where Goldberg hex dominates
 */
static inline uint8_t ring_to_hex(uint8_t face, uint8_t vert_slot) {
    return DODECA_FACE_VERTS[face % DODECA_FACES][vert_slot % DODECA_EDGES];
}

/* Inverse: vertex → one of its 3 faces */
static inline uint8_t hex_to_face(uint8_t vert, uint8_t face_slot) {
    return DODECA_VERT_FACES[vert % DODECA_VERTS][face_slot % 3u];
}

/* ── Fibonacci layer threshold ───────────────────────────────── */
/* Use hex routing at layer >= 6 (Goldberg subdivision dominant) */
static inline uint8_t ring_use_hex(uint8_t layer) {
    return (layer >= 6u) ? 1u : 0u;
}
