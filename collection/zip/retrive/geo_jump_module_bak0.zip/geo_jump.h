#ifndef GEO_JUMP_H
#define GEO_JUMP_H

#include <stdint.h>

// ============================================================
// GEO_JUMP — Deterministic Jump Router
// Geometry: 4×4×3 block (48) → 3 towers (144) → 144×144 (20736)
// All jumps O(1) arithmetic, wrap-around (sphere closed)
// ============================================================

// --- Constants ----------------------------------------------
#define GEO_BLOCK       48U      // 4×4×3 nodes
#define GEO_TOWER      144U      // 3 × 48 = 12²
#define GEO_FULL     20736U      // 144² = 12⁴ = TRUE_SYNC
#define GEO_PENTAGONS   12U      // dodecahedron faces = elevator count
#define GEO_PENT_RING   10U      // pentagons per ring
#define GEO_FIBO_CLOCK 1440U     // full time cycle
#define GEO_SHELL_TICK  12U      // ticks per pentagon = N_SHELLS
#define GEO_MOD_PRIME  162U      // sacred constant: 128×162=20736

#define GEO_WRAP(x)    ((uint32_t)(x) % GEO_FULL)  // sphere wrap

// --- Jump Types ---------------------------------------------
typedef enum {
    JUMP_PEANO    = 0,  // stream/sequential — Peano fold
    JUMP_HILBERT  = 1,  // spatial/cache     — Hilbert locality
    JUMP_PENTAGON = 2,  // cross-layer       — 12 pentagon elevators
    JUMP_MOD      = 3,  // hash/scatter      — mod arithmetic
    JUMP_INVERT   = 4,  // residual/recovery — Peano invert (Hilbert blind spots)
} GeoJumpType;

// --- Router Struct ------------------------------------------
typedef struct {
    GeoJumpType type;
    uint32_t    param;   // shell_level / pentagon_id / stride
} GeoJumpRouter;

// ============================================================
// Core Jump Functions (all return wrapped node_id)
// ============================================================

// Peano: sequential fold, cross-layer stream
// param = stride (typically 1)
static inline uint32_t _jump_peano(uint32_t node, uint32_t stride) {
    uint32_t layer  = node / GEO_BLOCK;
    uint32_t local  = node % GEO_BLOCK;
    uint32_t col    = local / 4;
    // int32_t intermediate: prevents underflow when local < stride
    int32_t  loc    = (int32_t)local;
    int32_t  s      = (int32_t)stride;
    int32_t  row    = loc % 4;
    int32_t  next   = (col % 2 == 0)
                    ? loc + s
                    : loc - s + 2 * ((int32_t)(GEO_BLOCK/4) - 1 - row);
    next = ((next % (int32_t)GEO_BLOCK) + (int32_t)GEO_BLOCK) % (int32_t)GEO_BLOCK;
    return GEO_WRAP(layer * GEO_BLOCK + (uint32_t)next);
}

// Hilbert: spatial locality, intra-layer
// param = quadrant hint (0-3)
static inline uint32_t _jump_hilbert(uint32_t node, uint32_t quad) {
    uint32_t layer  = node / GEO_BLOCK;
    uint32_t local  = node % GEO_BLOCK;
    // Hilbert neighbor via quadrant rotation (order-2, 4×4)
    uint32_t seg    = local / 4;
    uint32_t offset = local % 4;
    uint32_t next   = ((seg + quad) % (GEO_BLOCK / 4)) * 4 + offset;
    return GEO_WRAP(layer * GEO_BLOCK + next);
}

// Pentagon elevator: cross-tower via 12 pentagon channels
// param = pentagon_id (1-12)
static inline uint32_t _jump_pentagon(uint32_t node, uint32_t pent_id) {
    if (pent_id < 1 || pent_id > GEO_PENTAGONS) pent_id = 1;
    // each pentagon covers GEO_FULL/12 = 1728 nodes
    uint32_t elevator = (GEO_FULL / GEO_PENTAGONS) * (pent_id - 1);
    return GEO_WRAP(node + elevator);
}

// Mod/hash: scatter across full space
// param = multiplier (default GEO_MOD_PRIME=162)
static inline uint32_t _jump_mod(uint32_t node, uint32_t mult) {
    if (mult == 0) mult = GEO_MOD_PRIME;
    return GEO_WRAP((uint64_t)node * mult);
}

// Invert: hit Hilbert blind spots (inter-layer gaps)
// param = tower offset (0-2)
static inline uint32_t _jump_invert(uint32_t node, uint32_t tower_off) {
    uint32_t tower  = (node / GEO_BLOCK) % 3;
    uint32_t next_t = (tower + tower_off + 1) % 3;
    uint32_t local  = node % GEO_BLOCK;
    // mirror local index (Peano complement of Hilbert)
    uint32_t mirror = GEO_BLOCK - 1 - local;
    return GEO_WRAP(next_t * GEO_BLOCK + mirror);
}

// ============================================================
// Main API
// ============================================================

// Single jump
static inline uint32_t geo_jump(uint32_t node_id, GeoJumpType type, uint32_t param) {
    switch (type) {
        case JUMP_PEANO:    return _jump_peano   (node_id, param ? param : 1);
        case JUMP_HILBERT:  return _jump_hilbert (node_id, param);
        case JUMP_PENTAGON: return _jump_pentagon(node_id, param);
        case JUMP_MOD:      return _jump_mod     (node_id, param);
        case JUMP_INVERT:   return _jump_invert  (node_id, param);
        default:            return GEO_WRAP(node_id + 1);
    }
}

// Jump via router struct
static inline uint32_t geo_jump_r(uint32_t node_id, const GeoJumpRouter *r) {
    return geo_jump(node_id, r->type, r->param);
}

// Fibo clock position of a node
static inline uint32_t geo_clock_tick(uint32_t node_id) {
    return (node_id * GEO_FIBO_CLOCK) / GEO_FULL;
}

// Pentagon id of a node (1-12)
static inline uint32_t geo_pentagon_id(uint32_t node_id) {
    return (node_id / (GEO_FULL / GEO_PENTAGONS)) + 1;
}

// Shell level of a node (0-11)
static inline uint32_t geo_shell_level(uint32_t node_id) {
    return (node_id / (GEO_FULL / (GEO_PENTAGONS * GEO_SHELL_TICK))) % GEO_SHELL_TICK;
}

#endif // GEO_JUMP_H
