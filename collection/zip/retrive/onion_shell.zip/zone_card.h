/*
 * zone_card.h — POGLS Zone Card (S3 unified)
 * ════════════════════════════════════════════
 *
 * Universal 12-byte passport for weight block location.
 * Works with both local (GGUF float*) and cloud (logprobs[]) sources.
 * Output ZoneCard is identical — shell_weight_addr() accepts both.
 *
 * ── SECTION 1: Core structs
 * ── SECTION 2: Shared utils   (hash, entropy, sparsity)
 * ── SECTION 3: Local path     (float* weights → ZoneCard)
 * ── SECTION 4: Cloud path     (logprobs[] → ZoneCard)
 * ── SECTION 5: Verify / diff
 *
 * No malloc. No external deps beyond <stdint.h> <stddef.h> <math.h>.
 * Sacred rule: ZoneCard = 12 bytes. FROZEN.
 * ════════════════════════════════════════════
 */

#pragma once
#include <stdint.h>
#include <stddef.h>
#include <math.h>

/* ════════════════════════════════════════════
   SECTION 1 — Core structs
   ════════════════════════════════════════════ */

#define CARD_SPARSE 0
#define CARD_BATCH  1
#define CARD_LZ     2
#define NO_NEIGHBOR 0xFFFF

/* 12-byte passport — FROZEN */
typedef struct {
    uint16_t id;
    uint8_t  card_type;       /* SPARSE / BATCH / LZ             */
    uint8_t  entropy;         /* 0=certain/structured 255=chaotic */
    uint16_t pattern;         /* fingerprint (upper=hash, lower=flags) */
    uint8_t  locality;        /* similarity to neighbors          */
    uint8_t  stability;       /* 255=stable 0=volatile            */
    uint16_t neighbor_left;
    uint16_t neighbor_right;
} ZoneCard;

_Static_assert(sizeof(ZoneCard) == 12, "ZoneCard must be 12 bytes");

/* Extended: +hash for exact verification */
typedef struct {
    uint16_t id;
    uint8_t  card_type;
    uint8_t  entropy;
    uint16_t pattern;
    uint8_t  locality;
    uint8_t  stability;
    uint16_t neighbor_left;
    uint16_t neighbor_right;
    uint64_t hash_val;
} ZoneCardExt;

_Static_assert(sizeof(ZoneCardExt) == 20, "ZoneCardExt must be 20 bytes");

/* Source tag — which path created this card */
typedef enum {
    CARD_SRC_LOCAL = 0,   /* float* weights (GGUF)    */
    CARD_SRC_CLOUD = 1,   /* logprobs[] (API/MCP)     */
} ZoneCardSrc;

/* ════════════════════════════════════════════
   SECTION 2 — Shared utils
   ════════════════════════════════════════════ */

/* FNV-1a hash */
static inline uint64_t zone_card_hash(const uint8_t *data, size_t len)
{
    uint64_t h = 0xCBF29CE484222325ULL;
    for (size_t i = 0; i < len; i++) {
        h ^= data[i];
        h *= 0x100000001B3ULL;
    }
    return h;
}

/* Byte-level Shannon entropy → uint8 (0..255) */
static inline uint8_t zone_card_entropy(const uint8_t *data, size_t len)
{
    if (!data || len == 0) return 0;
    uint32_t counts[256] = {0};
    for (size_t i = 0; i < len; i++) counts[data[i]]++;
    double ent = 0.0;
    for (int i = 0; i < 256; i++) {
        if (counts[i]) {
            double p = (double)counts[i] / (double)len;
            ent -= p * log2(p);
        }
    }
    uint32_t s = (uint32_t)((ent / 8.0) * 255.0);
    return (uint8_t)(s > 255u ? 255u : s);
}

/* Sparsity of float array → uint8 (255=very sparse) */
static inline uint8_t zone_card_sparsity_f(const float *arr, size_t n,
                                            float threshold)
{
    if (!arr || n == 0) return 0;
    double sum = 0.0, sum2 = 0.0;
    for (size_t i = 0; i < n; i++) {
        sum  += arr[i];
        sum2 += (double)arr[i] * arr[i];
    }
    double mean = sum / n;
    double var  = sum2 / n - mean * mean;
    if (var < 1e-16) return (mean == 0.0) ? 255 : 0;
    double std = sqrt(var);
    size_t near_zero = 0;
    for (size_t i = 0; i < n; i++)
        if (fabs((double)arr[i]) < threshold * std) near_zero++;
    return (uint8_t)((near_zero * 255u) / n);
}

/* Stability across rows of float matrix → uint8 (255=stable) */
static inline uint8_t zone_card_stability(const float *arr,
                                           size_t rows, size_t cols)
{
    if (!arr || rows < 2) return 128;
    double sum = 0.0, sum_abs = 0.0;
    for (size_t r = 1; r < rows; r++) {
        for (size_t c = 0; c < cols; c++) {
            double d = (double)arr[r*cols+c] - (double)arr[(r-1)*cols+c];
            sum     += fabs(d);
            sum_abs += fabs((double)arr[(r-1)*cols+c]);
        }
    }
    double avg_diff = sum / ((rows-1) * cols);
    double avg_mag  = sum_abs / (rows * cols);
    if (avg_mag < 1e-10) return 255;
    double norm = avg_diff / avg_mag;
    if (norm > 1.0) norm = 1.0;
    return (uint8_t)((1.0 - norm) * 255.0);
}

/* Locality: similarity to neighbor cards → uint8 */
static inline uint8_t zone_card_locality_from_cards(const ZoneCard *self,
                                                      const ZoneCard *neighbors,
                                                      int n_neighbors)
{
    if (!neighbors || n_neighbors == 0) return 128;
    int total = 0;
    for (int i = 0; i < n_neighbors; i++) {
        int s = 0;
        if (self->card_type == neighbors[i].card_type) s += 102;
        int ed = (int)self->entropy - (int)neighbors[i].entropy;
        if (ed < 0) ed = -ed;
        s += (76 - ed / 3);
        if (s < 0) s = 0;
        total += s;
    }
    int avg = total / n_neighbors;
    return (uint8_t)(avg > 255 ? 255 : (avg < 0 ? 0 : avg));
}

/* ════════════════════════════════════════════
   SECTION 3 — Local path (GGUF float* weights)
   ════════════════════════════════════════════ */

static inline int _zc_type_f(const float *arr, size_t n)
{
    if (!arr || n == 0) return CARD_BATCH;
    double sum = 0.0, sum2 = 0.0;
    for (size_t i = 0; i < n; i++) { sum += arr[i]; sum2 += (double)arr[i]*arr[i]; }
    double mean = sum / n, var = sum2 / n - mean * mean;
    if (var < 1e-16) return (mean == 0.0) ? CARD_SPARSE : CARD_BATCH;
    if (zone_card_sparsity_f(arr, n, 0.05f) > 178) return CARD_SPARSE;
    return CARD_LZ;
}

static inline uint16_t _zc_pattern_f(const float *arr, size_t n)
{
    if (!arr || n == 0) return 0;
    uint16_t code = 0;
    if (zone_card_sparsity_f(arr, n, 0.01f) > 127) code |= 0x01;
    if (zone_card_entropy((const uint8_t*)arr, n * sizeof(float)) < 100) code |= 0x02;
    size_t alt = 0;
    for (size_t i = 1; i < n; i++)
        if ((arr[i] > 0 && arr[i-1] < 0) || (arr[i] < 0 && arr[i-1] > 0)) alt++;
    if ((float)alt / n > 0.3f) code |= 0x08;
    uint64_t h = zone_card_hash((const uint8_t*)arr, n * sizeof(float));
    code |= (uint16_t)((h & 0xFFu) << 8);
    return code;
}

/*
 * zone_card_make — local path
 * arr: float weight slice, n: element count
 * id, nl, nr: card id + neighbor ids
 */
static inline ZoneCard zone_card_make(const float *arr, size_t n,
                                       uint16_t id,
                                       uint16_t nl, uint16_t nr)
{
    ZoneCard card;
    card.id             = id;
    card.card_type      = (uint8_t)_zc_type_f(arr, n);
    card.entropy        = zone_card_entropy((const uint8_t*)arr,
                                            n * sizeof(float));
    card.pattern        = _zc_pattern_f(arr, n);
    card.locality       = 128;
    card.stability      = 128;
    card.neighbor_left  = nl;
    card.neighbor_right = nr;
    return card;
}

static inline ZoneCardExt zone_card_make_ext(const float *arr, size_t n,
                                              uint16_t id,
                                              uint16_t nl, uint16_t nr)
{
    ZoneCardExt card;
    card.id             = id;
    card.card_type      = (uint8_t)_zc_type_f(arr, n);
    card.entropy        = zone_card_entropy((const uint8_t*)arr,
                                            n * sizeof(float));
    card.pattern        = _zc_pattern_f(arr, n);
    card.locality       = 128;
    card.stability      = 128;
    card.neighbor_left  = nl;
    card.neighbor_right = nr;
    card.hash_val       = zone_card_hash((const uint8_t*)arr,
                                         n * sizeof(float));
    return card;
}

/* ════════════════════════════════════════════
   SECTION 4 — Cloud path (logprobs[] from API)
   ════════════════════════════════════════════ */

/*
 * Cloud model gives us logprobs[k] per output token position.
 * We cannot access weights directly — but logprobs reveal:
 *
 *   H = -Σ p×log2(p)    → entropy   (model uncertainty)
 *   PPL = 2^H            → stability (low PPL = stable)
 *   spread of top-k      → card_type
 *   hash of logprobs     → pattern fingerprint
 *
 * logprobs[]: log-probability values (natural log, typically negative)
 * k:          number of top tokens returned (top-k)
 * id, nl, nr: card id + neighbor ids
 */
static inline ZoneCard zone_card_from_logprobs(const float *logprobs,
                                                uint8_t      k,
                                                uint16_t     id,
                                                uint16_t     nl,
                                                uint16_t     nr)
{
    ZoneCard card;
    card.id             = id;
    card.neighbor_left  = nl;
    card.neighbor_right = nr;
    card.locality       = 128;

    if (!logprobs || k == 0) {
        card.card_type = CARD_BATCH;
        card.entropy   = 128;
        card.pattern   = 0;
        card.stability = 128;
        return card;
    }

    /* ── convert logprobs → probabilities ── */
    /* logprobs are log(p), so p = exp(logprob) */
    double probs[256];
    double sum_p = 0.0;
    uint8_t kk = k > 255 ? 255 : k;
    for (uint8_t i = 0; i < kk; i++) {
        double p = exp((double)logprobs[i]);
        probs[i] = p < 0.0 ? 0.0 : p;
        sum_p += probs[i];
    }
    /* normalize (top-k may not sum to 1.0) */
    if (sum_p > 1e-12) {
        for (uint8_t i = 0; i < kk; i++) probs[i] /= sum_p;
    }

    /* ── Shannon entropy H = -Σ p×log2(p) ── */
    double H = 0.0;
    for (uint8_t i = 0; i < kk; i++) {
        if (probs[i] > 1e-12) H -= probs[i] * log2(probs[i]);
    }
    /* H range: 0 (certain) .. log2(k) (uniform)
     * scale to uint8: H / log2(256) × 255 = H / 8 × 255 */
    double h_norm = H / 8.0;
    if (h_norm > 1.0) h_norm = 1.0;
    card.entropy = (uint8_t)(h_norm * 255.0);

    /* ── card_type from distribution shape ── */
    /* top-1 dominance: how much of mass is in best token */
    double top1 = probs[0];  /* logprobs assumed sorted descending */
    if (top1 > 0.85)
        card.card_type = CARD_SPARSE;   /* very certain → sparse */
    else if (top1 > 0.40)
        card.card_type = CARD_BATCH;    /* moderate → batch */
    else
        card.card_type = CARD_LZ;       /* spread out → uncertain */

    /* ── stability from perplexity PPL = 2^H ── */
    /* low PPL = model certain = stable (255), high PPL = unstable (0) */
    double PPL = pow(2.0, H);
    double max_PPL = (double)kk;        /* max = uniform over k tokens */
    double norm_PPL = PPL / (max_PPL > 1.0 ? max_PPL : 1.0);
    if (norm_PPL > 1.0) norm_PPL = 1.0;
    card.stability = (uint8_t)((1.0 - norm_PPL) * 255.0);

    /* ── pattern from logprobs hash + flags ── */
    uint64_t h = zone_card_hash((const uint8_t*)logprobs,
                                 (size_t)kk * sizeof(float));
    uint16_t pat = (uint16_t)((h & 0xFFu) << 8);  /* upper byte = hash */
    if (card.entropy > 200) pat |= 0x01;           /* high entropy flag */
    if (top1 > 0.70)        pat |= 0x02;           /* dominant token    */
    if (kk > 10 && H > 3.0) pat |= 0x08;           /* wide spread       */
    card.pattern = pat;

    return card;
}

/*
 * zone_card_from_logprobs_ext — cloud path with hash
 * Same as above but returns ZoneCardExt with hash of logprobs for
 * exact cross-session verification.
 */
static inline ZoneCardExt zone_card_from_logprobs_ext(const float *logprobs,
                                                        uint8_t      k,
                                                        uint16_t     id,
                                                        uint16_t     nl,
                                                        uint16_t     nr)
{
    ZoneCard base = zone_card_from_logprobs(logprobs, k, id, nl, nr);
    ZoneCardExt ext;
    ext.id             = base.id;
    ext.card_type      = base.card_type;
    ext.entropy        = base.entropy;
    ext.pattern        = base.pattern;
    ext.locality       = base.locality;
    ext.stability      = base.stability;
    ext.neighbor_left  = base.neighbor_left;
    ext.neighbor_right = base.neighbor_right;
    ext.hash_val       = zone_card_hash((const uint8_t*)logprobs,
                                         (size_t)k * sizeof(float));
    return ext;
}

/* ════════════════════════════════════════════
   SECTION 5 — Verify / diff
   ════════════════════════════════════════════ */

/*
 * zone_card_same_shell — do two cards map to same shell?
 * entropy bands: 0..21=sh0, 22..43=sh1, ... 234..255=sh11
 */
static inline int zone_card_same_shell(const ZoneCard *a, const ZoneCard *b)
{
    uint8_t sa = (uint8_t)(((uint32_t)a->entropy * 12u) >> 8);
    uint8_t sb = (uint8_t)(((uint32_t)b->entropy * 12u) >> 8);
    return sa == sb;
}

/*
 * zone_card_diff — bitmask of fields that differ
 * bit 0 = card_type, 1 = entropy band, 2 = stability band, 3 = pattern hi
 */
static inline uint8_t zone_card_diff(const ZoneCard *a, const ZoneCard *b)
{
    uint8_t d = 0;
    if (a->card_type != b->card_type)                       d |= 0x01;
    if ((a->entropy  >> 5) != (b->entropy  >> 5))           d |= 0x02;
    if ((a->stability >> 5) != (b->stability >> 5))         d |= 0x04;
    if ((a->pattern >> 8) != (b->pattern >> 8))             d |= 0x08;
    return d;
}

/*
 * zone_card_src_consistent — verify local vs cloud card are compatible
 * Returns 1 if same shell + same chord, 0 if diverged
 * Use: sanity check when both paths produce cards for same tensor
 */
static inline int zone_card_src_consistent(const ZoneCard *local,
                                            const ZoneCard *cloud)
{
    /* must agree on card_type (storage strategy) and entropy band (shell) */
    return (zone_card_diff(local, cloud) & 0x03) == 0;
}
