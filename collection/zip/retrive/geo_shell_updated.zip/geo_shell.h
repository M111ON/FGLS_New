/*
 * geo_shell.h — Shell constants stub
 * SHELL_TOTAL = 240 = dual globe (2 × 120 ring positions)
 */
#pragma once
#include <stdint.h>
#define SHELL_TOTAL    240u   /* 2 globes × 120 ring = RING_DUAL */
#define SHELL_FACES     12u   /* = DODECA_FACES                  */
#define SHELL_MAX_ID    11u   /* layer 0-11                      */
