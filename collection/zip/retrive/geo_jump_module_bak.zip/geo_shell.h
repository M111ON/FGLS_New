#ifndef GEO_SHELL_H
#define GEO_SHELL_H

/*
 * geo_shell.h — Pentagon Shell Address Space
 * ===========================================
 * Static coordinate layer: 240 pentagon positions → node_id in 20736
 *
 * NOT a traversal engine (see geo_dodeca_torus.h for that)
 * This is the GPS map — dodeca_torus is the car driving on it
 *
 * Layout:
 *   12 pentagon faces (dodecahedron)
 *   × 10 rings per face   (GEO_PENT_RING)
 *   × 2  sides (inner=0, outer=1)
 *   = 240 unique shell positions  ← E8 roots
 *
 * Coordinate → node_id mapping onto GEO_FULL=20736:
 *   unit = 20736 / 240 = 86 (floor), remainder distributed to outer ring
 *   face_block  = 20736 / 12  = 1728  nodes per face
 *   ring_block  = 1728  / 10  = 172   nodes per ring (+ 8 remainder)
 *   side_block  = 172   / 2   = 86    nodes per side
 *
 * Depends: stdint.h only
 */

#include <stdint.h>

/* ── constants ───────────────────────────────────────────────────── */
#define SHELL_FACES         12u     /* dodecahedron faces = N_PENTAGONS  */
#define SHELL_RINGS         10u     /* pentagon rings per face           */
#define SHELL_SIDES          2u     /* inner(0) / outer(1)              */
#define SHELL_TOTAL        240u     /* 12 × 10 × 2 = E8 roots           */

#define SHELL_FULL       20736u     /* = GEO_FULL = 144² = 12⁴          */
#define SHELL_FACE_BLOCK  1728u     /* 20736 / 12                        */
#define SHELL_RING_BLOCK   172u     /* 1728  / 10  (floor)              */
#define SHELL_SIDE_BLOCK    86u     /* 172   / 2   (floor)              */

/* inner/outer side enum */
#define SHELL_INNER          0u
#define SHELL_OUTER          1u

/* ── shell_id encode/decode ──────────────────────────────────────── */

/* encode: (face 0-11, ring 0-9, side 0-1) → shell_id 0-239 */
static inline uint32_t geo_shell_encode(uint32_t face,
                                         uint32_t ring,
                                         uint32_t side)
{
    /* clamp — silent, caller's responsibility to pass valid coords */
    if (face >= SHELL_FACES) face = SHELL_FACES - 1u;
    if (ring >= SHELL_RINGS) ring = SHELL_RINGS - 1u;
    if (side >= SHELL_SIDES) side = SHELL_SIDES - 1u;
    return face * (SHELL_RINGS * SHELL_SIDES) + ring * SHELL_SIDES + side;
}

/* decode: shell_id 0-239 → (face, ring, side) */
static inline void geo_shell_decode(uint32_t  shell_id,
                                     uint32_t *face,
                                     uint32_t *ring,
                                     uint32_t *side)
{
    shell_id %= SHELL_TOTAL;   /* wrap — sphere closed */
    *side =  shell_id % SHELL_SIDES;
    *ring = (shell_id / SHELL_SIDES) % SHELL_RINGS;
    *face =  shell_id / (SHELL_RINGS * SHELL_SIDES);
}

/* ── address mapping ─────────────────────────────────────────────── */

/* shell_id → node_id in 0..20735 */
static inline uint32_t geo_shell_to_node(uint32_t shell_id)
{
    shell_id %= SHELL_TOTAL;
    uint32_t face, ring, side;
    geo_shell_decode(shell_id, &face, &ring, &side);

    return (face * SHELL_FACE_BLOCK)
         + (ring * SHELL_RING_BLOCK)
         + (side * SHELL_SIDE_BLOCK);
}

/* node_id → nearest shell_id (inverse mapping, O(1)) */
static inline uint32_t geo_node_to_shell(uint32_t node_id)
{
    node_id %= SHELL_FULL;
    uint32_t face = node_id / SHELL_FACE_BLOCK;
    uint32_t rem  = node_id % SHELL_FACE_BLOCK;
    uint32_t ring = rem / SHELL_RING_BLOCK;
    uint32_t rem2 = rem % SHELL_RING_BLOCK;
    uint32_t side = rem2 / SHELL_SIDE_BLOCK;

    /* clamp to valid range */
    if (face >= SHELL_FACES) face = SHELL_FACES - 1u;
    if (ring >= SHELL_RINGS) ring = SHELL_RINGS - 1u;
    if (side >= SHELL_SIDES) side = SHELL_SIDES - 1u;

    return geo_shell_encode(face, ring, side);
}

/* ── helpers ─────────────────────────────────────────────────────── */

/* face of a node (0-11) — same as geo_pentagon_id-1 */
static inline uint32_t geo_shell_face(uint32_t node_id) {
    return (node_id % SHELL_FULL) / SHELL_FACE_BLOCK;
}

/* ring of a node (0-9) */
static inline uint32_t geo_shell_ring(uint32_t node_id) {
    return ((node_id % SHELL_FULL) % SHELL_FACE_BLOCK) / SHELL_RING_BLOCK;
}

/* side of a node: SHELL_INNER or SHELL_OUTER */
static inline uint32_t geo_shell_side(uint32_t node_id) {
    return (((node_id % SHELL_FULL) % SHELL_FACE_BLOCK) % SHELL_RING_BLOCK)
           / SHELL_SIDE_BLOCK;
}

/* torus face (0-11) → shell base node — entry point for dodeca_torus */
static inline uint32_t geo_shell_face_base(uint32_t torus_face) {
    return (torus_face % SHELL_FACES) * SHELL_FACE_BLOCK;
}

#endif /* GEO_SHELL_H */
