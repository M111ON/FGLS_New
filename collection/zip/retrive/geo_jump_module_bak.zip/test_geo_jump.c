#include <stdio.h>
#include <assert.h>
#include "geo_jump.h"

#define PASS(name) printf("[PASS] %s\n", name)
#define FAIL(name) printf("[FAIL] %s\n", name)
#define CHECK(cond, name) do { if(cond) PASS(name); else FAIL(name); } while(0)

int main(void) {
    printf("=== geo_jump test ===\n\n");

    // --- Constants
    CHECK(GEO_BLOCK * 3 == GEO_TOWER,          "48×3=144");
    CHECK(GEO_TOWER * GEO_TOWER == GEO_FULL,   "144²=20736");
    CHECK(128U * GEO_MOD_PRIME == GEO_FULL,    "128×162=20736");
    CHECK(GEO_FIBO_CLOCK / GEO_PENTAGONS == 120, "1440/12=120");
    CHECK(GEO_FIBO_CLOCK / (GEO_PENTAGONS * GEO_SHELL_TICK) == 10, "1440/144=10=pent_ring");

    // --- Wrap around
    uint32_t over = GEO_FULL + 126;
    CHECK(GEO_WRAP(over) == 126, "wrap 20862→126");

    // --- JUMP_MOD: 128×162=20736 → wraps to 0
    uint32_t m = geo_jump(128, JUMP_MOD, 162);
    CHECK(m == 0, "mod: 128×162%20736=0");

    // --- JUMP_PENTAGON: elevator spacing = 1728
    uint32_t p1 = geo_jump(0, JUMP_PENTAGON, 1);
    uint32_t p2 = geo_jump(0, JUMP_PENTAGON, 2);
    CHECK(p2 - p1 == GEO_FULL / GEO_PENTAGONS, "pentagon elevator spacing=1728");

    // --- JUMP_INVERT: must differ from source
    uint32_t inv = geo_jump(0, JUMP_INVERT, 0);
    CHECK(inv != 0, "invert: blind spot hit");

    // --- JUMP_HILBERT: stays within geometry
    uint32_t h = geo_jump(100, JUMP_HILBERT, 2);
    CHECK(h < GEO_FULL, "hilbert: within bounds");

    // --- JUMP_PEANO: sequential
    uint32_t pe = geo_jump(47, JUMP_PEANO, 1);
    CHECK(pe < GEO_FULL, "peano: within bounds");

    // --- Clock / Pentagon / Shell helpers
    uint32_t tick = geo_clock_tick(10368);  // midpoint
    CHECK(tick == 720, "clock_tick midpoint=720");

    uint32_t pid = geo_pentagon_id(1728);   // start of pentagon 2
    CHECK(pid == 2, "pentagon_id(1728)=2");

    uint32_t shell = geo_shell_level(0);
    CHECK(shell == 0, "shell_level(0)=0");

    printf("\n=== done ===\n");
    return 0;
}
