# CPU Pipeline v1 — LOCKED
_Session date: 2026-05-06_

## Status

| Layer | Component | Status |
|---|---|---|
| L5 | SpaceFrame (TRing/Goldberg) | ✅ frozen |
| L4 | geo_addr_net.h (SEAM 2) | ✅ done |
| L3 | geopixel_v21.c (SEAM 3) | ✅ done |
| L2 | tgw_dispatch_v2.h (P4+P6) | ✅ done |
| — | Integration test | ✅ 15/15 PASS |

## New Files

| File | Purpose |
|---|---|
| `geo_addr_net.h` | SEAM 2: enc → GeoNetAddr (polarity, spoke, hilbert_idx) |
| `geo_tring_walk.h` | SEAM 3: tile_i → TRing enc for spoke routing |
| `tgw_lc_bridge_p6.h` | P6: TGWPendingSlot, TGWBatchFlushFn, TGWGroundFn |
| `tgw_dispatch_v2.h` | P4+P6 merge: full context + Hilbert sort batch |
| `geopixel_v21.c` | geopixel_v20 + tring_walk_enc at 3 tile loop sites |

## Key Constants (frozen forever)

```c
GAN_TRING_CYCLE     = 720    // TRing full cycle
GAN_SPOKES          = 6      // spoke count
TRING_WALK_STRIDE   = 37     // coprime to 720, uniform spoke dist
TGW_V2_BATCH_MAX    = 64     // L1-cache-friendly batch size
polarity formula    = (pos % 120) >= 60   // NOT (pos%60)>=30
```

## Test Results

```
test_tring_walk.c:     6/6  PASS
test_dispatch_v2.c:   24/24 PASS
test_cpu_pipeline.c:  15/15 PASS
─────────────────────────────────
Total:                45/45 PASS
```

## Key Metrics (IT6)
```
sort_efficiency = 0.538   (walk order → pre-sorted ~54%)
avg_swaps/flush = 931.5
spoke dist NT=720: exact 120/spoke (60 ROUTE + 60 GROUND each)
```

## Fixes Applied This Session

| Bug | File | Fix |
|---|---|---|
| polarity `(pos%60)>=30` wrong | geo_addr_net.h | `(pos%120)>=60` |
| `no_blueprint` not counted as route | tgw_dispatch_v2.h | `route_count++` in no_bp branch |
| V2MockCtx buffer overflow | test_dispatch_v2.c | `*8 → *16` |
| TGWCtx stub ordering | test_dispatch_v2.c | moved tgw_write/batch stubs after retype |

## Next Steps

1. **Bench P4 vs P3** — measure MB/s with real data (bench_pipeline.c)
2. **LC-GCFS hook** — add as Layer 4 output (persistence layer)
3. **GPU batch Phase 14** — after CPU pipeline stable
