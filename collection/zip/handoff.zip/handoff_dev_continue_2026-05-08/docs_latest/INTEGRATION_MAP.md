# Integration Map

## Canonical Source Layout
- `src/` is canonical for TGW/LCGW wire headers and additive routing hooks.
- `core/pogls_engine/` provides shared engine dependencies consumed by `src` (`fgls_twin_store.h`, `lc_twin_gate.h`).
- `core/core/` provides foundational geometry/core headers when required by tests and compile surfaces.

## Include Policy
- Use include roots: `-Isrc -Icore/pogls_engine -Icore/core`.
- Do not use fragile relative includes like `../pogls_engine/...` from `src`.
- Keep `handoff_files/` as snapshot/reference only, not canonical compile source.

## Added From Handoff Into Canonical `src/`
- `frustum_gcfs.h`
- `frustum_slot64.h`
- `frustum_trit.h`
- `geo_goldberg_lut.h`
- `geo_metatron_route.h`
- `geo_temporal_lut.h`
- `lcgw_adaptive.h`
- `lc_hdr_lazy.h`
- `tgw_dispatch_v2_tri5.h`
- `tgw_frustum_wire.h`
- `tgw_ground_lcgw_lazy.h`

## Compatibility Shims Applied
- `src/lc_gcfs_wire.h`
: added `LCGW_RAW_BYTES` alias to `GCFS_TOTAL_BYTES`.
: added `lcgw_reset()` as back-compat helper that calls `lcgw_init()`.
- `src/tgw_ground_lcgw.h`
: rewired `lcgw_ground_rewind()` to match current `lcgw_rewind()` API surface by rebuilding chunks from saved lane seeds.
