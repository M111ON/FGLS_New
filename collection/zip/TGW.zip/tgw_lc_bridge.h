/*
 * tgw_lc_bridge.h — TGW ↔ LC Bridge (P4 upgrade)
 * ══════════════════════════════════════════════════
 * P4 changes vs P2:
 *   - tgwlc_gate_batch(): classify N enc pairs in one pass
 *     → feeds GROUND/ROUTE split before dispatch (pre-filter)
 *   - tgwlc_prefilter(): returns bitmask of which indices are GROUND
 *     → caller skips tgw_write entirely for GROUND pkts (~233ns saved/pkt)
 *   - All single-pkt functions unchanged (backward compatible)
 *
 * Key insight: LC gate check costs ~5ns vs tgw_write 233ns.
 * Pre-filtering GROUND before tgw_write = biggest single win in pipeline.
 *
 * No malloc. No heap. No modification to source headers.
 */

#ifndef TGW_LC_BRIDGE_H
#define TGW_LC_BRIDGE_H

#include <stdint.h>

#include "lc_hdr.h"
typedef LCHdr LCNodeHdr;

#define _LCT_SKIP_DEFS
typedef struct {
    uint8_t  sign;
    uint8_t  mag;
    uint8_t  rgb;
    uint8_t  level;
    uint8_t  angle;
    uint8_t  letter;
    uint16_t slope;
} TGWLCHdr;

typedef enum {
    BRIDGE_GATE_WARP      = 0,
    BRIDGE_GATE_ROUTE     = 1,
    BRIDGE_GATE_COLLISION = 2,
    BRIDGE_GATE_GROUND    = 3,
} BridgeGate;

/* ── Sacred constants ────────────────────────────────────────── */
#define TGWLC_TRING_CYCLE  720u
#define TGWLC_PENTAGON_SZ   60u
#define TGWLC_SPOKES         6u
#define TGWLC_ANG_STEPS    512u

/* ── Single-pkt math (unchanged) ────────────────────────────── */
static inline uint16_t tgwlc_enc_to_pos(uint32_t enc) {
    return (uint16_t)(enc % TGWLC_TRING_CYCLE);
}
static inline uint8_t tgwlc_pos_to_spoke(uint16_t pos) {
    return (uint8_t)((pos / TGWLC_PENTAGON_SZ) % TGWLC_SPOKES);
}
static inline uint8_t tgwlc_pos_to_polarity(uint16_t pos) {
    return (uint8_t)((pos % TGWLC_PENTAGON_SZ) >= (TGWLC_PENTAGON_SZ / 2));
}

/* ── enc → LCNodeHdr ─────────────────────────────────────────── */
static inline LCNodeHdr tgwlc_enc_to_node_hdr(uint32_t enc) {
    uint16_t pos      = tgwlc_enc_to_pos(enc);
    uint8_t  spoke    = tgwlc_pos_to_spoke(pos);
    uint8_t  polarity = tgwlc_pos_to_polarity(pos);
    uint16_t angle    = (uint16_t)((uint32_t)pos * TGWLC_ANG_STEPS
                                   / TGWLC_TRING_CYCLE);
    return lch_pack(
        polarity, 1u,
        (uint8_t)(spoke % 8), (uint8_t)(pos % 8), (uint8_t)(enc % 8),
        LC_LEVEL_0, angle, (uint8_t)(spoke % 4)
    );
}

/* ── TGWLCRoute ──────────────────────────────────────────────── */
typedef struct {
    uint8_t  spoke;
    uint8_t  polarity;
    uint16_t tring_pos;
} TGWLCRoute;

static inline TGWLCRoute tgwlc_node_hdr_to_route(LCNodeHdr hdr) {
    TGWLCRoute r;
    r.tring_pos = lch_tring_pos(hdr);
    r.spoke     = lch_r(hdr);
    r.polarity  = lch_sign(hdr);
    return r;
}

static inline TGWLCRoute tgwlc_route(uint32_t enc) {
    return tgwlc_node_hdr_to_route(tgwlc_enc_to_node_hdr(enc));
}

/* ── Single gate (unchanged) ─────────────────────────────────── */
static inline BridgeGate tgwlc_gate(uint32_t enc_addr, uint32_t enc_value) {
    LCNodeHdr hA = tgwlc_enc_to_node_hdr(enc_addr);
    LCNodeHdr hB = tgwlc_enc_to_node_hdr(enc_value);
    if (lch_is_ghost(hA) || lch_is_ghost(hB)) return BRIDGE_GATE_GROUND;
    if (lch_sign(hA) != lch_sign(hB))         return BRIDGE_GATE_GROUND;
    if (lch_is_complement(hA, hB))             return BRIDGE_GATE_WARP;
    return BRIDGE_GATE_ROUTE;
}

/* ── P4: batch gate → GROUND bitmask ────────────────────────────
 * Returns uint64_t bitmask: bit i=1 means pkts[i] is GROUND.
 * n must be ≤ 64. Caller skips tgw_write for GROUND bits.
 *
 * Cost: ~5ns/pkt vs 233ns/pkt for tgw_write.
 * Saves: 233ns × (GROUND fraction × N) per batch.
 * Typical GROUND ~50% (polarity split) → saves ~116ns/pkt average.
 */
static inline uint64_t tgwlc_gate_batch(
    const uint32_t *enc_addrs,   /* pkts[i].enc used as addr */
    const uint32_t *enc_vals,    /* pkts[i].enc used as value (or same) */
    uint32_t        n)           /* n ≤ 64 */
{
    uint64_t ground_mask = 0u;
    for (uint32_t i = 0; i < n && i < 64u; i++) {
        BridgeGate g = tgwlc_gate(enc_addrs[i], enc_vals[i]);
        if (g == BRIDGE_GATE_GROUND || g == BRIDGE_GATE_WARP)
            ground_mask |= (UINT64_C(1) << i);
    }
    return ground_mask;
}

/* ── P4: prefilter stream pkts → ground_mask ─────────────────────
 * Operates on TStreamPkt array directly.
 * enc used as both addr and value key (matches stream_dispatch logic).
 *
 * Usage in tgw_stream_dispatch:
 *   uint64_t gnd = tgwlc_prefilter(pkts, n);
 *   for i: if (gnd >> i) & 1 → pl_write; else → tgw_write + dispatch
 */
#include "geo_tring_stream.h"   /* TStreamPkt */

static inline uint64_t tgwlc_prefilter(const TStreamPkt *pkts, uint16_t n)
{
    uint64_t ground_mask = 0u;
    uint16_t lim = (n > 64u) ? 64u : n;
    for (uint16_t i = 0; i < lim; i++) {
        /* polarity from TRing position — fast path, no LCHdr pack needed */
        uint16_t pos      = (uint16_t)(pkts[i].enc % TGWLC_TRING_CYCLE);
        uint8_t  polarity = (uint8_t)((pos % TGWLC_PENTAGON_SZ)
                                       >= (TGWLC_PENTAGON_SZ / 2));
        if (polarity) ground_mask |= (UINT64_C(1) << i);
    }
    return ground_mask;
}

/* ── P4: spoke histogram (batch) ─────────────────────────────────
 * Count pkt distribution across 6 spokes in one pass.
 * Use after stream to verify uniform coverage (no enc skew).
 */
static inline void tgwlc_spoke_hist(
    const TStreamPkt *pkts, uint16_t n,
    uint32_t hist[TGWLC_SPOKES])
{
    for (uint8_t s = 0; s < TGWLC_SPOKES; s++) hist[s] = 0u;
    for (uint16_t i = 0; i < n; i++) {
        uint16_t pos   = (uint16_t)(pkts[i].enc % TGWLC_TRING_CYCLE);
        uint8_t  spoke = tgwlc_pos_to_spoke(pos);
        hist[spoke]++;
    }
}

#endif /* TGW_LC_BRIDGE_H */
