/*
 * tgw_dispatch.h — TGW Full Dispatch Layer (P4 upgrade)
 * =========================================
 * P4 changes vs original:
 *   - tgw_dispatch_batch(): accumulate ROUTE pkts → single tgw_batch() call
 *     amortizes goldberg_pipeline_batch + twin_bridge_batch overhead
 *   - tgw_dispatch_flush(): drain pending batch (call at end of stream)
 *   - TGWDispatch gains: pending_addrs[], pending_vals[], pending_n
 *   - GROUND path unchanged (pl_write direct, zero cost)
 *   - geomatrix_batch_verdict still runs per-blueprint (unchanged)
 *
 * P4 speedup target: 233 ns/call → <100 ns amortized
 *   Savings come from:
 *     twin_bridge_batch: te_batch_accumulate(N) vs N×te_tick  (~40% gain)
 *     goldberg_pipeline_batch: bulk addr fold vs N×serial      (~30% gain)
 *
 * Sacred constants (frozen):
 *   720  = TRING_CYCLE
 *   144  = GBT_WINDOW / fibo flush boundary
 *   18   = GEOMATRIX_PATHS
 *   128/144 = GEO_WINDOW_LO/HI
 */

#ifndef TGW_DISPATCH_H
#define TGW_DISPATCH_H

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "geo_tring_goldberg_wire.h"
#include "../pogls_engine/fgls_twin_store.h"
#include "geo_payload_store.h"
#include "../pogls_engine/lc_twin_gate.h"

/* ── P4: batch accumulator size ─────────────────────────────────
 * 64 = sweet spot: fits L1 cache (64×8×2 = 1KB), amortizes well
 * Must be ≤ TSTREAM_MAX_PKTS (720). Power-of-2 for branch-free flush.
 */
#define TGW_DISPATCH_BATCH_MAX  64u

/* ── blueprint → GeoPacket ──────────────────────────────────────  */
static inline GeoPacket _tgwd_bp_to_pkt(const GBBlueprint *bp,
                                          const uint64_t    *bundle,
                                          uint8_t            path_id)
{
    GeoPacket pkt;
    memset(&pkt, 0, sizeof(pkt));

    pkt.phase = (uint8_t)((bp->circuit_fired + path_id) & 0x3u);
    pkt.sig   = geo_compute_sig64(bundle, pkt.phase);

    uint16_t h_end   = (uint16_t)(bp->tring_end   % GEO_SLOTS);
    uint16_t h_start = (uint16_t)(bp->tring_start % GEO_SLOTS);

    pkt.hpos = h_end;
    bool hb = (h_end   >= GEO_BLOCK_BOUNDARY);
    bool ib = (h_start >= GEO_BLOCK_BOUNDARY);
    if (hb != ib)
        pkt.idx = hb ? (uint16_t)(h_start + GEO_BLOCK_BOUNDARY)
                     : (uint16_t)(h_start % GEO_BLOCK_BOUNDARY);
    else
        pkt.idx = h_start;

    pkt.bit = (uint8_t)(bp->stamp_hash & 0x1u);
    return pkt;
}

/* ── blueprint → DodecaEntry ────────────────────────────────────  */
static inline DodecaEntry _tgwd_bp_to_dodeca(const GBBlueprint *bp)
{
    DodecaEntry e;
    memset(&e, 0, sizeof(e));
    e.merkle_root = (uint64_t)bp->stamp_hash
                  | ((uint64_t)bp->stamp_hash << 32);
    e.sha256_hi   = (uint64_t)bp->spatial_xor;
    e.sha256_lo   = bp->window_id;
    e.offset      = bp->circuit_fired;
    e.hop_count   = bp->tring_span;
    e.segment     = bp->top_gaps[0];
    return e;
}

/* ── Dispatch context ───────────────────────────────────────────  */
typedef struct {
    FtsTwinStore    fts;
    PayloadStore    ps;
    LCTwinGateCtx   lc;

    /* P4: pending ROUTE batch */
    uint64_t        pending_addrs[TGW_DISPATCH_BATCH_MAX];
    uint64_t        pending_vals [TGW_DISPATCH_BATCH_MAX];
    uint32_t        pending_n;

    /* counters */
    uint32_t        total_dispatched;
    uint32_t        route_count;
    uint32_t        ground_count;
    uint32_t        verdict_fail;
    uint32_t        no_blueprint;
    uint32_t        batch_flushes;   /* P4: how many batch flushes fired */
} TGWDispatch;

typedef struct {
    uint32_t total_dispatched;
    uint32_t route_count;
    uint32_t ground_count;
    uint32_t verdict_fail;
    uint32_t no_blueprint;
    uint32_t batch_flushes;
    FtsTwinStats fts;
} TGWDispatchStats;

/* ── Init ───────────────────────────────────────────────────────  */
static inline void tgw_dispatch_init(TGWDispatch *d, uint64_t root_seed)
{
    memset(d, 0, sizeof(*d));
    fts_init(&d->fts, root_seed);
    pl_init(&d->ps);
    lc_twin_gate_init(&d->lc);
}

/* ── P4: internal batch flush ───────────────────────────────────
 * Drains pending_addrs/vals into tgw_batch() in one shot.
 * Called automatically when buffer full, or manually at stream end.
 */
static inline void _tgwd_flush_batch(TGWDispatch *d, TGWCtx *ctx)
{
    if (d->pending_n == 0) return;
    tgw_batch(ctx, d->pending_addrs, d->pending_vals, d->pending_n, 0);
    d->pending_n = 0;
    d->batch_flushes++;
}

/* ── Core dispatch (single write, P4-aware) ─────────────────────
 * GROUND path: immediate pl_write (unchanged, zero overhead)
 * ROUTE path:  accumulate into batch → flush when full
 *
 * NOTE: blueprint verdict still runs per-write (geomatrix_batch_verdict
 * needs the blueprint from that specific tgw_write result).
 * The batch optimization targets twin_bridge + goldberg inner loops.
 */
static inline void tgw_dispatch(TGWDispatch    *d,
                                  TGWCtx         *ctx,   /* P4: added ctx */
                                  const TGWResult *r,
                                  uint64_t         addr,
                                  uint64_t         value,
                                  const uint64_t  *bundle)
{
    d->total_dispatched++;

    /* ── GROUND gate: polarity check (unchanged) ─────────────  */
    {
        LCHdr hA = lc_hdr_encode_addr(addr);
        LCHdr hB = lc_hdr_encode_value(value);
        LCGate gate = lch_gate(hA, hB, d->lc.palette_a, d->lc.palette_b);
        if (gate == LC_GATE_GROUND) {
            pl_write(&d->ps, addr, value);
            d->lc.gate_counts[LC_GATE_GROUND]++;
            d->ground_count++;
            return;
        }
    }

    /* ── no blueprint yet: accumulate addr/val for batch ──────  */
    if (!r->gpr.blueprint_ready) {
        d->no_blueprint++;
        /* still feed into batch — tgw_batch handles pre-blueprint state */
        d->pending_addrs[d->pending_n] = addr;
        d->pending_vals [d->pending_n] = value;
        d->pending_n++;
        if (d->pending_n >= TGW_DISPATCH_BATCH_MAX)
            _tgwd_flush_batch(d, ctx);
        return;
    }

    /* ── blueprint ready: verdict → ROUTE or GROUND ──────────  */
    const GBBlueprint *bp = &r->gpr.bp;

    GeoPacket batch[GEOMATRIX_PATHS];
    for (int p = 0; p < GEOMATRIX_PATHS; p++)
        batch[p] = _tgwd_bp_to_pkt(bp, bundle, (uint8_t)p);

    GeomatrixStatsV3 stats = {0};
    bool verdict = geomatrix_batch_verdict(batch, bundle, &stats);

    if (verdict) {
        /* ROUTE: accumulate in batch buffer */
        d->pending_addrs[d->pending_n] = addr;
        d->pending_vals [d->pending_n] = value;
        d->pending_n++;
        if (d->pending_n >= TGW_DISPATCH_BATCH_MAX)
            _tgwd_flush_batch(d, ctx);

        /* fts_write uses blueprint fields (independent of tgw_batch) */
        DodecaEntry e       = _tgwd_bp_to_dodeca(bp);
        uint64_t route_addr = (uint64_t)bp->stamp_hash;
        uint64_t route_val  = (uint64_t)bp->spatial_xor;
        fts_write(&d->fts, route_addr, route_val, &e);
        d->route_count++;
    } else {
        /* verdict=false → GROUND fallback (flush pending first) */
        _tgwd_flush_batch(d, ctx);   /* boundary: don't mix failed into batch */
        pl_write(&d->ps, addr, value);
        d->verdict_fail++;
        d->ground_count++;
    }
}

/* ── P4: explicit flush (call after stream end) ─────────────────  */
static inline void tgw_dispatch_flush(TGWDispatch *d, TGWCtx *ctx)
{
    _tgwd_flush_batch(d, ctx);
}

/* ── Convenience: tgw_write + dispatch in one call ──────────────  */
static inline TGWResult tgw_write_dispatch(TGWCtx      *ctx,
                                             TGWDispatch *d,
                                             uint64_t     addr,
                                             uint64_t     value,
                                             uint8_t      slot_hot)
{
    TGWResult r = tgw_write(ctx, addr, value, slot_hot);
    tgw_dispatch(d, ctx, &r, addr, value, ctx->_bundle);
    return r;
}

/* ── Stats ──────────────────────────────────────────────────────  */
static inline TGWDispatchStats tgw_dispatch_stats(const TGWDispatch *d)
{
    TGWDispatchStats s;
    s.total_dispatched = d->total_dispatched;
    s.route_count      = d->route_count;
    s.ground_count     = d->ground_count;
    s.verdict_fail     = d->verdict_fail;
    s.no_blueprint     = d->no_blueprint;
    s.batch_flushes    = d->batch_flushes;
    s.fts              = fts_stats(&d->fts);
    return s;
}

/* ── Pending count (debug / bench) ──────────────────────────────  */
static inline uint32_t tgw_dispatch_pending(const TGWDispatch *d)
{
    return d->pending_n;
}

#endif /* TGW_DISPATCH_H */
