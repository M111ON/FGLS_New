/*
 * tgw_stream_dispatch.h — Stream-Aware Dispatch (P4 upgrade)
 * ==============================================================
 * P4 changes vs P1/P3:
 *   - Uses tgw_dispatch() batch path (no more per-pkt tgw_write)
 *   - ROUTE pkts accumulate in TGWDispatch.pending[] → tgw_batch flush
 *   - GROUND path still direct pl_write (zero overhead, unchanged)
 *   - tgw_dispatch_flush() called after loop to drain remainder
 *   - CRC LUT + smart memset from tgw_stream_opt.h baked in (P3)
 *   - caller-owned pkt buffer (OPT3) — no stack alloc inside dispatch
 *
 * P4 pipeline flow:
 *   file → tstream_slice_file_opt (CRC LUT, smart memset)
 *        → tring_route_from_enc   (O(1) LUT, stateless)
 *        → GROUND: pl_write       (immediate)
 *        → ROUTE:  tgw_dispatch() → batch accumulate
 *                  → tgw_batch()  when full (twin+goldberg amortized)
 *   end  → tgw_dispatch_flush()   (drain remainder)
 *
 * Sacred constants (frozen):
 *   720 = TRING_CYCLE, 60 = PENT_SPAN, 30 = mirror boundary, 6 = spokes
 */

#ifndef TGW_STREAM_DISPATCH_H
#define TGW_STREAM_DISPATCH_H

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "geo_tring_goldberg_wire.h"
#include "tgw_dispatch.h"        /* P4 batch-aware dispatch */
#include "crc16_lut.h"           /* P3 CRC LUT */

/* ── TRing geometry constants ────────────────────────────────── */
#define TRING_PENT_SPAN   60u
#define TRING_MIRROR_HALF 30u
#define TRING_SPOKES       6u

/* ── TRingRoute (unchanged from P1) ─────────────────────────── */
typedef struct {
    uint16_t pos;
    uint8_t  pentagon;
    uint8_t  spoke;
    uint8_t  polarity;   /* 0=ROUTE, 1=GROUND */
} TRingRoute;

static inline TRingRoute tring_route_from_enc(uint32_t enc)
{
    TRingRoute rt;
    rt.pos = tring_pos(enc);
    if (rt.pos == 0xFFFFu) {
        rt.pentagon = 0; rt.spoke = 0; rt.polarity = 1;
        return rt;
    }
    rt.pentagon = (uint8_t)(rt.pos / TRING_PENT_SPAN);
    rt.spoke    = (uint8_t)(rt.pentagon % TRING_SPOKES);
    rt.polarity = (uint8_t)((rt.pos % TRING_PENT_SPAN) >= TRING_MIRROR_HALF);
    return rt;
}

/* ── Stream stats ────────────────────────────────────────────── */
typedef struct {
    uint32_t pkts_rx;
    uint32_t pkts_ground;
    uint32_t pkts_route;
    uint32_t pkts_gap;
    uint32_t pkts_no_bp;
} TGWStreamStats;

typedef struct {
    TGWStreamStats ss;
} TGWStreamDispatch;

static inline void tgw_stream_dispatch_init(TGWStreamDispatch *sd)
{
    memset(sd, 0, sizeof(*sd));
}

/* ── P3: CRC LUT inline (from crc16_lut.h) ──────────────────── */
static inline uint16_t _tsd_crc16(const uint8_t *buf, uint16_t len)
{
    uint16_t crc = 0xFFFFu;
    for (uint16_t i = 0; i < len; i++)
        crc = (uint16_t)((crc << 8) ^ _crc16_lut[(crc >> 8) ^ buf[i]]);
    return crc;
}

/* ── P3+P4: slice with caller-owned buffer ───────────────────── */
static inline uint16_t tstream_slice_opt(
    TStreamPkt *out_pkts, const uint8_t *file, uint32_t fsize)
{
    if (!fsize) return 0u;
    uint16_t n = (uint16_t)((fsize + TSTREAM_DATA_BYTES - 1u) / TSTREAM_DATA_BYTES);
    if (n > TSTREAM_MAX_PKTS) return 0u;
    for (uint16_t i = 0; i < n; i++) {
        TStreamPkt *p = &out_pkts[i];
        uint32_t off  = (uint32_t)i * TSTREAM_DATA_BYTES;
        uint16_t sz   = (uint16_t)((off + TSTREAM_DATA_BYTES <= fsize)
                                    ? TSTREAM_DATA_BYTES : fsize - off);
        p->enc  = GEO_WALK[i];
        p->size = sz;
        if (sz < TSTREAM_DATA_BYTES)
            memset(p->data + sz, 0, TSTREAM_DATA_BYTES - sz); /* OPT2 */
        memcpy(p->data, file + off, sz);
        p->crc16 = _tsd_crc16(p->data, sz);                  /* OPT1 */
    }
    return n;
}

/* ── P4: main dispatch (caller-owns pkt buf) ─────────────────── */
/*
 * pkts: caller-allocated TStreamPkt[TSTREAM_MAX_PKTS] — no stack alloc
 * Returns packets processed.
 * MUST call tgw_dispatch_flush(d, ctx) after this returns.
 */
static inline uint16_t tgw_stream_dispatch(
    TGWCtx            *ctx,
    TGWDispatch       *d,
    TGWStreamDispatch *sd,
    TStreamPkt        *pkts,        /* P4: caller-owned */
    const uint8_t     *data,
    uint32_t           size)
{
    uint16_t n = tstream_slice_opt(pkts, data, size);

    for (uint16_t i = 0; i < n; i++) {

        int snap = tstream_recv_pkt(&ctx->tr, ctx->store, &pkts[i]);
        if (snap < 0) {
            sd->ss.pkts_gap++;
            ctx->stream_gaps++;
            continue;
        }
        ctx->stream_pkts_rx++;

        TRingRoute rt    = tring_route_from_enc(pkts[i].enc);
        uint64_t addr    = (uint64_t)pkts[i].enc;
        uint64_t value   = (uint64_t)pkts[i].crc16
                         | ((uint64_t)pkts[i].size << 16);

        /* ── GROUND: direct, zero overhead ──────────────────── */
        if (rt.polarity == 1) {
            pl_write(&d->ps, addr, value);
            d->ground_count++;
            d->total_dispatched++;
            sd->ss.pkts_ground++;
            sd->ss.pkts_rx++;
            continue;
        }

        /* ── ROUTE: feed through P4 batch dispatch ───────────
         * tgw_write runs once per pkt (blueprint accumulation),
         * but twin_bridge + goldberg inner loops are batched.
         */
        TGWResult r = tgw_write(ctx, addr, value, 0);
        tgw_dispatch(d, ctx, &r, addr, value, ctx->_bundle);

        if (!r.gpr.blueprint_ready)
            sd->ss.pkts_no_bp++;
        else
            sd->ss.pkts_route++;

        sd->ss.pkts_rx++;
    }

    /* ── drain remainder (caller may also call explicitly) ───── */
    tgw_dispatch_flush(d, ctx);

    return n;
}

/* ── Stats ───────────────────────────────────────────────────── */
static inline TGWStreamStats tgw_stream_dispatch_stats(
    const TGWStreamDispatch *sd)
{
    return sd->ss;
}

/* ── Spoke coverage (debug) ──────────────────────────────────── */
static inline void tgw_stream_spoke_coverage(
    const TStreamPkt *pkts, uint16_t n,
    uint32_t counts[TRING_SPOKES])
{
    for (uint8_t s = 0; s < TRING_SPOKES; s++) counts[s] = 0;
    for (uint16_t i = 0; i < n; i++) {
        TRingRoute rt = tring_route_from_enc(pkts[i].enc);
        if (rt.pos != 0xFFFFu) counts[rt.spoke]++;
    }
}

#endif /* TGW_STREAM_DISPATCH_H */
