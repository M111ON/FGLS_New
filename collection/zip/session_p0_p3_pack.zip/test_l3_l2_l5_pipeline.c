#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "geo_tring_goldberg_wire.h"
#include "tgw_stream_dispatch.h"

static int pass=0,fail=0;
#define CHK(cond,msg) \
    if(cond){printf("  OK %s\n",msg);pass++;} \
    else    {printf("  XX FAIL: %s\n",msg);fail++;}
static void fill(uint8_t*b,uint32_t n,uint32_t s){for(uint32_t i=0;i<n;i++)b[i]=(uint8_t)((i*17u+s)&0xFF);}

int main(void){
    printf("P2: L3->L2->L5 Pipeline\n\n");

    static uint64_t bundle[GEO_BUNDLE_WORDS];
    for(int i=0;i<GEO_BUNDLE_WORDS;i++) bundle[i]=0xDEADBEEF00000000ull^(uint64_t)i;
    GeoSeed seed={0xABCD1234EF567890ull,0x0FEDCBA987654321ull};
    TGWCtx ctx; tgw_init(&ctx,seed,bundle);
    TGWDispatch d; tgw_dispatch_init(&d,0x1122334455667788ull);
    TGWStreamDispatch sd; tgw_stream_dispatch_init(&sd);

    /* T1 */
    printf("[T1] init\n");
    TGWStats s0=tgw_stats(&ctx);
    CHK(s0.total_writes==0,"total_writes=0")
    CHK(d.total_dispatched==0,"dispatcher=0")

    /* T2 */
    printf("[T2] stream 4KB\n");
    static uint8_t data[4096]; fill(data,4096,53);
    uint16_t n=tgw_stream_dispatch(&ctx,&d,&sd,data,4096);
    printf("  sliced=%u rx=%u route=%u ground=%u no_bp=%u\n",
           n,sd.ss.pkts_rx,sd.ss.pkts_route,sd.ss.pkts_ground,sd.ss.pkts_no_bp);
    CHK(n>0,"sliced>0")
    CHK(sd.ss.pkts_rx==sd.ss.pkts_route+sd.ss.pkts_ground+sd.ss.pkts_no_bp,"rx=R+G+nobp")

    /* T3 */
    printf("[T3] dispatch balance\n");
    printf("  total=%u R=%u G=%u nobp=%u\n",d.total_dispatched,d.route_count,d.ground_count,d.no_blueprint);
    CHK(d.route_count+d.ground_count+d.no_blueprint==d.total_dispatched,"R+G+nobp=total")

    /* T4 */
    printf("[T4] pipeline active\n");
    CHK(d.total_dispatched>0||d.no_blueprint>0,"pipeline active")

    /* T5: LUT distribution */
    printf("[T5] LUT 2048->720 valid\n");
    uint32_t spk[6]={0},rc=0,gc=0;
    for(uint32_t e=0;e<2048;e++){
        TRingRoute rt=tring_route_from_enc(e);
        if(rt.pos==0xFFFFu)continue;
        spk[rt.spoke]++;
        if(rt.polarity)gc++;else rc++;
    }
    printf("  R=%u G=%u  ",rc,gc);
    for(int s=0;s<6;s++)printf("s%d=%u ",s,spk[s]);printf("\n");
    CHK(rc==360&&gc==360,"360R+360G")
    int uni=1;for(int s=0;s<6;s++)if(spk[s]!=120){uni=0;break;}
    CHK(uni,"6spokes*120")

    /* T6: polarity */
    printf("[T6] polarity math\n");
    int pol=1;
    for(uint32_t e=0;e<2048;e++){
        TRingRoute rt=tring_route_from_enc(e);
        if(rt.pos==0xFFFFu)continue;
        if(rt.polarity!=(uint8_t)((rt.pos%60)>=30)){pol=0;break;}
    }
    CHK(pol,"pol=pos%60>=30")

    /* T7: L5 writes */
    printf("[T7] L5 writes\n");
    TGWStats sf=tgw_stats(&ctx);
    CHK(sf.total_writes>0,"L5 writes>0")

    /* T8: loop until blueprint (144 writes threshold) */
    printf("[T8] loop until blueprint (max 128 iters x 64KB)\n");
    static uint8_t big[65536];
    TGWStats sf2;
    uint32_t it=0;
    while(it<128){
        fill(big,65536,it*31u+7u);
        tgw_stream_dispatch(&ctx,&d,&sd,big,65536);
        sf2=tgw_stats(&ctx);
        it++;
        if(sf2.blueprint_count>0) break;
    }
    printf("  iters=%u writes=%u blueprints=%u routes=%u\n",
           it,sf2.total_writes,sf2.blueprint_count,d.route_count);
    CHK(sf2.blueprint_count>0,"blueprint fired")
    CHK(d.route_count>0,"route_count>0")

    /* T9: FtsTwinStore */
    printf("[T9] FtsTwinStore\n");
    TGWDispatchStats ds=tgw_dispatch_stats(&d);
    printf("  fts.writes=%u\n",ds.fts.writes);
    CHK(ds.fts.writes>0,"fts.writes>0")

    /* T10: final invariant */
    printf("[T10] final balance\n");
    CHK(d.route_count+d.ground_count+d.no_blueprint==d.total_dispatched,"R+G+nobp=total(final)")

    printf("\nPASS=%d FAIL=%d\n",pass,fail);
    return fail?1:0;
}
