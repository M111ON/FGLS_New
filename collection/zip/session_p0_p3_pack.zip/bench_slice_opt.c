#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include "geo_tring_goldberg_wire.h"
#include "tgw_stream_dispatch.h"
#include "tgw_stream_opt.h"

static uint64_t ns_now(void){
    struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
    return (uint64_t)t.tv_sec*1e9+(uint64_t)t.tv_nsec;
}
static void fill(uint8_t*b,uint32_t n,uint32_t s){
    for(uint32_t i=0;i<n;i++)b[i]=(uint8_t)((i*17u+s)&0xFF);
}

#define ITERS   512
#define SZ      65536u

int main(void){
    printf("╔══════════════════════════════════════════════════════════╗\n");
    printf("║  Stream Slice Optimization — Baseline vs OPT            ║\n");
    printf("╚══════════════════════════════════════════════════════════╝\n\n");

    static uint8_t data[SZ];
    static TStreamPkt pkt_buf[TSTREAM_MAX_PKTS];  /* caller-owned */

    /* ── CRC16 accuracy check first ── */
    printf("▶ CRC16 accuracy: baseline vs LUT\n");
    fill(data,SZ,42);
    int crc_ok=1;
    for(uint32_t off=0;off<SZ;off+=256){
        uint16_t sz=(uint16_t)(off+256<=SZ?256:SZ-off);
        uint16_t base=_tstream_crc16(data+off,sz);
        uint16_t opt =_crc16_opt   (data+off,sz);
        if(base!=opt){crc_ok=0;printf("  MISMATCH off=%u base=%04X opt=%04X\n",off,base,opt);break;}
    }
    printf("  CRC16 LUT matches baseline: %s\n\n", crc_ok?"YES ✅":"NO ❌");
    if(!crc_ok) return 1;

    /* ── BENCH A: CRC16 byte-loop vs LUT (4096B × 1M) ── */
    printf("▶ BENCH A: CRC16 per-pkt (4096B, 500K calls)\n");
    fill(data,4096,99);
    {
        volatile uint32_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<500000;i++)
            sink+=_tstream_crc16(data,(uint16_t)(i%4096+1));
        uint64_t dt=ns_now()-t0;
        printf("  baseline: %.1f ns/call  (sink=%u)\n",(double)dt/500000.0,(unsigned)sink);
    }
    {
        volatile uint32_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<500000;i++)
            sink+=_crc16_opt(data,(uint16_t)(i%4096+1));
        uint64_t dt=ns_now()-t0;
        printf("  LUT opt:  %.1f ns/call  (sink=%u)\n\n",(double)dt/500000.0,(unsigned)sink);
    }

    /* ── BENCH B: tstream_slice_file vs _opt (64KB × ITERS) ── */
    printf("▶ BENCH B: slice_file  baseline vs opt  (%u × 64KB)\n", ITERS);
    {
        static TStreamPkt stack_buf[TSTREAM_MAX_PKTS]; /* baseline uses stack inside */
        volatile uint32_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<ITERS;i++){
            fill(data,SZ,i);
            uint16_t n=tstream_slice_file(stack_buf,data,SZ);
            sink+=n;
        }
        uint64_t dt=ns_now()-t0;
        double mb_s=((double)ITERS*SZ/1048576.0)/((double)dt/1e9);
        printf("  baseline: %.1f MB/s  (pkts=%u)\n", mb_s,(unsigned)sink);
    }
    {
        volatile uint32_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<ITERS;i++){
            fill(data,SZ,i);
            uint16_t n=tstream_slice_file_opt(pkt_buf,data,SZ);
            sink+=n;
        }
        uint64_t dt=ns_now()-t0;
        double mb_s=((double)ITERS*SZ/1048576.0)/((double)dt/1e9);
        printf("  OPT:      %.1f MB/s  (pkts=%u)\n\n", mb_s,(unsigned)sink);
    }

    /* ── BENCH C: full pipeline baseline vs opt (256 × 64KB) ── */
    printf("▶ BENCH C: full pipeline  baseline vs opt  (256 × 64KB)\n");
    GeoSeed seed={0xABCD1234EF567890ull,0x0FEDCBA987654321ull};
    static uint64_t bundle[GEO_BUNDLE_WORDS];
    for(int i=0;i<GEO_BUNDLE_WORDS;i++) bundle[i]=0xDEADBEEFull^(uint64_t)i;

    /* baseline */
    {
        static TGWCtx ctx; tgw_init(&ctx,seed,bundle);
        static TGWDispatch d; tgw_dispatch_init(&d,0x1122ull);
        static TGWStreamDispatch sd; tgw_stream_dispatch_init(&sd);
        uint64_t tot=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<256;i++){
            fill(data,SZ,i*7u+3u);
            tgw_stream_dispatch(&ctx,&d,&sd,data,SZ);
            tot+=SZ;
        }
        uint64_t dt=ns_now()-t0;
        double mb_s=((double)tot/1048576.0)/((double)dt/1e9);
        TGWStats sf=tgw_stats(&ctx);
        printf("  baseline: %.1f MB/s  writes=%u blueprints=%u routes=%u\n",
               mb_s,sf.total_writes,sf.blueprint_count,d.route_count);
    }

    /* opt */
    {
        static TGWCtx ctx2; tgw_init(&ctx2,seed,bundle);
        static TGWDispatch d2; tgw_dispatch_init(&d2,0x1122ull);
        static TGWStreamDispatch sd2; tgw_stream_dispatch_init(&sd2);
        uint64_t tot=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<256;i++){
            fill(data,SZ,i*7u+3u);
            uint16_t n=tstream_slice_file_opt(pkt_buf,data,SZ);
            tgw_stream_dispatch_opt(&ctx2,&d2,&sd2,pkt_buf,n);
            tot+=SZ;
        }
        uint64_t dt=ns_now()-t0;
        double mb_s=((double)tot/1048576.0)/((double)dt/1e9);
        TGWStats sf=tgw_stats(&ctx2);
        printf("  OPT:      %.1f MB/s  writes=%u blueprints=%u routes=%u\n\n",
               mb_s,sf.total_writes,sf.blueprint_count,d2.route_count);
    }

    printf("══════════════════════════════════════════════════════════\n");
    return 0;
}
