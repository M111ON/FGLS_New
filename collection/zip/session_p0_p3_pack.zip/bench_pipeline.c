#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include "geo_tring_goldberg_wire.h"
#include "tgw_stream_dispatch.h"

static uint64_t ns_now(void){
    struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
    return (uint64_t)t.tv_sec*1000000000ull+(uint64_t)t.tv_nsec;
}
static void fill(uint8_t*b,uint32_t n,uint32_t s){
    for(uint32_t i=0;i<n;i++)b[i]=(uint8_t)((i*17u+s)&0xFF);
}

#define BENCH_ITERS   256
#define CHUNK_SZ      65536   /* 64KB per iter */
#define WARMUP_ITERS  16

int main(void){
    printf("╔═══════════════════════════════════════════════════════╗\n");
    printf("║  P3: L3→L2→L5 Pipeline Benchmark                    ║\n");
    printf("╚═══════════════════════════════════════════════════════╝\n\n");

    static uint64_t bundle[GEO_BUNDLE_WORDS];
    for(int i=0;i<GEO_BUNDLE_WORDS;i++) bundle[i]=0xDEADBEEF00000000ull^(uint64_t)i;
    GeoSeed seed={0xABCD1234EF567890ull,0x0FEDCBA987654321ull};

    static TGWCtx ctx; tgw_init(&ctx,seed,bundle);
    static TGWDispatch d; tgw_dispatch_init(&d,0x1122334455667788ull);
    static TGWStreamDispatch sd; tgw_stream_dispatch_init(&sd);

    static uint8_t buf[CHUNK_SZ];

    /* ── warmup ── */
    printf("Warmup (%d iters)...\n", WARMUP_ITERS);
    for(int i=0;i<WARMUP_ITERS;i++){
        fill(buf,CHUNK_SZ,(uint32_t)i);
        tgw_stream_dispatch(&ctx,&d,&sd,buf,CHUNK_SZ);
    }
    TGWStats sw=tgw_stats(&ctx);
    printf("  writes=%u blueprints=%u routes=%u\n\n",
           sw.total_writes,sw.blueprint_count,d.route_count);

    /* ── BENCH 1: tring_route_from_enc (stateless LUT, hottest path) ── */
    printf("▶ BENCH 1: tring_route_from_enc (LUT, 2M calls)\n");
    {
        volatile uint32_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t rep=0;rep<2000000;rep++){
            TRingRoute rt=tring_route_from_enc(rep&0x7FFu);
            sink+=rt.pos;
        }
        uint64_t dt=ns_now()-t0;
        double ns_per=((double)dt)/2000000.0;
        double mops=2000.0/((double)dt/1e9);
        printf("  2M calls: %.1f ns/call  %.1f Mop/s  (sink=%u)\n\n",
               ns_per,mops,(unsigned)sink);
    }

    /* ── BENCH 2: tgw_write (L2 core, single enc→L5 write) ── */
    printf("▶ BENCH 2: tgw_write (L2→L5 core, 200K calls)\n");
    {
        volatile uint32_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<200000;i++){
            TGWResult r=tgw_write(&ctx,(uint64_t)i,(uint64_t)(i^0xDEAD),0);
            sink+=(uint32_t)r.gpr.blueprint_ready;
        }
        uint64_t dt=ns_now()-t0;
        double ns_per=((double)dt)/200000.0;
        double mops=200.0/((double)dt/1e9);
        printf("  200K calls: %.1f ns/call  %.2f Mop/s  blueprints=%u\n\n",
               ns_per,mops,(unsigned)sink);
    }

    /* ── BENCH 3: tgw_stream_dispatch (full pipeline, 256 × 64KB) ── */
    printf("▶ BENCH 3: tgw_stream_dispatch (full pipeline, %d × %dKB)\n",
           BENCH_ITERS, CHUNK_SZ/1024);
    {
        /* reset ctx for clean measurement */
        static TGWCtx ctx2; tgw_init(&ctx2,seed,bundle);
        static TGWDispatch d2; tgw_dispatch_init(&d2,0x1122334455667788ull);
        static TGWStreamDispatch sd2; tgw_stream_dispatch_init(&sd2);

        uint64_t total_bytes=0, total_pkts=0;
        uint64_t t0=ns_now();
        for(int i=0;i<BENCH_ITERS;i++){
            fill(buf,CHUNK_SZ,(uint32_t)i*7u+13u);
            uint16_t n=tgw_stream_dispatch(&ctx2,&d2,&sd2,buf,CHUNK_SZ);
            total_bytes+=CHUNK_SZ;
            total_pkts+=n;
        }
        uint64_t dt=ns_now()-t0;
        double secs=(double)dt/1e9;
        double mb_s=((double)total_bytes/1048576.0)/secs;
        double mp_s=((double)total_pkts/1e6)/secs;
        TGWStats sf=tgw_stats(&ctx2);
        printf("  %.1f MB in %.3fs → %.1f MB/s  pkts=%.0fK (%.2f Mp/s)\n",
               (double)total_bytes/1048576.0, secs, mb_s,
               (double)total_pkts/1000.0, mp_s);
        printf("  writes=%u blueprints=%u routes=%u grounds=%u\n\n",
               sf.total_writes,sf.blueprint_count,d2.route_count,d2.ground_count);
    }

    /* ── BENCH 4: LUT full-cycle throughput (720 valid enc) ── */
    printf("▶ BENCH 4: LUT full-cycle (720 valid, 1M cycles)\n");
    {
        /* pre-build valid enc list */
        uint16_t valid_enc[720]; uint32_t vc=0;
        for(uint32_t e=0;e<2048&&vc<720;e++){
            TRingRoute rt=tring_route_from_enc(e);
            if(rt.pos!=0xFFFFu) valid_enc[vc++]=(uint16_t)e;
        }
        volatile uint64_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t rep=0;rep<1000000;rep++)
            for(uint32_t i=0;i<720;i++){
                TRingRoute rt=tring_route_from_enc(valid_enc[i]);
                sink+=rt.pos;
            }
        uint64_t dt=ns_now()-t0;
        double total_ops=720e0*1e6;
        double gops=total_ops/((double)dt);
        printf("  720M route ops: %.3f Gop/s  (sink=%llu)\n\n",
               gops,(unsigned long long)sink);
    }

    /* ── BENCH 5: tgw_dispatch standalone (blueprint→verdict) ── */
    printf("▶ BENCH 5: tgw_dispatch (blueprint verdict path)\n");
    {
        /* prime pipeline until blueprint ready */
        static TGWCtx ctx3; tgw_init(&ctx3,seed,bundle);
        static TGWDispatch d3; tgw_dispatch_init(&d3,0x1122334455667788ull);
        static TGWStreamDispatch sd3; tgw_stream_dispatch_init(&sd3);
        uint32_t it=0;
        while(tgw_stats(&ctx3).blueprint_count==0&&it<256){
            fill(buf,CHUNK_SZ,it*31u+7u);
            tgw_stream_dispatch(&ctx3,&d3,&sd3,buf,CHUNK_SZ);
            it++;
        }
        printf("  primed in %u iters (writes=%u)\n",
               it,tgw_stats(&ctx3).total_writes);

        /* now bench dispatch with blueprint-ready writes */
        uint32_t N=50000;
        volatile uint32_t sink=0;
        uint64_t t0=ns_now();
        for(uint32_t i=0;i<N;i++){
            TGWResult r=tgw_write(&ctx3,(uint64_t)(i+1),(uint64_t)(i^0xBEEF),0);
            tgw_dispatch(&d3,&r,(uint64_t)(i+1),(uint64_t)(i^0xBEEF),bundle);
            sink+=d3.route_count;
        }
        uint64_t dt=ns_now()-t0;
        double ns_per=((double)dt)/(double)N;
        printf("  %uK dispatch calls: %.1f ns/call  routes=%u\n\n",
               N/1000,ns_per,d3.route_count);
    }

    /* ── summary table ── */
    TGWStats sfin=tgw_stats(&ctx);
    printf("══════════════════════════════════════════════════════\n");
    printf("Pipeline state at end:\n");
    printf("  total_writes=%u  blueprints=%u  routes=%u  grounds=%u\n",
           sfin.total_writes,sfin.blueprint_count,d.route_count,d.ground_count);
    printf("  no_blueprint=%u  verdict_fail=%u\n",
           d.no_blueprint,d.verdict_fail);
    printf("══════════════════════════════════════════════════════\n");
    return 0;
}
