/*
 * geo_completeness_test.c
 * ═══════════════════════
 * พิสูจน์สองอย่างเท่านั้น:
 *   1. COVERAGE  — ทุก input ที่เป็นไปได้มี position ใน geometry
 *   2. COLLISION — สอง input ที่ต่างกัน land ที่ position เดียวกันบ่อยแค่ไหน
 *
 * ไม่วัด speed ไม่มี storage ไม่มี retrieve
 * แค่ตรวจว่า geometry "ครบ" และ "ไม่ซ้ำ" พอ
 *
 * compile: gcc -O2 -o geo_test geo_completeness_test.c && ./geo_test
 */

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* ══════════════════════════════════════════
   SACRED NUMBERS
   ══════════════════════════════════════════ */
#define TRIT_MOD    27u
#define SPOKE_MOD    6u
#define COSET_MOD    9u
#define LETTER_MOD  26u
#define FIBO_MOD   144u
#define SHAPE_SLOTS (TRIT_MOD * SPOKE_MOD * COSET_MOD)  /* 1,458 */

/* full cycle: LCM(27,6,9,26,144) = 5,616
   ทุก 5,616 input pattern ถึงจะวนกลับมาที่ (0,0,0,0,0) ครบรอบ */
#define FULL_CYCLE  5616u

/* ══════════════════════════════════════════
   POSITION — geometric address ของ input
   derive จาก idx ล้วนๆ ไม่มี hash overhead
   ══════════════════════════════════════════ */
typedef struct {
    uint8_t trit;
    uint8_t spoke;
    uint8_t coset;
    uint8_t letter;
    uint8_t fibo;
} GeoPos;

/* mix idx bits เพื่อ decorrelate แต่ละ field */
static inline GeoPos geo_pos(uint64_t idx) {
    /* bit mixing — spread entropy ก่อน mod */
    uint64_t h = idx;
    h ^= h >> 33;
    h *= 0xff51afd7ed558ccdULL;
    h ^= h >> 33;

    GeoPos p;
    p.trit   = (uint8_t)(h         % TRIT_MOD);
    p.spoke  = (uint8_t)((h >> 8)  % SPOKE_MOD);
    p.coset  = (uint8_t)((h >> 17) % COSET_MOD);
    p.letter = (uint8_t)((h >> 26) % LETTER_MOD);
    p.fibo   = (uint8_t)((h >> 35) % FIBO_MOD);
    return p;
}

/* primary slot — 3D position ใน geometry space */
static inline uint32_t pos_slot(const GeoPos *p) {
    return (uint32_t)p->trit  * (SPOKE_MOD * COSET_MOD)
         + (uint32_t)p->spoke * COSET_MOD
         + (uint32_t)p->coset;
}

/* ══════════════════════════════════════════
   TEST 1: COVERAGE
   ทุก slot ใน 1,458-slot geometry space ต้องถูกแตะ
   ภายใน FULL_CYCLE (10,296) input แรก
   ══════════════════════════════════════════ */
static void test_coverage(void) {
    printf("=== TEST 1: COVERAGE ===\n");
    printf("ตรวจว่าทุก slot ใน geometry ถูก map ถึงภายใน %u inputs\n\n",
           FULL_CYCLE);

    /* slot hit map */
    uint8_t slot_hit[SHAPE_SLOTS];
    memset(slot_hit, 0, sizeof(slot_hit));

    uint32_t first_full_at = 0;   /* idx ที่ทุก slot ถูก hit ครบ */

    for (uint32_t idx = 0; idx < FULL_CYCLE; idx++) {
        GeoPos   p = geo_pos((uint64_t)idx);
        uint32_t s = pos_slot(&p);
        slot_hit[s] = 1;
    }

    /* นับ slot ที่ยังไม่ถูก hit */
    uint32_t uncovered = 0;
    for (uint32_t s = 0; s < SHAPE_SLOTS; s++)
        if (!slot_hit[s]) uncovered++;

    /* หา first_full_at */
    memset(slot_hit, 0, sizeof(slot_hit));
    uint32_t covered = 0;
    for (uint32_t idx = 0; idx < FULL_CYCLE * 4 && first_full_at == 0; idx++) {
        GeoPos   p = geo_pos((uint64_t)idx);
        uint32_t s = pos_slot(&p);
        if (!slot_hit[s]) { slot_hit[s] = 1; covered++; }
        if (covered == SHAPE_SLOTS) first_full_at = idx + 1;
    }

    /* trit axis coverage */
    uint8_t trit_hit[TRIT_MOD];   memset(trit_hit, 0, sizeof(trit_hit));
    uint8_t spoke_hit[SPOKE_MOD]; memset(spoke_hit, 0, sizeof(spoke_hit));
    uint8_t coset_hit[COSET_MOD]; memset(coset_hit, 0, sizeof(coset_hit));
    uint8_t letter_hit[LETTER_MOD]; memset(letter_hit, 0, sizeof(letter_hit));
    uint8_t fibo_hit[FIBO_MOD];   memset(fibo_hit, 0, sizeof(fibo_hit));

    for (uint32_t idx = 0; idx < FULL_CYCLE; idx++) {
        GeoPos p = geo_pos((uint64_t)idx);
        trit_hit  [p.trit]   = 1;
        spoke_hit [p.spoke]  = 1;
        coset_hit [p.coset]  = 1;
        letter_hit[p.letter] = 1;
        fibo_hit  [p.fibo]   = 1;
    }

    uint32_t trit_cov=0, spoke_cov=0, coset_cov=0, letter_cov=0, fibo_cov=0;
    for (uint8_t i=0;i<TRIT_MOD;i++)   trit_cov   += trit_hit[i];
    for (uint8_t i=0;i<SPOKE_MOD;i++)  spoke_cov  += spoke_hit[i];
    for (uint8_t i=0;i<COSET_MOD;i++)  coset_cov  += coset_hit[i];
    for (uint8_t i=0;i<LETTER_MOD;i++) letter_cov += letter_hit[i];
    for (uint8_t i=0;i<FIBO_MOD;i++)   fibo_cov   += fibo_hit[i];

    int pass = (uncovered == 0) || (first_full_at > 0 && first_full_at <= FULL_CYCLE * 2);

    printf("slot coverage: %u / %u  (uncovered=%u)  %s\n",
           SHAPE_SLOTS - uncovered, SHAPE_SLOTS, uncovered,
           uncovered == 0 ? "[FULL]" : "[PARTIAL]");
    printf("first full at: input #%u  (%.1f× FULL_CYCLE)\n",
           first_full_at, first_full_at / (double)FULL_CYCLE);
    printf("axis coverage:\n");
    printf("  trit   %2u/%2u  spoke %u/%u  coset %u/%u\n",
           trit_cov, TRIT_MOD, spoke_cov, SPOKE_MOD, coset_cov, COSET_MOD);
    printf("  letter %2u/%2u  fibo %3u/%3u\n",
           letter_cov, LETTER_MOD, fibo_cov, FIBO_MOD);
    printf("result: %s\n\n", pass ? "[PASS]" : "[FAIL]");
}

/* ══════════════════════════════════════════
   TEST 2: COLLISION RATE
   วัดว่ากี่ % ของ input pairs ที่ land บน slot เดิม
   เทียบกับ expected (birthday problem baseline)
   ══════════════════════════════════════════ */
static void test_collision(void) {
    printf("=== TEST 2: COLLISION RATE ===\n");
    printf("วัด collision บน %u inputs ใน %u slots\n\n",
           FULL_CYCLE, SHAPE_SLOTS);

    /* slot count: นับว่าแต่ละ slot ถูก hit กี่ครั้ง */
    uint16_t slot_count[SHAPE_SLOTS];
    memset(slot_count, 0, sizeof(slot_count));

    for (uint32_t idx = 0; idx < FULL_CYCLE; idx++) {
        GeoPos   p = geo_pos((uint64_t)idx);
        uint32_t s = pos_slot(&p);
        if (slot_count[s] < 0xFFFFu) slot_count[s]++;
    }

    /* คำนวณ stats */
    uint32_t collision_slots = 0;   /* slots ที่มี > 1 input */
    uint32_t empty_slots     = 0;   /* slots ที่ไม่มีใครเลย */
    uint32_t max_load        = 0;   /* slot ที่หนาแน่นสุด */
    uint64_t total_collisions= 0;   /* inputs ที่ชนกัน */

    for (uint32_t s = 0; s < SHAPE_SLOTS; s++) {
        uint16_t c = slot_count[s];
        if (c == 0) empty_slots++;
        if (c > 1)  { collision_slots++; total_collisions += c - 1; }
        if (c > max_load) max_load = c;
    }

    double avg_load    = (double)FULL_CYCLE / SHAPE_SLOTS;
    double coll_rate   = 100.0 * total_collisions / FULL_CYCLE;

    /* birthday problem expected: approximate without libm
       P(≥1 collision) ≈ N*(N-1)/(2*M) for N<<M (Poisson approx)
       for N=10296, M=1458: N/M ≈ 7.06 so nearly all slots hit multiple times
       expected collisions ≈ N - M*(1 - (1-1/M)^N) ≈ N - M*(e^(-N/M))
       since N>>M here: expected_coll% ≈ 100% × (1 - M/N) */
    double expected_coll = 100.0 * (1.0 - (double)SHAPE_SLOTS / (double)FULL_CYCLE);

    /* distribution: นับ slots ที่มี 0,1,2,3,4,5+ inputs */
    uint32_t dist[8] = {0};
    for (uint32_t s = 0; s < SHAPE_SLOTS; s++) {
        uint32_t c = slot_count[s];
        dist[c < 7 ? c : 7]++;
    }

    printf("load:  avg=%.1f  max=%u  empty=%u  collision_slots=%u\n",
           avg_load, max_load, empty_slots, collision_slots);
    printf("collision rate: %.1f%%  (birthday expected: %.1f%%)\n",
           coll_rate, expected_coll > 100.0 ? 100.0 : expected_coll);
    printf("distribution (slot → count of inputs landing there):\n");
    printf("  0 inputs: %5u slots  (%.1f%%)\n",
           dist[0], 100.0*dist[0]/SHAPE_SLOTS);
    for (uint32_t i = 1; i <= 6; i++)
        printf("  %u input%s: %5u slots  (%.1f%%)\n",
               i, i>1?"s":" ", dist[i], 100.0*dist[i]/SHAPE_SLOTS);
    printf("  7+inputs: %5u slots  (%.1f%%)\n",
           dist[7], 100.0*dist[7]/SHAPE_SLOTS);

    /* pass condition: actual collision rate ≤ 2× birthday expected
       หมายความว่า geometry ไม่ cluster แย่กว่า random distribution */
    int pass = (coll_rate <= expected_coll * 2.0) || (expected_coll >= 100.0);
    printf("result: %s  (actual %.1f%% vs expected %.1f%% × 2 = %.1f%%)\n\n",
           pass ? "[PASS]" : "[FAIL]",
           coll_rate,
           expected_coll > 100.0 ? 100.0 : expected_coll,
           expected_coll > 100.0 ? 200.0 : expected_coll * 2.0);
}

/* ══════════════════════════════════════════
   TEST 3: DETERMINISM
   input เดิม → position เดิมเสมอ 100%
   ถ้าข้อนี้ fail ทุกอย่างพัง
   ══════════════════════════════════════════ */
static void test_determinism(void) {
    printf("=== TEST 3: DETERMINISM ===\n");
    printf("ตรวจว่า input เดิม → position เดิม 100%%\n\n");

    int pass = 1;
    uint32_t checks = 0;

    /* run same idx สองรอบ ผลต้องเหมือนกันทุกครั้ง */
    for (uint64_t idx = 0; idx < FULL_CYCLE * 3; idx += 7) {
        GeoPos p1 = geo_pos(idx);
        GeoPos p2 = geo_pos(idx);
        if (p1.trit != p2.trit || p1.spoke != p2.spoke ||
            p1.coset != p2.coset || p1.letter != p2.letter ||
            p1.fibo != p2.fibo) {
            printf("[FAIL] idx=%llu p1=(%u,%u,%u) p2=(%u,%u,%u)\n",
                   (unsigned long long)idx,
                   p1.trit, p1.spoke, p1.coset,
                   p2.trit, p2.spoke, p2.coset);
            pass = 0;
            break;
        }
        checks++;
    }

    /* ตรวจ replay: position ที่ได้จาก idx ต้องตรงกับ slot ที่ compute ได้จาก position */
    for (uint64_t idx = 0; idx < 1000; idx++) {
        GeoPos   p  = geo_pos(idx);
        GeoPos   p2 = geo_pos(idx);
        uint32_t s1 = pos_slot(&p);
        uint32_t s2 = pos_slot(&p2);
        if (s1 != s2) {
            printf("[FAIL] slot not deterministic at idx=%llu\n",
                   (unsigned long long)idx);
            pass = 0;
            break;
        }
        checks++;
    }

    printf("checked %u pairs\n", checks);
    printf("result: %s\n\n", pass ? "[PASS]" : "[FAIL]");
}

/* ══════════════════════════════════════════
   TEST 4: SACRED NUMBER ALIGNMENT
   ตรวจว่าตัวเลข sacred ยัง hold ใน geometry
   ══════════════════════════════════════════ */
static void test_sacred(void) {
    printf("=== TEST 4: SACRED NUMBER ALIGNMENT ===\n");
    printf("ตรวจว่า geometry constants สอดคล้องกัน\n\n");

    int pass = 1;

    /* 27,648 = 4^5 × 3^3: LC space */
    uint32_t lc_space = 27648u;
    if (lc_space % TRIT_MOD != 0) {
        printf("[FAIL] 27648 %% 27 != 0\n"); pass = 0;
    }
    if (lc_space / TRIT_MOD != 1024u) {
        printf("[FAIL] 27648 / 27 != 1024\n"); pass = 0;
    }

    /* 3,456 = 2^7 × 3^3: TPOGLS GEO_FULL_N */
    uint32_t geo_full = 3456u;
    if (geo_full % TRIT_MOD != 0) {
        printf("[FAIL] 3456 %% 27 != 0\n"); pass = 0;
    }

    /* 54 icosphere faces = 2 × 27 */
    if (54u != 2u * TRIT_MOD) {
        printf("[FAIL] 54 != 2 × 27\n"); pass = 0;
    }

    /* 144 = 16 × 9 = 16 × COSET_MOD */
    if (FIBO_MOD % COSET_MOD != 0) {
        printf("[FAIL] 144 %% 9 != 0\n"); pass = 0;
    }

    /* SHAPE_SLOTS = 27 × 6 × 9 = 1,458 */
    if (SHAPE_SLOTS != TRIT_MOD * SPOKE_MOD * COSET_MOD) {
        printf("[FAIL] SHAPE_SLOTS wrong\n"); pass = 0;
    }

    /* FULL_CYCLE = LCM(27,26,144) */
    /* verify: FULL_CYCLE % each mod == 0 */
    if (FULL_CYCLE % TRIT_MOD != 0 || FULL_CYCLE % SPOKE_MOD != 0 ||
        FULL_CYCLE % COSET_MOD != 0 || FULL_CYCLE % LETTER_MOD != 0 ||
        FULL_CYCLE % FIBO_MOD != 0) {
        printf("[FAIL] FULL_CYCLE=%u is not LCM of all mods\n", FULL_CYCLE);
        printf("       27:%u 6:%u 9:%u 26:%u 144:%u\n",
               FULL_CYCLE%TRIT_MOD, FULL_CYCLE%SPOKE_MOD,
               FULL_CYCLE%COSET_MOD, FULL_CYCLE%LETTER_MOD,
               FULL_CYCLE%FIBO_MOD);
        pass = 0;
    }

    /* ratio: LC/TPOGLS = 2^3 = 8 */
    if (lc_space / geo_full != 8u) {
        printf("[FAIL] LC/TPOGLS ratio != 8 (got %u)\n", lc_space/geo_full);
        pass = 0;
    }

    /* 720 = 144 × 5 = fibo × pentagon */
    if (720u % FIBO_MOD != 0) {
        printf("[FAIL] 720 %% 144 != 0\n"); pass = 0;
    }

    if (pass) {
        printf("27,648 / 27 = 1,024  (LC = 4^5 × 3^3) ✓\n");
        printf("3,456  / 27 = 128    (TPOGLS = 2^7 × 3^3) ✓\n");
        printf("54     = 2 × 27      (icosphere faces) ✓\n");
        printf("144    = 16 × 9      (fibo × coset) ✓\n");
        printf("1,458  = 27×6×9      (SHAPE_SLOTS) ✓\n");
        printf("10,296 = LCM(all)    (FULL_CYCLE) ✓\n");
        printf("8      = LC/TPOGLS   (resolution ratio) ✓\n");
        printf("720    = 144 × 5     (dodeca rotation) ✓\n");
    }
    printf("\nresult: %s\n\n", pass ? "[PASS]" : "[FAIL]");
}

/* ══════════════════════════════════════════
   MAIN
   ══════════════════════════════════════════ */
int main(void) {
    printf("geo_completeness_test\n");
    printf("SHAPE_SLOTS=%u  FULL_CYCLE=%u\n",
           SHAPE_SLOTS, FULL_CYCLE);
    printf("trit=%u spoke=%u coset=%u letter=%u fibo=%u\n\n",
           TRIT_MOD, SPOKE_MOD, COSET_MOD, LETTER_MOD, FIBO_MOD);

    test_sacred();
    test_determinism();
    test_coverage();
    test_collision();

    printf("=== SUMMARY ===\n");
    printf("ถ้าทุก test PASS: geometry ครบ deterministic และกระจายสม่ำเสมอ\n");
    printf("ระบบ 'มีอยู่' และ 'ครบ' ไม่จำเป็นต้องเร็ว\n");
    return 0;
}
