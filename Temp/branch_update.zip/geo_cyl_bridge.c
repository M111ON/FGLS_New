/*
 * geo_cyl_bridge.c
 * ════════════════
 * Bridges cylinder encoder (cyl144.c) output into geo address space
 * (geo_completeness_test.c) and measures distribution quality.
 *
 * Key insight:
 *   cylinder byte = (spoke:3 | zone:5)
 *   cyl_idx       = spoke*24 + zone  → 0-143
 *   geo_pos(cyl_idx) → (trit, spoke, coset, letter, fibo)
 *
 *   This means: every encoded pixel IS a valid geo address.
 *   No translation needed — cylinder space IS fibo clock space.
 *
 * What we test:
 *   1. Does real image data cover geo address space well?
 *   2. Is distribution better/worse than random idx?
 *   3. Does fold ladder (odd-snap from cyl144v2) improve coverage?
 *
 * compile: gcc -O2 -lm -o geo_cyl_bridge geo_cyl_bridge.c && ./geo_cyl_bridge [image.bmp]
 * (no image needed — generates synthetic delta distribution if no BMP)
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* ══════════════════════════════════════════
   SACRED NUMBERS
   ══════════════════════════════════════════ */
#define TRIT_MOD    27u
#define SPOKE_MOD    6u
#define COSET_MOD    9u
#define LETTER_MOD  26u
#define FIBO_MOD   144u
#define SHAPE_SLOTS (TRIT_MOD * SPOKE_MOD * COSET_MOD)   /* 1,458 */
#define N_ZONES     24u
#define CYL_ADDR   (SPOKE_MOD * N_ZONES)   /* 144 — fibo closure */

/* ══════════════════════════════════════════
   GEO ADDRESS (from geo_completeness_test)
   ══════════════════════════════════════════ */
typedef struct { uint8_t trit,spoke,coset,letter,fibo; } GeoPos;

static inline GeoPos geo_pos(uint64_t idx) {
    uint64_t h = idx;
    h ^= h >> 33;
    h *= 0xff51afd7ed558ccdULL;
    h ^= h >> 33;
    GeoPos p;
    p.trit   = (uint8_t)(h         % TRIT_MOD);
    p.spoke  = (uint8_t)((h >> 8)  % SPOKE_MOD);
    p.coset  = (uint8_t)((h >> 17) % COSET_MOD);
    p.letter = (uint8_t)((h >> 26) % LETTER_MOD);
    p.fibo   = (uint8_t)((h >> 35) % FIBO_MOD);
    return p;
}

static inline uint32_t pos_slot(const GeoPos *p) {
    return (uint32_t)p->trit * (SPOKE_MOD * COSET_MOD)
         + (uint32_t)p->spoke * COSET_MOD
         + (uint32_t)p->coset;
}

/* ══════════════════════════════════════════
   CYLINDER ENCODER (from cyl144.c)
   ══════════════════════════════════════════ */
static inline void delta_to_addr(int8_t d, int ch,
                                  uint8_t *spoke_out, uint8_t *zone_out) {
    *spoke_out = (d >= 0) ? (uint8_t)(ch*2 + 1) : (uint8_t)(ch*2);
    uint8_t mag = (d >= 0) ? (uint8_t)d : (uint8_t)(-d - 1);
    *zone_out   = (uint8_t)((mag * N_ZONES) / 128);
}

/* odd-snap from cyl144v2 — improves PSNR 13→17dB */
static inline void delta_to_addr_oddsnap(int8_t d, int ch,
                                          uint8_t *spoke_out, uint8_t *zone_out) {
    *spoke_out = (d >= 0) ? (uint8_t)(ch*2 + 1) : (uint8_t)(ch*2);
    uint8_t mag = (d >= 0) ? (uint8_t)d : (uint8_t)(-d - 1);
    if (!(mag & 1)) mag++;   /* odd-snap: force odd magnitude */
    *zone_out   = (uint8_t)((mag * N_ZONES) / 128);
}

/* cylinder byte → cyl_idx (0-143) */
static inline uint8_t cyl_byte_to_idx(uint8_t byte) {
    uint8_t spoke = (byte >> 5) & 0x7;
    uint8_t zone  =  byte & 0x1F;
    return (uint8_t)(spoke * N_ZONES + zone);
}

/* ══════════════════════════════════════════
   BMP LOAD (minimal)
   ══════════════════════════════════════════ */
typedef struct { int w, h; uint8_t *px; } Img;

static int bmp_load(const char *path, Img *img) {
    FILE *f = fopen(path, "rb"); if (!f) return 0;
    uint8_t hdr[54]; fread(hdr, 1, 54, f);
    img->w = *(int32_t*)(hdr+18); img->h = *(int32_t*)(hdr+22);
    int row_size = (img->w * 3 + 3) & ~3;
    img->px = malloc((size_t)img->w * img->h * 3);
    fseek(f, *(uint32_t*)(hdr+10), SEEK_SET);
    uint8_t *row = malloc(row_size);
    for (int y=img->h-1;y>=0;y--) {
        fread(row, 1, row_size, f);
        for (int x=0;x<img->w;x++) {
            int d=(y*img->w+x)*3;
            img->px[d+0]=row[x*3+2];
            img->px[d+1]=row[x*3+1];
            img->px[d+2]=row[x*3+0];
        }
    }
    free(row); fclose(f); return 1;
}

/* ══════════════════════════════════════════
   SYNTHETIC DELTA GENERATOR
   Simulates realistic image delta distribution
   (Laplacian-like: most deltas near 0)
   ══════════════════════════════════════════ */
static uint64_t lcg_s = 0xDEADBEEFCAFEBABEULL;
static inline uint64_t lcg(void) {
    lcg_s = lcg_s * 6364136223846793005ULL + 1442695040888963407ULL;
    return lcg_s;
}

static int8_t synth_delta(void) {
    /* Realistic image delta: ~70% near zero (±8), ~25% mid (±32), ~5% large (±64)
       This matches natural image statistics better than sum-of-uniform */
    uint64_t r = lcg();
    int bucket = (int)(r % 100);
    int mag;
    if (bucket < 70) {
        mag = (int)((lcg() % 9));        /* 0-8: small delta */
    } else if (bucket < 95) {
        mag = (int)(8 + (lcg() % 25));   /* 8-32: medium */
    } else {
        mag = (int)(32 + (lcg() % 32));  /* 32-63: large */
    }
    /* even/odd mix: force half even so odd-snap has work to do */
    if (!(mag & 1)) mag &= ~1u;   /* keep even */
    int sign = (lcg() & 1) ? 1 : -1;
    int d = sign * mag;
    if (d > 127) d = 127; if (d < -128) d = -128;
    return (int8_t)d;
}

/* log2 approximation — avoids libm dependency */
static inline double log2_approx(double x) {
    /* bit-trick integer log2 + fractional correction */
    if (x <= 0.0) return -1e30;
    uint64_t bits; memcpy(&bits, &x, 8);
    int exp = (int)((bits >> 52) & 0x7FF) - 1023;
    /* fractional part via (1+f) ≈ 1 + f - f²/2 */
    double f = (double)(bits & 0x000FFFFFFFFFFFFFULL) / (double)(1ULL << 52);
    double frac = f * (1.0 - f * 0.5);
    return (double)exp + frac;
}
typedef struct {
    uint32_t slot_count[SHAPE_SLOTS];   /* how many cyl_idx land per geo slot */
    uint32_t cyl_count[CYL_ADDR];       /* raw cyl_idx frequency */
    uint32_t total;
} Distribution;

static void dist_init(Distribution *d) { memset(d, 0, sizeof(*d)); }

static void dist_add(Distribution *d, uint8_t cyl_idx) {
    if (cyl_idx >= CYL_ADDR) return;
    d->cyl_count[cyl_idx]++;
    GeoPos   p = geo_pos((uint64_t)cyl_idx);
    uint32_t s = pos_slot(&p);
    d->slot_count[s]++;
    d->total++;
}

static void dist_report(const Distribution *d, const char *label) {
    /* coverage */
    uint32_t cyl_covered  = 0, slot_covered = 0;
    uint32_t slot_max     = 0, slot_min     = UINT32_MAX;
    uint32_t cyl_max      = 0;

    for (uint32_t i = 0; i < CYL_ADDR;   i++) {
        if (d->cyl_count[i]  > 0) cyl_covered++;
        if (d->cyl_count[i]  > cyl_max) cyl_max = d->cyl_count[i];
    }
    for (uint32_t i = 0; i < SHAPE_SLOTS; i++) {
        if (d->slot_count[i] > 0) slot_covered++;
        if (d->slot_count[i] > slot_max) slot_max = d->slot_count[i];
        if (d->slot_count[i] < slot_min) slot_min = d->slot_count[i];
    }

    /* entropy of cyl distribution (bits/symbol) */
    double entropy = 0.0;
    for (uint32_t i = 0; i < CYL_ADDR; i++) {
        if (!d->cyl_count[i]) continue;
        double p = (double)d->cyl_count[i] / d->total;
        entropy -= p * log2_approx(p);
    }

    /* chi-square uniformity test on slot distribution
       uniform expected = total / SHAPE_SLOTS */
    double chi2 = 0.0;
    double expected = (double)d->total / SHAPE_SLOTS;
    if (expected > 0) {
        for (uint32_t i = 0; i < SHAPE_SLOTS; i++) {
            double diff = (double)d->slot_count[i] - expected;
            chi2 += diff * diff / expected;
        }
    }
    /* normalized: chi2 / slots — lower = more uniform */
    double chi2_norm = chi2 / SHAPE_SLOTS;

    printf("\n[%s]\n", label);
    printf("  total inputs   : %u\n", d->total);
    printf("  cyl coverage   : %u / %u  (%.1f%%)\n",
           cyl_covered, CYL_ADDR, 100.0*cyl_covered/CYL_ADDR);
    printf("  slot coverage  : %u / %u  (%.1f%%)\n",
           slot_covered, SHAPE_SLOTS, 100.0*slot_covered/SHAPE_SLOTS);
    printf("  entropy        : %.3f bits/sym  (max=%.3f)\n",
           entropy, log2_approx((double)CYL_ADDR));
    printf("  slot load      : avg=%.1f  max=%u  min=%u\n",
           (double)d->total/SHAPE_SLOTS, slot_max,
           slot_covered > 0 ? slot_min : 0);
    printf("  uniformity     : chi2/slot=%.2f  (0=perfect uniform)\n",
           chi2_norm);
}

/* ══════════════════════════════════════════
   MAIN
   ══════════════════════════════════════════ */
int main(int argc, char **argv) {
    printf("geo_cyl_bridge\n");
    printf("cylinder 144-space → geo address space bridge\n");
    printf("SHAPE_SLOTS=%u  CYL_ADDR=%u  SPOKE=%u×ZONE=%u\n\n",
           SHAPE_SLOTS, CYL_ADDR, SPOKE_MOD, N_ZONES);

    /* ── SOURCE: BMP image or synthetic ── */
    Img img = {0};
    int use_bmp = 0;
    if (argc > 1) {
        use_bmp = bmp_load(argv[1], &img);
        if (!use_bmp) printf("(could not load %s — using synthetic)\n", argv[1]);
    }

    int n_pixels = use_bmp
                 ? img.w * img.h
                 : 512 * 512;   /* synthetic: 512×512 */

    printf("source: %s (%d pixels)\n\n",
           use_bmp ? argv[1] : "synthetic 512×512",
           n_pixels);

    /* ── RUN 3 distributions ── */

    /* 1. Random baseline: uniform random cyl_idx 0-143 */
    Distribution d_random;
    dist_init(&d_random);
    for (int i = 0; i < n_pixels * 3; i++)
        dist_add(&d_random, (uint8_t)(lcg() % CYL_ADDR));

    /* 2. Cylinder v1 (no odd-snap) */
    Distribution d_cyl;
    dist_init(&d_cyl);

    /* 3. Cylinder v2 (odd-snap) */
    Distribution d_snap;
    dist_init(&d_snap);

    if (use_bmp) {
        for (int y = 0; y < img.h; y++) {
            for (int x = 1; x < img.w; x++) {
                for (int ch = 0; ch < 3; ch++) {
                    int8_t d = (int8_t)(img.px[(y*img.w+x)*3+ch]
                                      - img.px[(y*img.w+x-1)*3+ch]);
                    uint8_t spoke, zone;
                    /* v1 */
                    delta_to_addr(d, ch, &spoke, &zone);
                    dist_add(&d_cyl,  (uint8_t)(spoke*N_ZONES + zone));
                    /* v2 odd-snap */
                    delta_to_addr_oddsnap(d, ch, &spoke, &zone);
                    dist_add(&d_snap, (uint8_t)(spoke*N_ZONES + zone));
                }
            }
        }
    } else {
        /* synthetic: Laplacian deltas, 3 channels */
        for (int i = 0; i < n_pixels * 3; i++) {
            int ch = i % 3;
            int8_t d = synth_delta();
            uint8_t spoke, zone;
            delta_to_addr(d, ch, &spoke, &zone);
            dist_add(&d_cyl,  (uint8_t)(spoke*N_ZONES + zone));
            delta_to_addr_oddsnap(d, ch, &spoke, &zone);
            dist_add(&d_snap, (uint8_t)(spoke*N_ZONES + zone));
        }
    }

    dist_report(&d_random, "RANDOM BASELINE (uniform cyl_idx)");
    dist_report(&d_cyl,    "CYLINDER v1 (no odd-snap)");
    dist_report(&d_snap,   "CYLINDER v2 (odd-snap, +3dB)");

    /* ── COMPARISON ── */
    printf("\n=== KEY QUESTION ===\n");
    printf("Does real image data distribute well in geo address space?\n\n");

    /* compute slot entropy for each distribution */
    double entropy_slot[3];
    Distribution *dists[3] = {&d_random, &d_cyl, &d_snap};
    const char   *names[3] = {"random", "cyl_v1", "cyl_v2"};

    for (int k = 0; k < 3; k++) {
        double e = 0.0;
        for (uint32_t i = 0; i < SHAPE_SLOTS; i++) {
            if (!dists[k]->slot_count[i]) continue;
            double p = (double)dists[k]->slot_count[i] / dists[k]->total;
            e -= p * (log2_approx(p));
        }
        entropy_slot[k] = e;
    }

    double max_slot_entropy = log2_approx((double)SHAPE_SLOTS);
    printf("Slot space entropy (max=%.2f bits for %u slots):\n",
           max_slot_entropy, SHAPE_SLOTS);
    for (int k = 0; k < 3; k++)
        printf("  %-10s %.3f bits  (%.1f%% of max)\n",
               names[k], entropy_slot[k],
               100.0 * entropy_slot[k] / max_slot_entropy);

    printf("\nConclusion:\n");
    if (entropy_slot[2] >= entropy_slot[1])
        printf("  odd-snap IMPROVES geo distribution (higher slot entropy)\n");
    else
        printf("  odd-snap does not improve geo distribution\n");

    if (entropy_slot[1] >= entropy_slot[0] * 0.85)
        printf("  real image data fills geo space well (>=85%% of random baseline)\n");
    else
        printf("  real image data is sparser than random — geometry has headroom\n");

    printf("\n  cyl_idx IS fibo clock input: spoke*24+zone → geo_pos directly\n");
    printf("  no translation layer needed between cylinder encoder and TPOGLS\n");

    if (use_bmp) free(img.px);
    return 0;
}
