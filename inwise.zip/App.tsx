
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { motion, AnimatePresence, MotionConfig } from 'motion/react';
import { 
  Brain, 
  Settings, 
  Loader2, 
  FileUp, 
  Undo2, 
  Redo2, 
  XCircle, 
  Filter, 
  ChevronRight, 
  X, 
  Wand2, 
  AlertCircle, 
  Search, 
  Code2, 
  Check, 
  Edit3, 
  History, 
  Trash2, 
  FileText, 
  ClipboardList, 
  Volume2, 
  Square, 
  FileOutput, 
  MessageSquare, 
  Send, 
  Mic, 
  Lock, 
  Plus, 
  FileCode, 
  GitBranch, 
  SlidersHorizontal, 
  Zap, 
  ZapOff,
  Key, 
  Eye, 
  EyeOff, 
  Ghost, 
  RotateCcw,
  AlertTriangle,
  Sparkles,
  Thermometer,
  Hash,
  User
} from 'lucide-react';
import { AnalysisState, Message, TabType, AppLanguage, SummaryHistoryItem, AppMode, CodeFile, ContextSource } from './types';
import { geminiService } from './services/gemini';

import { TRANSLATIONS } from './constants/translations';
import { cn } from './lib/utils';
import { io } from 'socket.io-client';

const STORAGE_KEYS = {
  STATE: 'cw_persisted_state',
  MESSAGES: 'cw_persisted_messages'
};

const socket = io();

const App: React.FC = () => {
  const [state, setState] = useState<AnalysisState>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STATE);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { 
          ...parsed, 
          isProcessing: false, 
          error: null,
          temperature: parsed.temperature ?? 0.7,
          maxOutputTokens: parsed.maxOutputTokens ?? 2048,
          customPersona: parsed.customPersona ?? '',
          summaryType: parsed.summaryType ?? 'summary',
          complexity: parsed.complexity ?? 'standard',
          outputLanguage: parsed.outputLanguage ?? 'auto',
          appMode: parsed.appMode ?? AppMode.ANALYSIS,
          codeFiles: (parsed.codeFiles || []).map((f: any) => ({
            ...f,
            lastUpdated: new Date(f.lastUpdated)
          })),
          activeCodeFileId: parsed.activeCodeFileId ?? null,
          editMode: parsed.editMode ?? false,
          summaryUndoStack: parsed.summaryUndoStack ?? [],
          summaryRedoStack: parsed.summaryRedoStack ?? [],
          contextUndoStack: parsed.contextUndoStack ?? [],
          contextRedoStack: parsed.contextRedoStack ?? [],
          chatSummary: parsed.chatSummary ?? null,
          activeTab: parsed.activeTab ?? TabType.SUMMARY,
          sidebarWidth: parsed.sidebarWidth ?? 384,
          topicIntensity: parsed.topicIntensity ?? 50,
          excludeUrls: parsed.excludeUrls ?? false,
          excludeDates: parsed.excludeDates ?? false,
          isThinkingMode: parsed.isThinkingMode ?? false,
          isFastMode: parsed.isFastMode ?? false,
          reducedEffects: parsed.reducedEffects ?? false,
          headerNote: parsed.headerNote ?? null,
          apiKeys: parsed.apiKeys ?? [],
          selectedApiKeyIndex: parsed.selectedApiKeyIndex ?? null,
          activeSummaryId: parsed.activeSummaryId ?? (parsed.summaryHistory?.length > 0 ? parsed.summaryHistory[0].id : null),
          sources: (parsed.sources || []).map((s: any) => ({
            ...s,
            timestamp: new Date(s.timestamp)
          })),
          summaryHistory: (parsed.summaryHistory || []).map((h: any) => ({
            ...h,
            timestamp: new Date(h.timestamp)
          }))
        };
      } catch (e) {
        console.error("Failed to load state from storage", e);
      }
    }
    return {
      rawContext: '',
      summary: '',
      summaryHistory: [],
      sources: [],
      isProcessing: false,
      excludeCode: false,
      focusKeywords: '',
      summaryType: 'summary',
      complexity: 'standard',
      outputLanguage: 'auto',
      error: null,
      language: 'en',
      uploadProgress: 0,
      temperature: 0.7,
      maxOutputTokens: 2048,
      customPersona: '',
      appMode: AppMode.ANALYSIS,
      codeFiles: [],
      activeCodeFileId: null,
      editMode: false,
      summaryUndoStack: [],
      summaryRedoStack: [],
      contextUndoStack: [],
      contextRedoStack: [],
      chatSummary: null,
      activeTab: TabType.SUMMARY,
      sidebarWidth: 384,
      topicIntensity: 50,
      excludeUrls: false,
      excludeDates: false,
      isThinkingMode: false,
      isFastMode: false,
      reducedEffects: false,
      headerNote: null,
      apiKeys: [],
      selectedApiKeyIndex: null,
      activeSummaryId: null
    };
  });

  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed.map((m: any) => ({
          ...m,
          id: m.id || Math.random().toString(36).substring(2, 9),
          timestamp: new Date(m.timestamp)
        }));
      } catch (e) {
        console.error("Failed to load messages from storage", e);
      }
    }
    return [];
  });

  const [inputMessage, setInputMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isChatting, setIsChatting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isHoveringZone, setIsHoveringZone] = useState(false);
  
  const [isSummarizingChat, setIsSummarizingChat] = useState(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<Set<string>>(new Set());
  const [showChatSummaryModal, setShowChatSummaryModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [selectedSummaryIds, setSelectedSummaryIds] = useState<Set<string>>(new Set());
  const [chatError, setChatError] = useState<string | null>(null);
  const [lastUserMessage, setLastUserMessage] = useState<string>('');
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [confirmRequest, setConfirmRequest] = useState<{
    message: string;
    onConfirm: () => void;
    confirmText?: string;
    cancelText?: string;
    isDestructive?: boolean;
  } | null>(null);
  const [showFiltersDropdown, setShowFiltersDropdown] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  const [newFileName, setNewFileName] = useState('');
  const [codeUpdateInput, setCodeUpdateInput] = useState('');
  const [isFormatting, setIsFormatting] = useState(false);
  const [overallCodeSummary, setOverallCodeSummary] = useState('');

  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  const [newApiKey, setNewApiKey] = useState('');
  const [newApiKeyLabel, setNewApiKeyLabel] = useState('');
  const [revealedKeys, setRevealedKeys] = useState<Record<number, boolean>>({});

  const t = TRANSLATIONS[state.language];

  const confirm = (message: string, onConfirm: () => void, isDestructive: boolean = true) => {
    setConfirmRequest({ message, onConfirm, isDestructive });
  };

  const showAlert = (message: string) => {
    setConfirmRequest({ 
      message, 
      onConfirm: () => {}, 
      confirmText: state.language === 'th' ? 'ตกลง' : 'OK',
      cancelText: '',
      isDestructive: false 
    });
  };

  useEffect(() => {
    // Update API key in service when selected key changes
    const key = (state.selectedApiKeyIndex !== null && state.apiKeys[state.selectedApiKeyIndex]) 
      ? state.apiKeys[state.selectedApiKeyIndex].key 
      : (process.env.GEMINI_API_KEY || "");
    
    geminiService.setApiKey(key);
    
    // Re-initialize chat if context exists
    if (state.rawContext && state.summary) {
      geminiService.initChat(state, messages);
    }
  }, [state.selectedApiKeyIndex, state.apiKeys, state.rawContext, state.summary]);

  useEffect(() => {
    const handleWindowResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleWindowResize);
    return () => window.removeEventListener('resize', handleWindowResize);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      const { error, isProcessing, uploadProgress, ...persistableState } = state;
      localStorage.setItem(STORAGE_KEYS.STATE, JSON.stringify(persistableState));
    }, 1000);
    return () => clearTimeout(timer);
  }, [state]);

  useEffect(() => {
    const timer = setTimeout(() => {
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
    }, 1000);
    return () => clearTimeout(timer);
  }, [messages]);

  useEffect(() => {
    if (state.summary && state.rawContext) {
      geminiService.initChat(state, messages);
    }
  }, [state.isThinkingMode, state.isFastMode]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      // Removed showFiltersDropdown logic as it now uses a backdrop
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const lastHistoryPush = useRef<number>(0);
  const HISTORY_DEBOUNCE = 1000; 
  const MAX_HISTORY = 50;

  const scrollToBottom = (behavior: ScrollBehavior = "smooth") => {
    if (chatEndRef.current) {
      // Use a more robust scrolling method
      const container = chatEndRef.current.parentElement;
      if (container) {
        if (behavior === "smooth") {
          chatEndRef.current.scrollIntoView({ behavior, block: "end" });
        } else {
          container.scrollTop = container.scrollHeight;
        }
      }
    }
  };

  useEffect(() => {
    if (state.activeTab === TabType.CHAT && !searchTerm) {
      // Use "auto" for tab switch to prevent jumping, "smooth" for new messages
      const behavior = isChatting || messages.length > 0 ? "smooth" : "auto";
      const timer = setTimeout(() => scrollToBottom(behavior as ScrollBehavior), 50);
      return () => clearTimeout(timer);
    }
  }, [messages, isChatting, state.activeTab, searchTerm]);

  const updateContextWithHistory = useCallback((newText: string, immediate: boolean = false) => {
    if (newText === state.rawContext) return;

    const now = Date.now();
    const isSignificantChange = immediate || Math.abs(newText.length - state.rawContext.length) > 20;
    const isDebounced = now - lastHistoryPush.current > HISTORY_DEBOUNCE;

    if (isSignificantChange || isDebounced) {
      setState(prev => ({ 
        ...prev, 
        rawContext: newText,
        contextUndoStack: [...prev.contextUndoStack, prev.rawContext].slice(-MAX_HISTORY),
        contextRedoStack: []
      }));
      lastHistoryPush.current = now;
    } else {
      setState(prev => ({ ...prev, rawContext: newText }));
    }
  }, [state.rawContext]);

  const handleUndo = useCallback(() => {
    if (state.contextUndoStack.length === 0) return;
    
    setState(prev => {
      const previous = prev.contextUndoStack[prev.contextUndoStack.length - 1];
      const newUndoStack = prev.contextUndoStack.slice(0, -1);
      
      return {
        ...prev,
        rawContext: previous,
        contextUndoStack: newUndoStack,
        contextRedoStack: [prev.rawContext, ...prev.contextRedoStack].slice(0, MAX_HISTORY)
      };
    });
    lastHistoryPush.current = Date.now();
  }, [state.contextUndoStack, state.rawContext]);

  const handleRedo = useCallback(() => {
    if (state.contextRedoStack.length === 0) return;
    
    setState(prev => {
      const next = prev.contextRedoStack[0];
      const newRedoStack = prev.contextRedoStack.slice(1);
      
      return {
        ...prev,
        rawContext: next,
        contextUndoStack: [...prev.contextUndoStack, prev.rawContext].slice(-MAX_HISTORY),
        contextRedoStack: newRedoStack
      };
    });
    lastHistoryPush.current = Date.now();
  }, [state.contextRedoStack, state.rawContext]);

  const updateSummaryWithHistory = useCallback((newText: string) => {
    if (newText === state.summary) return;
    setState(prev => ({ 
      ...prev, 
      summary: newText,
      summaryUndoStack: [...prev.summaryUndoStack, prev.summary],
      summaryRedoStack: []
    }));
  }, [state.summary]);

  const handleSummaryUndo = () => {
    if (state.summaryUndoStack.length === 0) return;
    const previous = state.summaryUndoStack[state.summaryUndoStack.length - 1];
    const newUndoStack = state.summaryUndoStack.slice(0, state.summaryUndoStack.length - 1);
    setState(prev => ({ 
      ...prev, 
      summary: previous,
      summaryUndoStack: newUndoStack,
      summaryRedoStack: [prev.summary, ...prev.summaryRedoStack]
    }));
  };

  const handleSummaryRedo = () => {
    if (state.summaryRedoStack.length === 0) return;
    const next = state.summaryRedoStack[0];
    const newRedoStack = state.summaryRedoStack.slice(1);
    setState(prev => ({ 
      ...prev, 
      summary: next,
      summaryUndoStack: [...prev.summaryUndoStack, prev.summary],
      summaryRedoStack: newRedoStack
    }));
  };

  // Keyboard shortcuts for context undo/redo
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isTextarea = target.tagName === 'TEXTAREA' && target.classList.contains('input-field');
      
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (isTextarea) {
          e.preventDefault();
          if (e.shiftKey) {
            handleRedo();
          } else {
            handleUndo();
          }
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        if (isTextarea) {
          e.preventDefault();
          handleRedo();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  const startResizing = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
  }, []);

  const stopResizing = useCallback(() => {
    setIsResizing(false);
  }, []);

  const resize = useCallback((e: MouseEvent) => {
    if (isResizing) {
      const newWidth = e.clientX;
      if (newWidth > 280 && newWidth < 600) {
        setState(prev => ({ ...prev, sidebarWidth: newWidth }));
      }
    }
  }, [isResizing]);

  useEffect(() => {
    window.addEventListener('mousemove', resize);
    window.addEventListener('mouseup', stopResizing);
    return () => {
      window.removeEventListener('mousemove', resize);
      window.removeEventListener('mouseup', stopResizing);
    };
  }, [resize, stopResizing]);

  const extractTextFromPdf = async (file: File, onProgress: (progress: number) => void): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdfjsLib = (window as any).pdfjsLib;
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    
    // Track loading progress
    loadingTask.onProgress = (progressData: { loaded: number; total: number }) => {
      if (progressData.total > 0) {
        onProgress((progressData.loaded / progressData.total) * 30); // First 30% for loading
      }
    };

    const pdf = await loadingTask.promise;
    let fullText = '';
    const numPages = pdf.numPages;
    
    for (let i = 1; i <= numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n';
      
      // Update progress from 30% to 100%
      onProgress(30 + ((i / numPages) * 70));
    }
    return fullText;
  };

  const handleRemoveSource = (id: string) => {
    setState(prev => {
      const sourceToRemove = prev.sources.find(s => s.id === id);
      if (!sourceToRemove) return prev;
      
      const newSources = prev.sources.filter(s => s.id !== id);
      
      // Attempt to remove the source content from rawContext
      const sourceHeader = `--- Source: ${sourceToRemove.name} ---\n`;
      const fullSourceSection = `${sourceHeader}${sourceToRemove.content}`;
      
      let newRawContext = prev.rawContext;
      
      // Try to remove with various possible separators
      if (newRawContext.includes(`\n\n${fullSourceSection}`)) {
        newRawContext = newRawContext.replace(`\n\n${fullSourceSection}`, '');
      } else if (newRawContext.includes(`${fullSourceSection}\n\n`)) {
        newRawContext = newRawContext.replace(`${fullSourceSection}\n\n`, '');
      } else {
        newRawContext = newRawContext.replace(fullSourceSection, '');
      }

      if (newSources.length === 0 && newRawContext.trim() === '') {
        newRawContext = '';
      }

      return {
        ...prev,
        sources: newSources,
        rawContext: newRawContext
      };
    });
  };

  const handleFile = async (file: File) => {
    setIsUploading(true);
    setState(prev => ({ ...prev, error: null, uploadProgress: 0 }));
    try {
      let text = '';
      if (file.type === 'application/pdf') {
        text = await extractTextFromPdf(file, (progress) => {
          setState(prev => ({ ...prev, uploadProgress: Math.round(progress) }));
        });
      } else if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
        // For large text files, we can use a FileReader and track progress
        text = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onprogress = (event) => {
            if (event.lengthComputable) {
              const progress = Math.round((event.loaded / event.total) * 100);
              setState(prev => ({ ...prev, uploadProgress: progress }));
            }
          };
          reader.onload = (e) => resolve(e.target?.result as string || '');
          reader.onerror = (e) => reject(new Error('Failed to read text file'));
          reader.readAsText(file);
        });
      } else {
        throw new Error(state.language === 'th' ? 'ไม่รองรับประเภทไฟล์นี้ โปรดอัปโหลด .txt หรือ .pdf' : 'Unsupported file type. Please upload a .txt or .pdf file.');
      }
      
      const finalContent = text.trim();
      if (finalContent) {
        const sourceId = Math.random().toString(36).substring(2, 9);
        const newSource: ContextSource = {
          id: sourceId,
          name: file.name,
          type: file.type === 'application/pdf' ? 'pdf' : 'text',
          content: finalContent,
          timestamp: new Date()
        };
        
        setState(prev => {
          const separator = prev.rawContext ? '\n\n' : '';
          const sourceHeader = `--- Source: ${file.name} ---\n`;
          const updatedContext = `${prev.rawContext}${separator}${sourceHeader}${finalContent}`;
          
          return {
            ...prev,
            sources: [...prev.sources, newSource],
            rawContext: updatedContext,
            uploadProgress: 100
          };
        });
      }
      
      setIsSuccess(true);
      // Small delay to show 100% and success
      setTimeout(() => {
        setState(prev => ({ ...prev, uploadProgress: 0 }));
        setIsSuccess(false);
      }, 2000);
    } catch (err: any) {
      setState(prev => ({ ...prev, error: err.message, uploadProgress: 0 }));
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) handleFile(file);
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => {
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const handleSummarize = async () => {
    if (!state.rawContext.trim()) {
      setState(prev => ({ ...prev, error: t.errorGeneral }));
      return;
    }
    
    const currentSummary = state.summary;
    const currentContext = state.rawContext;
    const currentExcludeCode = state.excludeCode;
    const currentFocus = state.focusKeywords;

    setState(prev => ({ ...prev, isProcessing: true, error: null }));
    try {
      const result = await geminiService.summarize(
        state.rawContext,
        state.excludeCode,
        state.focusKeywords,
        state.outputLanguage,
        { 
          temperature: state.temperature, 
          maxOutputTokens: state.maxOutputTokens, 
          customPersona: state.customPersona,
          summaryType: state.summaryType,
          complexity: state.complexity,
          topicIntensity: state.topicIntensity,
          excludeUrls: state.excludeUrls,
          excludeDates: state.excludeDates,
          isThinkingMode: state.isThinkingMode,
          isFastMode: state.isFastMode
        }
      );
      
      const newHistoryItem: SummaryHistoryItem = {
        id: Date.now().toString(),
        timestamp: new Date(),
        summary: result.summary,
        headerNote: result.headerNote,
        rawContext: currentContext,
        excludeCode: currentExcludeCode,
        excludeUrls: state.excludeUrls,
        excludeDates: state.excludeDates,
        topicIntensity: state.topicIntensity,
        focusKeywords: currentFocus
      };

      const newState = { 
        ...state, 
        summary: result.summary, 
        headerNote: result.headerNote,
        isProcessing: false,
        activeSummaryId: newHistoryItem.id,
        summaryHistory: [newHistoryItem, ...state.summaryHistory].slice(0, 20)
      };
      setState(newState);
      
      geminiService.initChat(newState, []);
      setMessages([]); 
    } catch (err: any) {
      setState(prev => ({ ...prev, isProcessing: false, error: err.message }));
    }
  };

  const handleSwitchSummary = (item: SummaryHistoryItem) => {
    const newState = {
      ...state,
      summary: item.summary,
      headerNote: item.headerNote || null,
      activeSummaryId: item.id
    };
    setState(newState);
  };

  const handleRestoreContext = (item: SummaryHistoryItem) => {
    confirm(t.restoreConfirm, () => {
      const newState = {
        ...state,
        summary: item.summary,
        headerNote: item.headerNote || null,
        rawContext: item.rawContext,
        excludeCode: item.excludeCode,
        excludeUrls: item.excludeUrls,
        excludeDates: item.excludeDates,
        topicIntensity: item.topicIntensity,
        focusKeywords: item.focusKeywords,
        activeSummaryId: item.id
      };
      setState(newState);
      setShowHistoryModal(false);
      geminiService.initChat(newState, []);
      setMessages([]);
    });
  };

  const createWavHeader = (dataLength: number, sampleRate: number = 24000) => {
    const buffer = new ArrayBuffer(44);
    const view = new DataView(buffer);

    /* RIFF identifier */
    view.setUint32(0, 0x52494646, false); // "RIFF"
    /* file length */
    view.setUint32(4, 36 + dataLength, true);
    /* RIFF type */
    view.setUint32(8, 0x57415645, false); // "WAVE"

    /* format chunk identifier */
    view.setUint32(12, 0x666d7420, false); // "fmt "
    /* format chunk length */
    view.setUint32(16, 16, true);
    /* sample format (raw) */
    view.setUint16(20, 1, true); // PCM
    /* channel count */
    view.setUint16(22, 1, true); // Mono
    /* sample rate */
    view.setUint32(24, sampleRate, true);
    /* byte rate (sample rate * block align) */
    view.setUint32(28, sampleRate * 2, true);
    /* block align (channel count * bytes per sample) */
    view.setUint16(32, 2, true);
    /* bits per sample */
    view.setUint16(34, 16, true);

    /* data chunk identifier */
    view.setUint32(36, 0x64617461, false); // "data"
    /* data chunk length */
    view.setUint32(40, dataLength, true);

    return buffer;
  };

  const handleSpeak = async (text: string, id: string) => {
    if (currentlySpeakingId === id) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        setCurrentlySpeakingId(null);
      }
      return;
    }

    try {
      setCurrentlySpeakingId(id);
      const base64Audio = await geminiService.generateSpeech(text);
      if (!base64Audio) throw new Error("No audio generated");

      // Convert base64 to Uint8Array
      const binaryString = window.atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Add WAV header
      const header = createWavHeader(len, 24000);
      const wavBlob = new Blob([header, bytes], { type: 'audio/wav' });
      const audioUrl = URL.createObjectURL(wavBlob);
      
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      
      const audio = new Audio(audioUrl);
      audioPlayerRef.current = audio;
      audio.onended = () => {
        setCurrentlySpeakingId(null);
        URL.revokeObjectURL(audioUrl);
      };
      
      // Handle play errors
      audio.play().catch(err => {
        console.error("Playback error:", err);
        setCurrentlySpeakingId(null);
      });
    } catch (error) {
      console.error("TTS error:", error);
      setCurrentlySpeakingId(null);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = (reader.result as string).split(',')[1];
          setIsTranscribing(true);
          try {
            const transcription = await geminiService.transcribeAudio(base64Audio);
            if (transcription) {
              setInputMessage(prev => prev ? `${prev} ${transcription}` : transcription);
            }
          } catch (error) {
            console.error("Transcription error:", error);
          } finally {
            setIsTranscribing(false);
          }
        };
        
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error("Microphone access error:", error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleAddApiKey = () => {
    if (!newApiKey.trim()) return;
    const newKeyObj = { key: newApiKey.trim(), label: newApiKeyLabel.trim() || `Key ${state.apiKeys.length + 1}` };
    setState(prev => ({
      ...prev,
      apiKeys: [...prev.apiKeys, newKeyObj],
      selectedApiKeyIndex: prev.selectedApiKeyIndex === null ? 0 : prev.selectedApiKeyIndex
    }));
    setNewApiKey('');
    setNewApiKeyLabel('');
  };

  const handleRemoveApiKey = (index: number) => {
    setState(prev => {
      const newKeys = prev.apiKeys.filter((_, i) => i !== index);
      let newSelectedIndex = prev.selectedApiKeyIndex;
      if (newSelectedIndex === index) {
        newSelectedIndex = null;
      } else if (newSelectedIndex !== null && newSelectedIndex > index) {
        newSelectedIndex--;
      }
      return { ...prev, apiKeys: newKeys, selectedApiKeyIndex: newSelectedIndex };
    });
  };

  const handleClearAllKeys = () => {
    confirm(t.clearConfirm, () => {
      setState(prev => ({ ...prev, apiKeys: [], selectedApiKeyIndex: null }));
    });
  };

  const toggleKeyReveal = (index: number) => {
    setRevealedKeys(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const handleSummarizeChat = async () => {
    if (messages.length === 0) return;
    setIsSummarizingChat(true);
    try {
      const summary = await geminiService.summarizeChat(messages, state.outputLanguage);
      setState(prev => ({ ...prev, chatSummary: summary }));
      setShowChatSummaryModal(true);
    } catch (err: any) {
      showAlert("Failed to summarize conversation: " + err.message);
    } finally {
      setIsSummarizingChat(false);
    }
  };

  const processChatMessage = async (text: string) => {
    setIsChatting(true);
    setChatError(null);
    try {
      const response = await geminiService.sendMessage(text);
      const aiMsg: Message = { 
        id: Date.now().toString() + "-ai",
        role: 'model', 
        content: response, 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, aiMsg]);
      setChatError(null);
    } catch (err: any) {
      const errorText = (state.language === 'th' ? "เกิดข้อผิดพลาดในการประมวลผล: " : "Oops! Something went wrong while processing your message. ") + err.message;
      setChatError(errorText);
      const errMsg: Message = { 
        id: Date.now().toString() + "-err",
        role: 'model', 
        content: errorText, 
        timestamp: new Date(),
        isError: true 
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsChatting(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || state.isProcessing || isChatting) return;
    const userText = inputMessage;
    setLastUserMessage(userText);
    const userMsg: Message = { 
      id: Date.now().toString() + "-user",
      role: 'user', 
      content: userText, 
      timestamp: new Date() 
    };
    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    await processChatMessage(userText);
  };

  const handleRetry = async (failedId: string) => {
    if (state.isProcessing || isChatting) return;
    
    let userMessageToRetry = "";
    
    setMessages(prev => {
      const failedIdx = prev.findIndex(m => m.id === failedId);
      if (failedIdx === -1) return prev;

      const newMessages = [...prev];
      // Look for the user message before this error
      for (let i = failedIdx - 1; i >= 0; i--) {
        if (newMessages[i].role === 'user') {
          userMessageToRetry = newMessages[i].content;
          break;
        }
      }
      newMessages.splice(failedIdx, 1);
      return newMessages;
    });

    if (userMessageToRetry) {
      setLastUserMessage(userMessageToRetry);
      await processChatMessage(userMessageToRetry);
    }
  };

  const handleDismissError = (id: string) => {
    setMessages(prev => prev.filter(m => m.id !== id));
  };

  const handleClearHistory = () => {
    confirm(t.clearConfirm, () => {
      setMessages([]);
      setSelectedMessageIds(new Set());
      localStorage.removeItem(STORAGE_KEYS.MESSAGES);
      if (state.rawContext) {
        geminiService.initChat(state, []);
      }
    });
  };

  const handleToggleMessageSelection = (id: string) => {
    setSelectedMessageIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAllMessages = () => {
    if (selectedMessageIds.size === messages.length) {
      setSelectedMessageIds(new Set());
    } else {
      setSelectedMessageIds(new Set(messages.map(m => m.id)));
    }
  };

  const handleDeleteMessage = (id: string) => {
    confirm(t.clearConfirm, () => {
      setMessages(prev => prev.filter(m => m.id !== id));
      setSelectedMessageIds(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    });
  };

  const handleDeleteSelectedMessages = () => {
    if (selectedMessageIds.size === 0) return;
    const confirmMsg = state.language === 'th' ? `ต้องการลบ ${selectedMessageIds.size} ข้อความที่เลือกใช่หรือไม่?` : `Delete ${selectedMessageIds.size} selected messages?`;
    confirm(confirmMsg, () => {
      setMessages(prev => prev.filter(m => !selectedMessageIds.has(m.id)));
      setSelectedMessageIds(new Set());
    });
  };

  const handleExportSelectedMessages = () => {
    if (selectedMessageIds.size === 0) return;
    
    const selectedMessages = messages
      .filter(m => selectedMessageIds.has(m.id))
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    
    const exportText = selectedMessages
      .map(m => `[${m.timestamp.toLocaleString()}] ${m.role === 'user' ? 'User' : 'Assistant'}:\n${m.content}\n`)
      .join('\n---\n\n');
    
    const blob = new Blob([exportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `chat-selection-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleClearAllSummaries = () => {
    confirm(t.deleteHistoryConfirm, () => {
      setState(prev => ({
        ...prev,
        summary: '',
        headerNote: null,
        summaryHistory: [],
        activeSummaryId: null
      }));
      setSelectedSummaryIds(new Set());
    });
  };

  const handleToggleSummarySelection = (id: string) => {
    setSelectedSummaryIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAllSummaries = () => {
    if (selectedSummaryIds.size === state.summaryHistory.length) {
      setSelectedSummaryIds(new Set());
    } else {
      setSelectedSummaryIds(new Set(state.summaryHistory.map(h => h.id)));
    }
  };

  const handleDeleteHistoryItem = (id: string, skipConfirm: boolean = false) => {
    const executeDelete = () => {
      setState(prev => {
        const newHistory = prev.summaryHistory.filter(h => h.id !== id);
        let newActiveId = prev.activeSummaryId;
        let newSummary = prev.summary;
        
        if (prev.activeSummaryId === id) {
          if (newHistory.length > 0) {
            newActiveId = newHistory[0].id;
            newSummary = newHistory[0].summary;
          } else {
            newActiveId = null;
            newSummary = '';
          }
        }
        
        return {
          ...prev,
          summaryHistory: newHistory,
          activeSummaryId: newActiveId,
          summary: newSummary
        };
      });
      setSelectedSummaryIds(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    };

    if (skipConfirm) {
      executeDelete();
    } else {
      confirm(t.clearConfirm, executeDelete);
    }
  };

  const handleExport = (ids?: string[]) => {
    const itemsToExport = ids 
      ? state.summaryHistory.filter(h => ids.includes(h.id))
      : state.summaryHistory;

    if (itemsToExport.length === 0) return;
    
    const sortedHistory = [...itemsToExport].sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    
    const exportText = sortedHistory
      .map((item, index) => {
        const dateStr = item.timestamp.toLocaleString();
        const title = `SUMMARY #${index + 1} - ${dateStr}`;
        const separator = "=".repeat(title.length);
        return `${separator}\n${title}\n${separator}\n\n${item.summary}\n`;
      })
      .join('\n\n' + "-".repeat(40) + '\n\n');
    
    const blob = new Blob([exportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `summaries-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDeleteSelectedSummaries = () => {
    if (selectedSummaryIds.size === 0) return;
    
    // Check if everything is selected to show a different message
    const isAll = selectedSummaryIds.size === state.summaryHistory.length;
    const confirmMsg = isAll ? t.deleteHistoryConfirm : (state.language === 'th' ? `ต้องการลบ ${selectedSummaryIds.size} รายการที่เลือกใช่หรือไม่?` : `Delete ${selectedSummaryIds.size} selected items?`);

    confirm(confirmMsg, () => {
      setState(prev => {
        const newHistory = prev.summaryHistory.filter(h => !selectedSummaryIds.has(h.id));
        let newActiveId = prev.activeSummaryId;
        let newSummary = prev.summary;
        
        if (prev.activeSummaryId && selectedSummaryIds.has(prev.activeSummaryId)) {
          if (newHistory.length > 0) {
            newActiveId = newHistory[0].id;
            newSummary = newHistory[0].summary;
          } else {
            newActiveId = null;
            newSummary = '';
          }
        }
        
        return {
          ...prev,
          summaryHistory: newHistory,
          activeSummaryId: newActiveId,
          summary: newSummary
        };
      });
      setSelectedSummaryIds(new Set());
    });
  };

  const handleDeleteActiveSummary = () => {
    if (state.activeSummaryId) {
      handleDeleteHistoryItem(state.activeSummaryId);
    } else if (state.summary) {
      // If there's a summary but no id (current generation not yet in history?)
      // Actually handleAnalyze adds it to history, so activeSummaryId should be set.
      confirm(t.clearConfirm, () => {
        setState(prev => ({ ...prev, summary: '', headerNote: null }));
      });
    }
  };
  const handleAddFile = () => {
    if (!newFileName.trim()) return;
    const newFile: CodeFile = {
      id: Date.now().toString(),
      name: newFileName.trim(),
      content: '',
      summary: '',
      lastUpdated: new Date()
    };
    setState(prev => ({
      ...prev,
      codeFiles: [...prev.codeFiles, newFile],
      activeCodeFileId: newFile.id
    }));
    setNewFileName('');
  };

  const handleCodeUpdate = async () => {
    if (!state.activeCodeFileId || !codeUpdateInput.trim()) return;
    const activeFile = state.codeFiles.find(f => f.id === state.activeCodeFileId);
    if (!activeFile) return;

    setIsFormatting(true);
    try {
      const updatedCode = await geminiService.processCodeUpdate(
        activeFile.content,
        codeUpdateInput,
        state.language
      );
      
      const updatedFiles = state.codeFiles.map(f => 
        f.id === state.activeCodeFileId 
          ? { ...f, content: updatedCode, lastUpdated: new Date() } 
          : f
      );

      setState(prev => ({ ...prev, codeFiles: updatedFiles }));
      setCodeUpdateInput('');
      
      // Auto-summarize codebase after update
      const summary = await geminiService.summarizeCode(updatedFiles, state.outputLanguage);
      setOverallCodeSummary(summary);
    } catch (err: any) {
      showAlert(err.message);
    } finally {
      setIsFormatting(false);
    }
  };

  const handleResetAll = () => {
    const confirmMsg = state.language === 'th' ? "ต้องการล้างข้อมูลทั้งหมดและเริ่มใหม่หรือไม่?" : "Are you sure you want to reset everything and start fresh?";
    confirm(confirmMsg, () => {
      localStorage.clear();
      window.location.reload();
    });
  };

  const filteredMessages = messages.filter(m => 
    m.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderSummaryContent = (content: string) => {
    // Regex to find filenames (e.g., file.ts, style.css, App.tsx)
    const fileRegex = /([a-zA-Z0-9_-]+\.[a-zA-Z0-9]+)/g;
    const parts = content.split(fileRegex);
    
    return parts.map((part, i) => {
      if (fileRegex.test(part)) {
        const existingFile = state.codeFiles.find(f => f.name === part);
        return (
          <motion.span 
            key={i} 
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="group/file relative inline-block"
          >
            <motion.button 
              whileHover={{ scale: 1.05, backgroundColor: '#e0e7ff' }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                if (existingFile) {
                  setState(prev => ({ ...prev, appMode: AppMode.CODE, activeCodeFileId: existingFile.id }));
                } else {
                  setNewFileName(part);
                  setState(prev => ({ ...prev, appMode: AppMode.CODE }));
                }
              }}
              className="text-indigo-600 font-mono font-bold hover:underline bg-indigo-50 px-1 rounded transition-colors"
            >
              {part}
            </motion.button>
            {existingFile && (
              <div className="absolute bottom-full left-0 mb-2 hidden group-hover/file:block w-64 p-3 bg-white border border-gray-200 rounded-lg shadow-xl z-50 text-xs text-gray-600">
                <p className="font-bold mb-1 border-b pb-1">{existingFile.name}</p>
                <p className="line-clamp-3 italic">{existingFile.content || 'No content yet.'}</p>
              </div>
            )}
          </motion.span>
        );
      }
      return (
        <ReactMarkdown key={i} remarkPlugins={[remarkGfm]} components={{ p: 'span' }}>
          {part}
        </ReactMarkdown>
      );
    });
  };

  return (
    <MotionConfig reducedMotion={state.reducedEffects ? "always" : "never"}>
      <div className="min-h-screen flex flex-col md:flex-row bg-gray-50 text-gray-900">
      {/* Sidebar */}
      <aside 
        style={{ width: isMobile ? '100%' : `${state.sidebarWidth}px` }}
        className="bg-white border-r border-gray-200 flex flex-col p-6 shadow-sm overflow-y-auto relative group/sidebar"
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 text-white p-2 rounded-lg shadow-indigo-200 shadow-lg">
              <Brain className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">{t.sidebarTitle}</h1>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="flex bg-gray-100 rounded-lg p-1 shadow-inner">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setState(prev => ({ ...prev, language: 'en' }))} 
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${state.language === 'en' ? 'bg-white shadow-md text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
              >
                EN
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setState(prev => ({ ...prev, language: 'th' }))} 
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${state.language === 'th' ? 'bg-white shadow-md text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
              >
                TH
              </motion.button>
            </div>
            <div className="flex gap-4">
              <motion.button 
                whileHover={{ scale: 1.05, color: '#4f46e5' }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowSettingsModal(true)} 
                className="text-[10px] text-gray-400 font-bold transition-all uppercase tracking-widest flex items-center gap-1.5 group"
              >
                <Settings className="w-3 h-3 group-hover:rotate-90 transition-transform duration-500" />
                {t.settingsTitle}
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05, color: '#ef4444' }}
                whileTap={{ scale: 0.95 }}
                onClick={handleResetAll} 
                className="text-[10px] text-gray-400 font-bold transition-all uppercase tracking-widest flex items-center gap-1.5"
              >
                <RotateCcw className="w-3 h-3" />
                {t.reset}
              </motion.button>
            </div>
          </div>
        </div>

        <div className="space-y-8 mt-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <div className="w-1 h-4 bg-indigo-600 rounded-full" />
                <label className="block text-xs font-black text-gray-900 uppercase tracking-widest">{t.contentSource}</label>
              </div>
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
                <button onClick={handleUndo} disabled={state.contextUndoStack.length === 0} className="text-gray-400 hover:text-indigo-600 disabled:opacity-30 transition-all p-1.5 hover:bg-white rounded-md shadow-sm" title="Undo"><Undo2 className="w-3.5 h-3.5" /></button>
                <button onClick={handleRedo} disabled={state.contextRedoStack.length === 0} className="text-gray-400 hover:text-indigo-600 disabled:opacity-30 transition-all p-1.5 hover:bg-white rounded-md shadow-sm" title="Redo"><Redo2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
            
            <div 
              onDragOver={(e) => {
                e.preventDefault();
                const items = Array.from(e.dataTransfer.items);
                const hasSupportedFile = items.some(item => 
                  item.kind === 'file' && 
                  (item.type === 'text/plain' || item.type === 'application/pdf' || item.type === '')
                );
                if (hasSupportedFile) setIsDragging(true);
              }}
              onDragLeave={onDragLeave}
              onMouseEnter={() => setIsHoveringZone(true)}
              onMouseLeave={() => setIsHoveringZone(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                setIsHoveringZone(false);
                const file = e.dataTransfer.files?.[0];
                if (file && (file.type === 'text/plain' || file.name.endsWith('.txt') || file.type === 'application/pdf')) {
                  handleFile(file);
                } else if (file) {
                  setState(prev => ({ ...prev, error: state.language === 'th' ? 'รองรับเฉพาะไฟล์ .txt และ .pdf เท่านั้น' : 'Only .txt and .pdf files are supported.' }));
                }
              }}
              className={`relative group transition-all duration-500 rounded-2xl overflow-hidden ${isDragging ? 'scale-[1.02] z-10' : ''}`}
            >
              <textarea 
                className={`w-full min-h-[260px] p-5 resize-y shadow-inner transition-all duration-500 border-2 outline-none text-sm leading-relaxed ${
                  isDragging 
                    ? 'border-indigo-600 bg-indigo-50 ring-8 ring-indigo-500/5' 
                    : isHoveringZone 
                      ? 'border-indigo-300 bg-white shadow-md' 
                      : 'border-gray-200 bg-gray-50/30'
                } ${state.editMode ? 'font-mono' : 'font-sans'}`} 
                placeholder={t.placeholder} 
                value={state.rawContext} 
                onChange={(e) => updateContextWithHistory(e.target.value)} 
              />

              {state.sources.length > 0 && (
                <div className="absolute top-4 left-4 right-20 flex flex-wrap gap-2 pointer-events-none">
                  {state.sources.map(source => (
                    <motion.div 
                      key={source.id}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="group/source flex items-center gap-1.5 px-2.5 py-1 bg-white/90 backdrop-blur-sm border border-indigo-100 rounded-lg shadow-sm pointer-events-auto"
                    >
                      <FileText className="w-3 h-3 text-indigo-500" />
                      <span className="text-[9px] font-bold text-gray-700 truncate max-w-[80px]">{source.name}</span>
                      <button 
                        onClick={() => handleRemoveSource(source.id)}
                        className="p-1 px-1.5 hover:bg-red-50 text-gray-400 hover:text-red-500 rounded transition-colors group-hover/source:scale-110"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </motion.div>
                  ))}
                </div>
              )}
              
              <div className="absolute bottom-4 right-4 flex items-center gap-2">
                <AnimatePresence>
                  {state.rawContext && !isUploading && !isSuccess && (
                    <motion.button 
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      onClick={() => {
                        updateContextWithHistory('', true);
                        setState(prev => ({ ...prev, sources: [] }));
                      }} 
                      className={`text-gray-400 hover:text-red-500 transition-all bg-white/90 p-2.5 rounded-xl shadow-sm hover:shadow-md active:scale-90 border border-gray-100 ${state.reducedEffects ? '' : 'backdrop-blur-sm'}`} 
                      title="Clear context"
                    >
                      <Trash2 className="w-4 h-4" />
                    </motion.button>
                  )}
                </AnimatePresence>
                
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-[10px] font-bold transition-all shadow-sm border border-gray-100 ${
                    isUploading 
                      ? 'bg-indigo-50 text-indigo-400' 
                      : isSuccess
                        ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                        : `bg-white/90 text-indigo-600 hover:bg-indigo-50 hover:shadow-md active:scale-95 ${state.reducedEffects ? '' : 'backdrop-blur-sm'}`
                  }`}
                >
                  {isUploading ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : isSuccess ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : (
                    <FileUp className="w-3.5 h-3.5" />
                  )}
                  {isUploading ? `${state.uploadProgress}%` : isSuccess ? t.success : t.upload}
                </button>
              </div>

              <AnimatePresence>
                {isDragging && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className={`absolute inset-0 bg-indigo-600/10 flex flex-col items-center justify-center pointer-events-none border-4 border-dashed border-indigo-600/50 m-1 rounded-xl ${state.reducedEffects ? '' : 'backdrop-blur-[2px]'}`}
                  >
                    <motion.div 
                      animate={{ y: [0, -10, 0] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      className="bg-white p-5 rounded-3xl shadow-2xl text-indigo-600 mb-4"
                    >
                      <FileUp className="w-10 h-10" />
                    </motion.div>
                    <p className="text-sm font-black text-indigo-700 uppercase tracking-widest bg-white px-4 py-2 rounded-full shadow-sm">{t.dropZoneText}</p>
                  </motion.div>
                )}

                {isUploading && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className={`absolute inset-0 bg-white/80 flex flex-col items-center justify-center p-10 ${state.reducedEffects ? '' : 'backdrop-blur-md'}`}
                  >
                    <div className="w-full max-w-[240px] space-y-5">
                      <div className="flex flex-col items-center gap-4">
                        <div className="relative">
                          <Loader2 className="w-12 h-12 text-indigo-600 animate-spin opacity-20" />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-[10px] font-black text-indigo-600">{state.uploadProgress}%</span>
                          </div>
                        </div>
                        <div className="text-center">
                          <p className="text-xs font-black text-indigo-600 uppercase tracking-widest animate-pulse">
                            {state.uploadProgress < 30 ? t.uploading : t.reading}
                          </p>
                          <p className="text-[10px] text-gray-400 font-medium mt-1">
                            {state.uploadProgress < 30 ? 'Receiving file data...' : 'Extracting content...'}
                          </p>
                        </div>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden shadow-inner border border-gray-200">
                        <motion.div 
                          className="bg-indigo-600 h-full shadow-[0_0_10px_rgba(79,70,229,0.5)]" 
                          initial={{ width: 0 }}
                          animate={{ width: `${state.uploadProgress}%` }}
                          transition={{ type: "spring", stiffness: 50 }}
                        ></motion.div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {isSuccess && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 1.1 }}
                    className={`absolute inset-0 bg-emerald-50/90 flex flex-col items-center justify-center ${state.reducedEffects ? '' : 'backdrop-blur-sm'}`}
                  >
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="bg-emerald-500 text-white p-4 rounded-full shadow-lg mb-3"
                    >
                      <Check className="w-8 h-8" />
                    </motion.div>
                    <p className="text-sm font-black text-emerald-700 uppercase tracking-widest">{t.success}</p>
                  </motion.div>
                )}
              </AnimatePresence>
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".txt, .pdf" className="hidden" />
            </div>
          </div>
          <div className="space-y-4">
            <div className="relative">
              <button 
                onClick={() => setShowFiltersDropdown(!showFiltersDropdown)}
                className="w-full flex items-center justify-between p-3.5 bg-white border border-gray-200 rounded-2xl text-sm font-bold text-gray-700 hover:border-indigo-300 hover:shadow-md transition-all group"
              >
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-indigo-600 group-hover:scale-110 transition-transform" />
                  <span>{t.filtersLabel}</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 text-gray-400 transition-transform ${showFiltersDropdown ? 'rotate-90' : ''}`} />
              </button>

              <AnimatePresence>
                {showFiltersDropdown && (
                  <>
                    <div className="fixed inset-0 z-[60]" onClick={() => setShowFiltersDropdown(false)} />
                    <motion.div 
                      initial={state.reducedEffects ? { opacity: 1, y: 5 } : { opacity: 0, scale: 0.95, y: 10 }}
                      animate={{ opacity: 1, scale: 1, y: 5 }}
                      exit={state.reducedEffects ? { opacity: 0 } : { opacity: 0, scale: 0.95, y: 10 }}
                      className="absolute left-0 right-0 z-[70] mt-2 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden flex flex-col"
                    >
                      <div className="p-4 space-y-4 overflow-y-auto max-h-[60vh] custom-scrollbar">
                        <div className="grid grid-cols-1 gap-4">
                          <div className="space-y-2">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">{t.typeLabel}</label>
                            <select 
                              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all cursor-pointer hover:bg-white"
                              value={state.summaryType}
                              onChange={(e) => setState(prev => ({ ...prev, summaryType: e.target.value as any }))}
                            >
                              {(Object.entries(t.types) as [string, string][]).map(([key, label]) => (
                                <option key={key} value={key}>{label}</option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">{t.complexityLabel}</label>
                            <select 
                              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all cursor-pointer hover:bg-white"
                              value={state.complexity}
                              onChange={(e) => setState(prev => ({ ...prev, complexity: e.target.value as any }))}
                            >
                              {(Object.entries(t.complexities) as [string, string][]).map(([key, label]) => (
                                <option key={key} value={key}>{label}</option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">{t.outputLangLabel}</label>
                            <select 
                              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all cursor-pointer hover:bg-white"
                              value={state.outputLanguage}
                              onChange={(e) => setState(prev => ({ ...prev, outputLanguage: e.target.value as any }))}
                            >
                              {(Object.entries(t.outputLangs) as [string, string][]).map(([key, label]) => (
                                <option key={key} value={key}>{label}</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="pt-4 border-t border-gray-100 space-y-3">
                          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1 mb-1">{t.exclusionsLabel}</label>
                          <div className="grid grid-cols-1 gap-2">
                            <label className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-indigo-50 rounded-2xl cursor-pointer transition-all group border border-transparent hover:border-indigo-100">
                              <span className="text-xs font-bold text-gray-600 group-hover:text-indigo-600 transition-colors">{t.excludeCode}</span>
                              <input type="checkbox" className="w-4 h-4 text-indigo-600 rounded-lg focus:ring-indigo-500 border-gray-300" checked={state.excludeCode} onChange={(e) => setState(prev => ({ ...prev, excludeCode: e.target.checked }))} />
                            </label>
                            <label className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-indigo-50 rounded-2xl cursor-pointer transition-all group border border-transparent hover:border-indigo-100">
                              <span className="text-xs font-bold text-gray-600 group-hover:text-indigo-600 transition-colors">{t.excludeUrls}</span>
                              <input type="checkbox" className="w-4 h-4 text-indigo-600 rounded-lg focus:ring-indigo-500 border-gray-300" checked={state.excludeUrls} onChange={(e) => setState(prev => ({ ...prev, excludeUrls: e.target.checked }))} />
                            </label>
                            <label className="flex items-center justify-between p-3.5 bg-gray-50 hover:bg-indigo-50 rounded-2xl cursor-pointer transition-all group border border-transparent hover:border-indigo-100">
                              <span className="text-xs font-bold text-gray-600 group-hover:text-indigo-600 transition-colors">{t.excludeDates}</span>
                              <input type="checkbox" className="w-4 h-4 text-indigo-600 rounded-lg focus:ring-indigo-500 border-gray-300" checked={state.excludeDates} onChange={(e) => setState(prev => ({ ...prev, excludeDates: e.target.checked }))} />
                            </label>
                          </div>
                        </div>

                        <div className="pt-4 border-t border-gray-100 space-y-3">
                          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1 mb-1">{t.aiIntelligence}</label>
                          <div className="grid grid-cols-1 gap-2">
                            <label className={`flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all border-2 ${state.isFastMode ? 'bg-emerald-50 border-emerald-500 shadow-sm' : 'bg-gray-50 border-transparent hover:border-gray-200'}`}>
                              <div className="flex flex-col">
                                <span className={`text-xs font-bold ${state.isFastMode ? 'text-emerald-700' : 'text-gray-700'}`}>{t.fastMode}</span>
                                <span className="text-[9px] text-gray-400 font-medium">{t.fastModeSub}</span>
                              </div>
                              <input 
                                type="checkbox" 
                                className="w-4 h-4 text-emerald-600 rounded-lg focus:ring-emerald-500 border-gray-300" 
                                checked={state.isFastMode} 
                                onChange={(e) => setState(prev => ({ ...prev, isFastMode: e.target.checked, isThinkingMode: e.target.checked ? false : prev.isThinkingMode }))} 
                              />
                            </label>
                            <label className={`flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all border-2 ${state.isThinkingMode ? 'bg-indigo-50 border-indigo-500 shadow-sm' : 'bg-gray-50 border-transparent hover:border-gray-200'}`}>
                              <div className="flex flex-col">
                                <span className={`text-xs font-bold ${state.isThinkingMode ? 'text-indigo-700' : 'text-gray-700'}`}>{t.thinkingMode}</span>
                                <span className="text-[9px] text-gray-400 font-medium">{t.thinkingModeSub}</span>
                              </div>
                              <input 
                                type="checkbox" 
                                className="w-4 h-4 text-indigo-600 rounded-lg focus:ring-indigo-500 border-gray-300" 
                                checked={state.isThinkingMode} 
                                onChange={(e) => setState(prev => ({ ...prev, isThinkingMode: e.target.checked, isFastMode: e.target.checked ? false : prev.isFastMode }))} 
                              />
                            </label>
                          </div>
                        </div>
                      </div>
                      
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            <div className="space-y-2 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium text-gray-700">{t.topicIntensity}</label>
                <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">{state.topicIntensity}%</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="100" 
                step="5"
                className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600" 
                value={state.topicIntensity} 
                onChange={(e) => setState(prev => ({ ...prev, topicIntensity: parseInt(e.target.value) }))} 
              />
              <div className="flex justify-between text-[10px] text-gray-400 font-medium">
                <span>{t.topicIntensityLow}</span>
                <span>{t.topicIntensityHigh}</span>
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">{t.focusLabel}</label>
              <input type="text" className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm" placeholder={t.focusPlaceholder} value={state.focusKeywords} onChange={(e) => setState(prev => ({ ...prev, focusKeywords: e.target.value }))} />
            </div>
          </div>
          <button 
            onClick={handleSummarize} 
            disabled={state.isProcessing || isUploading || !state.rawContext.trim()} 
            className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 shadow-xl shadow-indigo-200 hover:bg-indigo-700 hover:shadow-indigo-300 active:scale-[0.98] transition-all disabled:opacity-50 disabled:shadow-none group relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
            {state.isProcessing ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Sparkles className="w-5 h-5 group-hover:scale-110 transition-transform" />
            )}
            {state.isProcessing ? t.thinking : t.analyzeBtn}
          </button>
          {state.error && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-xs font-bold flex items-center gap-3 shadow-sm"
            >
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{state.error}</span>
            </motion.div>
          )}
        </div>

        {/* Resize Handle */}
        <div 
          onMouseDown={startResizing}
          className="hidden md:block absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-indigo-400 transition-colors z-10"
        />
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <nav className="flex items-center justify-between px-6 pt-6 border-b border-gray-200 bg-white">
          <div className="flex items-center gap-4">
            <div className="flex bg-gray-100 p-1 rounded-xl mr-4">
              <button 
                onClick={() => setState(prev => ({ ...prev, appMode: AppMode.ANALYSIS }))}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${state.appMode === AppMode.ANALYSIS ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <Search className="w-3.5 h-3.5" />
                {t.codeMode.analysisMode}
              </button>
              <button 
                onClick={() => setState(prev => ({ ...prev, appMode: AppMode.CODE }))}
                className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${state.appMode === AppMode.CODE ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <Code2 className="w-3.5 h-3.5" />
                {t.codeMode.title}
              </button>
            </div>
            {state.appMode === AppMode.ANALYSIS && (
              <>
                <button onClick={() => setState(prev => ({ ...prev, activeTab: TabType.SUMMARY }))} className={`px-6 py-3 text-sm font-semibold transition-all border-b-2 ${state.activeTab === TabType.SUMMARY ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>{t.summaryTab}</button>
                <button onClick={() => setState(prev => ({ ...prev, activeTab: TabType.CHAT }))} className={`px-6 py-3 text-sm font-semibold transition-all border-b-2 ${state.activeTab === TabType.CHAT ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>{t.chatTab}</button>
              </>
            )}
          </div>
          
          <div className="flex items-center gap-2 pb-1">
            {state.activeTab === TabType.SUMMARY && state.summary && (
              <div className="flex items-center gap-2 mr-2 pr-2 border-r border-gray-200">
                {state.editMode && (
                  <div className="flex items-center gap-1 mr-2">
                    <button 
                      onClick={handleSummaryUndo} 
                      disabled={state.summaryUndoStack.length === 0} 
                      className="text-gray-400 hover:text-indigo-600 disabled:opacity-30 transition-all p-2 rounded-lg hover:bg-gray-100" 
                      title={t.undo}
                    >
                      <Undo2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={handleSummaryRedo} 
                      disabled={state.summaryRedoStack.length === 0} 
                      className="text-gray-400 hover:text-indigo-600 disabled:opacity-30 transition-all p-2 rounded-lg hover:bg-gray-100" 
                      title={t.redo}
                    >
                      <Redo2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
                <button 
                  onClick={() => setState(prev => ({ ...prev, editMode: !prev.editMode }))} 
                  className={`text-xs font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${state.editMode ? 'bg-indigo-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                  {state.editMode ? <Check className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5" />}
                  {t.editMode}
                </button>
              </div>
            )}
            {state.activeTab === TabType.SUMMARY && state.summaryHistory.length > 0 && (
              <button onClick={() => setShowHistoryModal(true)} className="text-xs bg-gray-50 text-gray-600 hover:bg-gray-100 font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-2 border border-gray-200 shadow-sm hover:shadow-md">
                <History className="w-3.5 h-3.5" />
                {t.historyBtn}
              </button>
            )}
            {state.activeTab === TabType.CHAT && (
              <div className="flex items-center gap-2">
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="relative group"
                >
                  <input 
                    type="text" 
                    placeholder={t.searchPlaceholder}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="text-xs p-2 pl-9 pr-8 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none w-48 transition-all bg-gray-50/50 hover:bg-white"
                  />
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
                  {searchTerm && (
                    <motion.button 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      onClick={() => setSearchTerm('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500 transition-all p-0.5 rounded-md hover:bg-red-50"
                      title={t.clearSearch}
                    >
                      <X className="w-3 h-3" />
                    </motion.button>
                  )}
                </motion.div>
                {messages.length > 0 && (
                  <>
                    <div className="h-4 w-px bg-gray-200 mx-2" />
                    <div className="flex items-center gap-3">
                      <motion.button 
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={handleSelectAllMessages} 
                        className="text-[10px] font-bold text-gray-500 hover:text-indigo-600 uppercase tracking-widest transition-colors flex items-center gap-1.5"
                      >
                        <div className={`w-3.5 h-3.5 rounded border transition-colors flex items-center justify-center ${selectedMessageIds.size === messages.length ? 'bg-indigo-600 border-indigo-600' : 'border-gray-300'}`}>
                          {selectedMessageIds.size === messages.length && <Check className="w-2.5 h-2.5 text-white" />}
                        </div>
                        {selectedMessageIds.size === messages.length ? t.deselectAll : t.selectAll}
                      </motion.button>
                      
                      <AnimatePresence>
                        {selectedMessageIds.size > 0 && (
                          <div className="flex items-center gap-2">
                            <motion.button 
                              initial={{ opacity: 0, x: -10, scale: 0.9 }}
                              animate={{ opacity: 1, x: 0, scale: 1 }}
                              exit={{ opacity: 0, x: -10, scale: 0.9 }}
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={handleExportSelectedMessages} 
                              className="text-[10px] font-bold bg-indigo-600 text-white px-3 py-1.5 rounded-lg hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100 flex items-center gap-1.5"
                            >
                              <FileOutput className="w-3 h-3" />
                              {t.exportSelected} ({selectedMessageIds.size})
                            </motion.button>
                            <motion.button 
                              initial={{ opacity: 0, x: -10, scale: 0.9 }}
                              animate={{ opacity: 1, x: 0, scale: 1 }}
                              exit={{ opacity: 0, x: -10, scale: 0.9 }}
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={handleDeleteSelectedMessages} 
                              className="text-[10px] font-bold bg-red-50 text-red-600 px-3 py-1.5 rounded-lg hover:bg-red-100 transition-all border border-red-100 flex items-center gap-1.5"
                            >
                              <Trash2 className="w-3 h-3" />
                              {t.deleteSelected} ({selectedMessageIds.size})
                            </motion.button>
                          </div>
                        )}
                      </AnimatePresence>
                    </div>

                    <div className="h-4 w-px bg-gray-200 mx-2" />
                    <motion.button 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleSummarizeChat} 
                      disabled={isSummarizingChat} 
                      className="text-xs bg-indigo-50 text-indigo-600 hover:bg-indigo-100 font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-2 border border-indigo-100"
                    >
                      {isSummarizingChat ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                      {t.summarizeChat}
                    </motion.button>
                    <motion.button 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleClearHistory} 
                      className="text-xs text-red-500 hover:text-red-700 font-bold px-4 py-2 rounded-lg hover:bg-red-50 transition-all flex items-center gap-2"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      {t.clearChat}
                    </motion.button>
                  </>
                )}
              </div>
            )}
          </div>
        </nav>

        <div className="flex-1 overflow-hidden relative">
          {state.appMode === AppMode.ANALYSIS ? (
            <div className="h-full overflow-y-auto p-6 md:p-10 custom-scrollbar">
              {state.activeTab === TabType.SUMMARY ? (
                <div className="max-w-4xl mx-auto space-y-6">
                  {!state.summary && !state.isProcessing ? (
                    <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                      <FileText className="w-16 h-16 mb-4 opacity-20" />
                      <p className="text-lg text-center whitespace-pre-wrap">{t.emptySummary}</p>
                    </div>
                  ) : state.isProcessing ? (
                    <div className="space-y-4 animate-pulse">
                      <div className="h-8 bg-gray-200 rounded w-1/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    </div>
                  ) : (
                    <>
                      {state.summaryHistory.length > 1 && (
                        <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar no-scrollbar">
                          {state.summaryHistory.map((item, index) => (
                            <button
                              key={item.id}
                              onClick={() => handleSwitchSummary(item)}
                              className={`flex-shrink-0 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${state.activeSummaryId === item.id ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-white text-gray-500 border-gray-200 hover:border-indigo-300 hover:text-indigo-600'}`}
                            >
                              {state.language === 'th' ? `สรุป #${state.summaryHistory.length - index}` : `Summary #${state.summaryHistory.length - index}`}
                            </button>
                          ))}
                        </div>
                      )}
                      <article className="prose prose-indigo max-w-none bg-white p-8 rounded-2xl shadow-sm border border-gray-100 relative">
                        <div className="flex justify-between items-start mb-6">
                          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                            <ClipboardList className="w-6 h-6 text-indigo-600" />
                            {t.contextSummary}
                          </h2>
                          <div className="flex gap-2">
                            <button 
                              onClick={() => handleSpeak(state.summary, 'main-summary')}
                              className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg transition-colors ${currentlySpeakingId === 'main-summary' ? 'bg-indigo-600 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}`}
                              title={currentlySpeakingId === 'main-summary' ? t.stop : t.speak}
                            >
                              {currentlySpeakingId === 'main-summary' ? <Square className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                              {currentlySpeakingId === 'main-summary' ? t.stop : t.speak}
                            </button>
                            <button 
                              onClick={() => setShowHistoryModal(true)} 
                              className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold rounded-lg transition-colors" 
                              title={t.export}
                            >
                              <FileOutput className="w-4 h-4" />
                              {t.export}
                            </button>
                            <button 
                              onClick={handleDeleteActiveSummary} 
                              className="flex items-center gap-2 px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 text-sm font-semibold rounded-lg transition-colors border border-red-100" 
                              title={t.clearConfirm}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                      {state.headerNote && !state.editMode && (
                        <motion.div 
                          initial={state.reducedEffects ? { opacity: 1 } : { opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="mb-6 p-5 bg-indigo-50/50 border border-indigo-100 rounded-2xl flex flex-col gap-3 relative overflow-hidden group"
                        >
                          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
                            <Sparkles className="w-12 h-12 text-indigo-600" />
                          </div>
                          <div className="flex items-center gap-3 relative z-10">
                            <div className="p-2 bg-indigo-600 text-white rounded-lg shadow-sm">
                              <Brain className="w-4 h-4" />
                            </div>
                            <div className="flex flex-col">
                              <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest leading-none mb-1">{t.aiAnalysisNote}</span>
                              <div className="flex items-center gap-2">
                                <div 
                                  className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-[9px] font-bold rounded uppercase tracking-wider border border-indigo-200 cursor-help relative group/tooltip"
                                  title={state.topicIntensity > 70 ? t.intensityFlavor : undefined}
                                >
                                  {t.intensityBadge}: {state.topicIntensity}/100
                                  {state.topicIntensity > 70 && (
                                    <div className="absolute bottom-full left-0 mb-2 hidden group-hover/tooltip:block w-64 p-3 bg-indigo-900 text-white text-[10px] rounded-lg shadow-xl z-50 normal-case font-medium leading-relaxed">
                                      {t.intensityFlavor}
                                      <div className="absolute top-full left-4 border-8 border-transparent border-t-indigo-900" />
                                    </div>
                                  )}
                                </div>
                                <div className="h-1 w-24 bg-gray-200 rounded-full overflow-hidden">
                                  <motion.div 
                                    initial={{ width: 0 }}
                                    animate={{ width: `${state.topicIntensity}%` }}
                                    className="h-full bg-indigo-600"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                          <p className="text-xs text-indigo-800 font-medium leading-relaxed italic relative z-10 pl-1 border-l-2 border-indigo-200">
                            {state.headerNote}
                          </p>
                        </motion.div>
                      )}

                      {state.editMode ? (
                        <textarea
                          className="w-full min-h-[400px] p-6 border border-indigo-100 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-gray-700 leading-relaxed resize-y bg-indigo-50/30 font-sans"
                          value={state.summary}
                          onChange={(e) => updateSummaryWithHistory(e.target.value)}
                        />
                      ) : (
                        <div className="text-gray-700 leading-relaxed markdown-body">
                          {renderSummaryContent(state.summary)}
                        </div>
                      )}
                    </article>
                  </>
                )}
              </div>
            ) : (
                <div className="max-w-4xl mx-auto h-full flex flex-col">
                  <div className="flex-1 overflow-y-auto space-y-4 pb-4 custom-scrollbar">
                    <AnimatePresence initial={false}>
                      {state.chatSummary && !searchTerm && (
                      <div className="mb-6 bg-indigo-50/50 border border-indigo-100 rounded-2xl p-6 relative group animate-in fade-in slide-in-from-top-4 duration-500">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-widest flex items-center gap-2">
                            <Sparkles className="w-3 h-3" />
                            {t.chatSummaryTitle}
                          </h4>
                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => setShowChatSummaryModal(true)}
                              className="text-[10px] font-bold text-indigo-400 hover:text-indigo-600 uppercase tracking-widest transition-colors"
                            >
                              {t.view}
                            </button>
                            <button 
                              onClick={() => setState(prev => ({ ...prev, chatSummary: null }))}
                              className="text-[10px] font-bold text-gray-400 hover:text-red-500 uppercase tracking-widest transition-colors"
                            >
                              {t.close}
                            </button>
                          </div>
                        </div>
                        <div className="text-sm text-gray-700 leading-relaxed markdown-body line-clamp-3">
                          <ReactMarkdown remarkPlugins={[remarkGfm]}>
                            {state.chatSummary}
                          </ReactMarkdown>
                        </div>
                        {state.chatSummary.length > 200 && (
                          <button 
                            onClick={() => setShowChatSummaryModal(true)}
                            className="mt-2 text-[10px] font-bold text-indigo-600 hover:underline uppercase tracking-widest"
                          >
                            {t.readMore}
                          </button>
                        )}
                      </div>
                    )}

                    {messages.length > 0 && !searchTerm && !state.chatSummary && (
                      <div className="flex justify-center mb-6">
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={handleSummarizeChat} 
                          disabled={isSummarizingChat}
                          className="group flex items-center gap-3 px-6 py-3 bg-white border border-indigo-100 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-200 transition-all animate-in fade-in slide-in-from-top-2 duration-500"
                        >
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${isSummarizingChat ? 'bg-indigo-100' : 'bg-indigo-50 group-hover:bg-indigo-100'}`}>
                            {isSummarizingChat ? (
                              <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                            ) : (
                              <Sparkles className="w-4 h-4 text-indigo-600" />
                            )}
                          </div>
                          <div className="text-left">
                            <p className="text-xs font-bold text-gray-900 uppercase tracking-widest">{t.summarizeChat}</p>
                            <p className="text-[10px] text-gray-400 font-medium">{t.summarizeChatSubtext}</p>
                          </div>
                        </motion.button>
                      </div>
                    )}

                    {searchTerm && filteredMessages.length > 0 && (
                      <div className="flex items-center justify-between mb-4 px-2">
                        <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 px-2 py-1 rounded">
                          {state.language === 'th' ? `พบ ${filteredMessages.length} รายการ` : `Found ${filteredMessages.length} ${filteredMessages.length === 1 ? 'match' : 'matches'}`}
                        </span>
                        <button onClick={() => setSearchTerm('')} className="text-[10px] font-bold text-gray-400 hover:text-gray-600 uppercase tracking-widest">
                          {state.language === 'th' ? 'ล้างการค้นหา' : 'Clear Search'}
                        </button>
                      </div>
                    )}
                    {filteredMessages.length === 0 && (
                      <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                        <MessageSquare className="w-16 h-16 mb-4 opacity-20" />
                        <p className="text-center whitespace-pre-wrap">{searchTerm ? 'No matches found.' : t.chatDefault}</p>
                      </div>
                    )}
                    {filteredMessages.map((msg) => (
                      <motion.div 
                        key={msg.id} 
                        initial={state.reducedEffects ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: 20, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        transition={state.reducedEffects ? { duration: 0 } : { type: "spring", stiffness: 260, damping: 20 }}
                        className={`flex flex-col group/msg ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
                      >
                        <div className={`mb-1 px-2 flex items-center gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                          <button 
                            onClick={() => handleToggleMessageSelection(msg.id)}
                            className={`w-4 h-4 rounded border transition-all flex items-center justify-center ${selectedMessageIds.has(msg.id) ? 'bg-indigo-600 border-indigo-600' : 'border-gray-300 bg-white opacity-0 group-hover/msg:opacity-100'}`}
                          >
                            {selectedMessageIds.has(msg.id) && <Check className="w-2.5 h-2.5 text-white" />}
                          </button>
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{msg.role === 'user' ? (state.language === 'th' ? 'คุณ' : 'You') : (state.language === 'th' ? 'ผู้ช่วย' : 'Assistant')}</span>
                        </div>
                        <div 
                          onClick={() => handleToggleMessageSelection(msg.id)}
                          className={`max-w-[85%] p-4 rounded-2xl shadow-sm relative group cursor-pointer transition-all ${selectedMessageIds.has(msg.id) ? 'ring-2 ring-indigo-500 ring-offset-2' : ''} ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : msg.isError ? 'bg-red-50 text-red-800 border-2 border-red-200 rounded-tl-none' : 'bg-white text-gray-800 border border-gray-100 rounded-tl-none'}`}
                        >
                          <div className="flex items-start gap-2">
                            {msg.isError && <AlertCircle className="w-4 h-4 mt-1 text-red-500" />}
                            <div className="text-sm markdown-body">
                              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                {msg.content}
                              </ReactMarkdown>
                            </div>
                          </div>
                          <div className="flex items-center justify-between mt-2 pt-2 border-t border-black/5">
                            <div className="flex items-center gap-3">
                              <span className={`text-[10px] block opacity-50`}>{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              <motion.button 
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteMessage(msg.id);
                                }}
                                className="text-gray-400 hover:text-red-500 transition-colors"
                              >
                                <Trash2 className="w-3 h-3" />
                              </motion.button>
                              {msg.role === 'model' && !msg.isError && (
                                <motion.button 
                                  whileHover={{ scale: 1.1 }}
                                  whileTap={{ scale: 0.9 }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleSpeak(msg.content, msg.id);
                                  }}
                                  className={`text-[10px] font-bold transition-colors flex items-center gap-1 ${currentlySpeakingId === msg.id ? 'text-indigo-600' : 'text-gray-400 hover:text-indigo-600'}`}
                                  title={currentlySpeakingId === msg.id ? t.stop : t.speak}
                                >
                                  {currentlySpeakingId === msg.id ? <Square className="w-3 h-3 fill-current" /> : <Volume2 className="w-3 h-3" />}
                                  {currentlySpeakingId === msg.id ? t.stop : t.speak}
                                </motion.button>
                              )}
                            </div>
                            {msg.isError && (
                              <div className="flex items-center gap-2">
                                <motion.button 
                                  whileHover={{ scale: 1.05 }}
                                  whileTap={{ scale: 0.95 }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRetry(msg.id);
                                  }} 
                                  className="text-[10px] font-bold bg-red-100 text-red-700 px-2 py-1 rounded-md hover:bg-red-200 transition-all flex items-center gap-1"
                                >
                                  <RotateCcw className="w-2.5 h-2.5" />
                                  {t.retry}
                                </motion.button>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDismissError(msg.id);
                                  }} 
                                  className="text-[10px] font-bold bg-gray-100 text-gray-600 px-2 py-1 rounded-md hover:bg-gray-200 transition-all"
                                >
                                  {t.close}
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                    {isChatting && (
                      <div className="flex flex-col items-start">
                        <div className="mb-1 px-2"><span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{state.language === 'th' ? 'ผู้ช่วย' : 'Assistant'}</span></div>
                        <div className="bg-white text-gray-400 border border-gray-100 rounded-2xl rounded-tl-none p-4 shadow-sm flex items-center gap-3">
                          <div className="flex gap-1">
                            <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                            <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                            <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></span>
                          </div>
                          <span className="text-sm">{t.thinking}</span>
                        </div>
                      </div>
                    )}
                    {!searchTerm && <div ref={chatEndRef} />}
                  </div>

                  <div className="pt-4 mt-auto border-t border-gray-100">
                    {chatError && (
                      <div className="mb-3 p-3 bg-red-50 border border-red-100 rounded-xl flex items-center justify-between animate-in slide-in-from-bottom-2 duration-300">
                        <div className="flex items-center gap-2 text-red-700 text-xs font-medium">
                          <AlertTriangle className="w-4 h-4" />
                          <span className="line-clamp-1">{chatError}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <motion.button 
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={() => processChatMessage(lastUserMessage)}
                            className="text-[10px] font-bold bg-red-600 text-white px-3 py-1 rounded-lg hover:bg-red-700 transition-all shadow-sm flex items-center gap-1"
                          >
                            <RotateCcw className="w-2.5 h-2.5" />
                            {t.retry}
                          </motion.button>
                          <button 
                            onClick={() => setChatError(null)}
                            className="text-red-400 hover:text-red-600 p-1"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                    <form onSubmit={handleSendMessage} className="flex gap-2 relative">
                      <div className="flex-1 relative group/input">
                        <input 
                          type="text" 
                          placeholder={!state.summary ? t.analyzeFirst : isChatting ? t.thinking : isTranscribing ? t.transcribing : t.chatPlaceholder} 
                          className="w-full p-4 pr-24 border border-gray-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none text-sm bg-white shadow-sm disabled:bg-gray-50 transition-all placeholder:text-gray-300" 
                          value={inputMessage} 
                          onChange={(e) => setInputMessage(e.target.value)} 
                          disabled={!state.summary || isChatting || isTranscribing} 
                        />
                        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                          <motion.button 
                            whileHover={{ scale: 1.1, backgroundColor: isRecording ? '#fee2e2' : '#f3f4f6' }}
                            whileTap={{ scale: 0.9 }}
                            type="button"
                            onClick={isRecording ? stopRecording : startRecording}
                            disabled={!state.summary || isChatting || isTranscribing}
                            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all shadow-sm ${isRecording ? 'bg-red-50 text-red-600 animate-pulse border border-red-100' : 'text-gray-400 hover:text-indigo-600 border border-transparent'}`}
                            title={isRecording ? t.stopRecording : t.startRecording}
                          >
                            {isTranscribing ? <Loader2 className="w-5 h-5 animate-spin" /> : isRecording ? <Square className="w-5 h-5 fill-current" /> : <Mic className="w-5 h-5" />}
                          </motion.button>
                          <motion.button 
                            whileHover={{ scale: 1.05, backgroundColor: '#4338ca' }}
                            whileTap={{ scale: 0.95 }}
                            type="submit" 
                            disabled={!state.summary || state.isProcessing || isChatting || !inputMessage.trim() || isTranscribing} 
                            className="w-10 h-10 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                          >
                            {isChatting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                          </motion.button>
                        </div>
                      </div>
                    </form>
                    {!state.summary && <p className="text-center text-[10px] font-medium text-amber-600 mt-2 uppercase tracking-tighter"><i className="fas fa-lock mr-1"></i> {t.chatLock}</p>}
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Code Editor Mode UI */
            <div className="h-full flex flex-col md:flex-row overflow-hidden bg-gray-900">
              {/* File Explorer */}
              <div className="w-full md:w-64 bg-gray-800 border-r border-gray-700 flex flex-col">
                <div className="p-4 border-b border-gray-700">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">{t.codeMode.codeFiles}</h3>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      placeholder={t.codeMode.filePlaceholder}
                      className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-3 py-1.5 text-xs text-gray-300 focus:ring-1 focus:ring-indigo-500 outline-none"
                      value={newFileName}
                      onChange={(e) => setNewFileName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleAddFile()}
                    />
                    <button onClick={handleAddFile} className="bg-indigo-600 hover:bg-indigo-700 text-white p-1.5 rounded-lg transition-colors"><i className="fas fa-plus"></i></button>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
                  {state.codeFiles.length === 0 ? (
                    <p className="text-[10px] text-gray-500 text-center mt-4">{t.codeMode.noFiles}</p>
                  ) : (
                    state.codeFiles.map(file => (
                      <button 
                        key={file.id} 
                        onClick={() => setState(prev => ({ ...prev, activeCodeFileId: file.id }))}
                        className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all flex items-center justify-between group ${state.activeCodeFileId === file.id ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-gray-200'}`}
                      >
                        <span className="flex items-center gap-2 truncate">
                          <i className={`fas ${file.name.endsWith('.ts') || file.name.endsWith('.tsx') ? 'fa-code text-blue-400' : 'fa-file-code text-gray-400'}`}></i>
                          {file.name}
                        </span>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setState(prev => ({ ...prev, codeFiles: prev.codeFiles.filter(f => f.id !== file.id), activeCodeFileId: prev.activeCodeFileId === file.id ? null : prev.activeCodeFileId }));
                          }}
                          className="opacity-0 group-hover:opacity-100 hover:text-red-400 transition-all"
                        >
                          <i className="fas fa-times"></i>
                        </button>
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* Editor Area */}
              <div className="flex-1 flex flex-col overflow-hidden">
                {state.activeCodeFileId ? (
                  <>
                    <div className="flex-1 relative">
                      <textarea 
                        className="w-full h-full p-6 bg-gray-900 text-gray-300 font-mono text-sm leading-relaxed resize-none outline-none custom-scrollbar"
                        value={state.codeFiles.find(f => f.id === state.activeCodeFileId)?.content || ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          setState(prev => ({
                            ...prev,
                            codeFiles: prev.codeFiles.map(f => f.id === state.activeCodeFileId ? { ...f, content: val } : f)
                          }));
                        }}
                        placeholder="// Start coding here..."
                      />
                    </div>
                    <div className="p-4 bg-gray-800 border-t border-gray-700">
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t.codeMode.updateCode}</label>
                          {isFormatting && <span className="text-[10px] text-indigo-400 animate-pulse font-bold">{t.codeMode.formatting}</span>}
                        </div>
                        <div className="flex gap-3">
                          <textarea 
                            className="flex-1 bg-gray-900 border border-gray-700 rounded-xl p-3 text-xs text-gray-300 focus:ring-1 focus:ring-indigo-500 outline-none resize-none h-20"
                            placeholder={t.codeMode.updatePlaceholder}
                            value={codeUpdateInput}
                            onChange={(e) => setCodeUpdateInput(e.target.value)}
                          />
                          <button 
                            onClick={handleCodeUpdate}
                            disabled={isFormatting || !codeUpdateInput.trim()}
                            className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white px-6 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2"
                          >
                            {isFormatting ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-magic"></i>}
                            {t.codeMode.applyUpdate}
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-gray-600 space-y-4">
                    <i className="fas fa-code-branch text-5xl opacity-20"></i>
                    <p className="text-sm font-medium">{t.codeMode.noFiles}</p>
                  </div>
                )}
              </div>

              {/* Code Summary Sidebar */}
              <div className="w-full md:w-80 bg-gray-800 border-l border-gray-700 flex flex-col p-6 overflow-y-auto custom-scrollbar">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">{t.codeMode.codeSummary}</h3>
                <div className="prose prose-invert prose-xs">
                  {overallCodeSummary ? (
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {overallCodeSummary}
                    </ReactMarkdown>
                  ) : (
                    <p className="text-gray-500 italic text-xs">{t.codeMode.overallSummaryPlaceholder}</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettingsModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={state.reducedEffects ? { opacity: 1 } : { opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={state.reducedEffects ? { opacity: 0 } : { opacity: 0 }}
              onClick={() => setShowSettingsModal(false)}
              className={`absolute inset-0 bg-black/60 ${state.reducedEffects ? '' : 'backdrop-blur-sm'}`}
            />
            <motion.div 
              initial={state.reducedEffects ? { opacity: 1, y: 0 } : { opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={state.reducedEffects ? { opacity: 0, y: 0 } : { opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] relative z-10"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Settings className="w-6 h-6 text-indigo-600" />
                  {t.settingsTitle}
                </h3>
                <button 
                  onClick={() => setShowSettingsModal(false)} 
                  className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="p-8 space-y-6 overflow-y-auto max-h-[70vh] custom-scrollbar">
                <div className="grid grid-cols-2 gap-4">
                  <motion.button 
                    whileHover={{ scale: 1.02, translateY: -2 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setState(prev => ({ ...prev, isFastMode: !prev.isFastMode, isThinkingMode: false }))}
                    className={`p-4 rounded-2xl border-2 transition-all text-left flex flex-col gap-1 relative overflow-hidden ${state.isFastMode ? 'border-indigo-600 bg-indigo-50/50 shadow-lg shadow-indigo-100' : 'border-gray-100 bg-white hover:border-indigo-200'}`}
                  >
                    {state.isFastMode && <motion.div layoutId="active-glow" className="absolute inset-0 bg-indigo-500/5 pointer-events-none" />}
                    <div className="flex items-center justify-between relative z-10">
                      <span className={`text-sm font-bold ${state.isFastMode ? 'text-indigo-600' : 'text-gray-700'}`}>{t.fastMode}</span>
                      <Zap className={`w-4 h-4 ${state.isFastMode ? 'text-indigo-600' : 'text-gray-300'}`} />
                    </div>
                    <span className="text-[10px] text-gray-400 leading-tight relative z-10">{t.fastModeSub}</span>
                  </motion.button>

                  <motion.button 
                    whileHover={{ scale: 1.02, translateY: -2 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setState(prev => ({ ...prev, isThinkingMode: !prev.isThinkingMode, isFastMode: false }))}
                    className={`p-4 rounded-2xl border-2 transition-all text-left flex flex-col gap-1 relative overflow-hidden ${state.isThinkingMode ? 'border-indigo-600 bg-indigo-50/50 shadow-lg shadow-indigo-100' : 'border-gray-100 bg-white hover:border-indigo-200'}`}
                  >
                    {state.isThinkingMode && <motion.div layoutId="active-glow" className="absolute inset-0 bg-indigo-500/5 pointer-events-none" />}
                    <div className="flex items-center justify-between relative z-10">
                      <span className={`text-sm font-bold ${state.isThinkingMode ? 'text-indigo-600' : 'text-gray-700'}`}>{t.thinkingMode}</span>
                      <Brain className={`w-4 h-4 ${state.isThinkingMode ? 'text-indigo-600' : 'text-gray-300'}`} />
                    </div>
                    <span className="text-[10px] text-gray-400 leading-tight relative z-10">{t.thinkingModeSub}</span>
                  </motion.button>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <Thermometer className="w-4 h-4 text-indigo-500" />
                      {t.temperature}
                    </label>
                    <motion.span 
                      key={state.temperature}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-xs font-mono bg-indigo-50 text-indigo-600 px-2 py-1 rounded-md border border-indigo-100"
                    >
                      {state.temperature.toFixed(2)}
                    </motion.span>
                  </div>
                  <div className="relative pt-1">
                    <input 
                      type="range" min="0" max="2" step="0.05"
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 hover:accent-indigo-700 transition-all"
                      value={state.temperature}
                      onChange={(e) => setState(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))}
                    />
                    <div className="flex justify-between text-[10px] text-gray-400 uppercase font-bold tracking-tighter mt-1">
                      <span>{t.precise}</span>
                      <span>{t.creative}</span>
                    </div>
                  </div>
                </div>

                <div className={`space-y-3 transition-all duration-300 ${state.isThinkingMode ? 'opacity-40 grayscale pointer-events-none scale-[0.98]' : 'opacity-100'}`}>
                  <div className="flex justify-between items-center">
                    <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <Hash className="w-4 h-4 text-indigo-500" />
                      {t.maxTokens}
                    </label>
                    <input 
                      type="number" min="1" max="8192"
                      className="text-xs font-mono bg-indigo-50 text-indigo-600 px-2 py-1 rounded-md border border-indigo-100 outline-none w-20 text-right focus:ring-2 focus:ring-indigo-500/20 transition-all"
                      value={state.maxOutputTokens}
                      onChange={(e) => setState(prev => ({ ...prev, maxOutputTokens: parseInt(e.target.value) || 2048 }))}
                      disabled={state.isThinkingMode}
                    />
                  </div>
                  <input 
                    type="range" min="256" max="8192" step="256"
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 hover:accent-indigo-700 transition-all"
                    value={state.maxOutputTokens}
                    onChange={(e) => setState(prev => ({ ...prev, maxOutputTokens: parseInt(e.target.value) }))}
                    disabled={state.isThinkingMode}
                  />
                  {state.isThinkingMode && (
                    <motion.p 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-[10px] text-indigo-600 font-bold italic flex items-center gap-1"
                    >
                      <Lock className="w-2.5 h-2.5" />
                      {t.thinkingModeMaxTokensNote}
                    </motion.p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <User className="w-4 h-4 text-indigo-500" />
                    {t.personaLabel}
                  </label>
                  <textarea 
                    className="w-full h-32 p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm resize-none custom-scrollbar"
                    placeholder={t.personaPlaceholder}
                    value={state.customPersona}
                    onChange={(e) => setState(prev => ({ ...prev, customPersona: e.target.value }))}
                  />
                </div>

                <div className="pt-6 border-t border-gray-100 space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-transparent hover:border-indigo-100 transition-all group cursor-pointer" onClick={() => setState(prev => ({ ...prev, reducedEffects: !prev.reducedEffects }))}>
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-xl transition-colors ${state.reducedEffects ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-200 text-gray-500'}`}>
                        <ZapOff className="w-4 h-4" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-gray-700">{t.reducedEffects}</span>
                        <span className="text-[10px] text-gray-400 font-medium">{t.reducedEffectsSub}</span>
                      </div>
                    </div>
                    <div className={`w-10 h-5 rounded-full relative transition-colors duration-300 ${state.reducedEffects ? 'bg-indigo-600' : 'bg-gray-300'}`}>
                      <motion.div 
                        animate={{ x: state.reducedEffects ? 22 : 2 }}
                        className="absolute top-1 left-0 w-3 h-3 bg-white rounded-full shadow-sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-gray-100 space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                      <Key className="w-4 h-4 text-indigo-600" />
                      {t.apiManagement}
                    </h4>
                    {state.apiKeys.length > 0 && (
                      <button 
                        onClick={handleClearAllKeys}
                        className="text-[10px] font-bold text-red-500 hover:text-red-600 transition-colors uppercase tracking-wider"
                      >
                        {t.clearAllKeys}
                      </button>
                    )}
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <div className="flex-1 space-y-1">
                        <input 
                          type="text" 
                          placeholder={t.apiLabelPlaceholder}
                          className="w-full p-2 border border-gray-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                          value={newApiKeyLabel}
                          onChange={(e) => setNewApiKeyLabel(e.target.value)}
                        />
                        <input 
                          type="password" 
                          placeholder={t.apiKeyPlaceholder}
                          className="w-full p-2 border border-gray-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                          value={newApiKey}
                          onChange={(e) => setNewApiKey(e.target.value)}
                        />
                      </div>
                      <motion.button 
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={handleAddApiKey}
                        disabled={!newApiKey.trim()}
                        className="bg-indigo-600 text-white px-4 rounded-lg text-xs font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-md shadow-indigo-100"
                      >
                        <Plus className="w-4 h-4" />
                      </motion.button>
                    </div>

                    <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                      <motion.div 
                        whileHover={{ scale: 1.01 }}
                        className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${state.selectedApiKeyIndex === null ? 'bg-indigo-50 border-indigo-200' : 'bg-white border-gray-100 hover:border-gray-200 cursor-pointer'}`}
                        onClick={() => state.selectedApiKeyIndex !== null && setState(prev => ({ ...prev, selectedApiKeyIndex: null }))}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-bold text-gray-700 truncate">{t.useDefaultKey}</span>
                            {state.selectedApiKeyIndex === null && (
                              <motion.span 
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="text-[8px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-full uppercase font-bold tracking-tighter flex items-center gap-1"
                              >
                                <Check className="w-2 h-2" />
                                Active
                              </motion.span>
                            )}
                          </div>
                          <p className="text-[10px] text-gray-400 italic">{t.defaultKeySub}</p>
                        </div>
                        {state.selectedApiKeyIndex !== null && (
                          <ChevronRight className="w-3 h-3 text-gray-300" />
                        )}
                      </motion.div>

                      <AnimatePresence mode="popLayout">
                        {state.apiKeys.map((keyObj, index) => (
                          <motion.div 
                            key={index} 
                            layout
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20 }}
                            whileHover={{ scale: 1.01 }}
                            className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${state.selectedApiKeyIndex === index ? 'bg-indigo-50 border-indigo-200' : 'bg-white border-gray-100'}`}
                          >
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs font-bold text-gray-700 truncate">{keyObj.label}</span>
                                {state.selectedApiKeyIndex === index && (
                                  <motion.span 
                                    initial={{ scale: 0 }}
                                    animate={{ scale: 1 }}
                                    className="text-[8px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-full uppercase font-bold tracking-tighter flex items-center gap-1"
                                  >
                                    <Check className="w-2 h-2" />
                                    Active
                                  </motion.span>
                                )}
                              </div>
                              <div className="flex items-center gap-2">
                                <code className="text-[10px] text-gray-500 font-mono truncate bg-gray-50 px-1.5 py-0.5 rounded">
                                  {revealedKeys[index] ? keyObj.key : `${keyObj.key.substring(0, 6)}...${keyObj.key.substring(keyObj.key.length - 4)}`}
                                </code>
                                <motion.button 
                                  whileHover={{ scale: 1.2 }}
                                  whileTap={{ scale: 0.8 }}
                                  onClick={() => toggleKeyReveal(index)}
                                  className="text-gray-400 hover:text-indigo-600 transition-colors"
                                  title={revealedKeys[index] ? t.hideKey : t.revealKey}
                                >
                                  {revealedKeys[index] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                                </motion.button>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {state.selectedApiKeyIndex !== index && (
                                <motion.button 
                                  whileHover={{ scale: 1.05 }}
                                  whileTap={{ scale: 0.95 }}
                                  onClick={() => setState(prev => ({ ...prev, selectedApiKeyIndex: index }))}
                                  className="text-[10px] font-bold text-indigo-600 hover:underline uppercase tracking-tighter"
                                >
                                  {t.selectKey}
                                </motion.button>
                              )}
                              <motion.button 
                                whileHover={{ scale: 1.2, color: '#ef4444' }}
                                whileTap={{ scale: 0.8 }}
                                onClick={() => handleRemoveApiKey(index)}
                                className="text-gray-400 transition-colors p-1"
                                title={t.removeKey}
                              >
                                <Trash2 className="w-4 h-4" />
                              </motion.button>
                            </div>
                          </motion.div>
                        ))}
                      </AnimatePresence>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-6 bg-gray-50 flex justify-end">
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setShowSettingsModal(false);
                    if (state.summary) geminiService.initChat(state, messages);
                  }}
                  className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 active:scale-95 transition-all flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  {t.saveSettings}
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* History Modal */}
      <AnimatePresence>
        {showHistoryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={state.reducedEffects ? { opacity: 1 } : { opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={state.reducedEffects ? { opacity: 0 } : { opacity: 0 }}
              onClick={() => setShowHistoryModal(false)}
              className={`absolute inset-0 bg-black/50 ${state.reducedEffects ? '' : 'backdrop-blur-sm'}`}
            />
            <motion.div 
              initial={state.reducedEffects ? { opacity: 1, y: 0 } : { opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={state.reducedEffects ? { opacity: 0, y: 0 } : { opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] relative z-10"
            >
              <div className="flex items-center justify-between p-6 border-b border-gray-100">
                <div className="flex items-center gap-4">
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <History className="w-6 h-6 text-indigo-600" />
                    {t.historyTitle}
                  </h3>
                  {state.summaryHistory.length > 0 && (
                    <div className="flex items-center gap-2 bg-gray-100 px-3 py-1.5 rounded-xl border border-gray-200">
                      <input 
                        type="checkbox" 
                        checked={selectedSummaryIds.size === state.summaryHistory.length && state.summaryHistory.length > 0} 
                        onChange={handleSelectAllSummaries}
                        className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-gray-300 cursor-pointer"
                      />
                      <span className="text-xs font-bold text-gray-500">{t.selectAll}</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  <AnimatePresence>
                    {state.summaryHistory.length > 0 && selectedSummaryIds.size === 0 && (
                      <motion.button
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={handleClearAllSummaries}
                        className="text-xs text-red-500 hover:text-red-700 font-bold px-3 py-1.5 rounded-lg hover:bg-red-50 transition-all flex items-center gap-2 border border-red-100"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        {t.clearAllSummaries}
                      </motion.button>
                    )}
                  </AnimatePresence>
                  <AnimatePresence>
                    {selectedSummaryIds.size > 0 && (
                      <div className="flex items-center gap-2">
                        <motion.button
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          onClick={() => handleExport(Array.from(selectedSummaryIds))}
                          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all hover:scale-105 active:scale-95"
                        >
                          <FileOutput className="w-4 h-4" />
                          {t.exportSelected} ({selectedSummaryIds.size})
                        </motion.button>
                        <motion.button
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          onClick={handleDeleteSelectedSummaries}
                          className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 text-sm font-bold rounded-xl border border-red-100 hover:bg-red-100 transition-all shadow-sm"
                        >
                          <Trash2 className="w-4 h-4" />
                          {t.deleteSelected} ({selectedSummaryIds.size})
                        </motion.button>
                      </div>
                    )}
                  </AnimatePresence>
                  <button 
                    onClick={() => setShowHistoryModal(false)} 
                    className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>
              <div className="p-6 overflow-y-auto custom-scrollbar bg-gray-50 space-y-4">
                {state.summaryHistory.length === 0 ? (
                  <div className="text-center py-20 text-gray-400">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <History className="w-8 h-8 opacity-20" />
                    </div>
                    <p>{t.historyEmpty}</p>
                  </div>
                ) : (
                  state.summaryHistory.map((item) => (
                    <motion.div 
                      key={item.id} 
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      whileHover={{ scale: 1.005, translateY: -1 }}
                      onClick={() => handleToggleSummarySelection(item.id)}
                      className={`relative cursor-pointer bg-white p-5 rounded-2xl border transition-all group overflow-hidden ${selectedSummaryIds.has(item.id) ? 'border-indigo-600 ring-2 ring-indigo-500/10' : 'border-gray-200 shadow-sm hover:border-indigo-300'}`}
                    >
                      {selectedSummaryIds.has(item.id) && (
                        <div className="absolute top-0 right-0 w-12 h-12 overflow-hidden pointer-events-none">
                          <div className="absolute top-0 right-0 bg-indigo-600 text-white p-1 rounded-bl-xl shadow-sm">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        </div>
                      )}
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex items-start gap-3">
                          <input 
                            type="checkbox" 
                            checked={selectedSummaryIds.has(item.id)} 
                            onChange={(e) => {
                              e.stopPropagation();
                              handleToggleSummarySelection(item.id);
                            }}
                            onClick={(e) => e.stopPropagation()}
                            className="mt-1 w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-gray-300 cursor-pointer"
                          />
                          <div>
                            <p className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-1">
                              {t.generatedOn}: {item.timestamp.toLocaleString()}
                            </p>
                            {item.focusKeywords && (
                              <p className="text-[10px] text-gray-500 italic">
                                {t.focusLabel}: {item.focusKeywords}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2">
                           <motion.button 
                             whileHover={{ scale: 1.05 }}
                             whileTap={{ scale: 0.95 }}
                             onClick={(e) => {
                               e.stopPropagation();
                               handleSwitchSummary(item);
                               setShowHistoryModal(false);
                             }}
                             className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${state.activeSummaryId === item.id ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                           >
                             <Eye className="w-3 h-3" />
                             {t.view}
                           </motion.button>
                           <motion.button 
                             whileHover={{ scale: 1.05 }}
                             whileTap={{ scale: 0.95 }}
                             onClick={(e) => {
                               e.stopPropagation();
                               handleDeleteHistoryItem(item.id);
                             }}
                             className="p-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
                             title={t.clearConfirm}
                           >
                             <Trash2 className="w-3.5 h-3.5" />
                           </motion.button>
                           <motion.button 
                             whileHover={{ scale: 1.05 }}
                             whileTap={{ scale: 0.95 }}
                             onClick={(e) => {
                               e.stopPropagation();
                               handleRestoreContext(item);
                             }}
                             className="px-4 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 transition-all flex items-center gap-1 shadow-sm shadow-indigo-100"
                           >
                             <Undo2 className="w-3 h-3" />
                             {t.restore}
                           </motion.button>
                         </div>
                      </div>
                      <div className="text-sm text-gray-700 line-clamp-2 bg-gray-50 p-3 rounded-xl border border-gray-100 italic group-hover:bg-indigo-50/30 transition-colors">
                        {item.headerNote && (
                          <div className="mb-2 pb-2 border-b border-gray-200 not-italic font-bold text-indigo-600 text-[10px] uppercase tracking-widest flex items-center gap-1">
                            <Brain className="w-3 h-3" />
                            {t.aiAnalysisNote}
                          </div>
                        )}
                        {item.summary}
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
              <div className="p-4 border-t border-gray-100 bg-white flex justify-end">
                <button 
                  onClick={() => setShowHistoryModal(false)} 
                  className="px-6 py-2 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition-all"
                >
                  {t.close}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Chat Summary Modal */}
      <AnimatePresence>
        {showChatSummaryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={state.reducedEffects ? { opacity: 1 } : { opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={state.reducedEffects ? { opacity: 0 } : { opacity: 0 }}
              onClick={() => setShowChatSummaryModal(false)}
              className={`absolute inset-0 bg-black/50 ${state.reducedEffects ? '' : 'backdrop-blur-sm'}`}
            />
            <motion.div 
              initial={state.reducedEffects ? { opacity: 1, y: 0 } : { opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={state.reducedEffects ? { opacity: 0, y: 0 } : { opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] relative z-10"
            >
              <div className="flex items-center justify-between p-6 border-b border-gray-100">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-indigo-600" />
                  {t.chatSummaryTitle}
                </h3>
                <button 
                  onClick={() => setShowChatSummaryModal(false)} 
                  className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="p-8 overflow-y-auto custom-scrollbar">
                <div className="prose prose-indigo max-w-none text-gray-700 leading-relaxed markdown-body">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {state.chatSummary || ''}
                  </ReactMarkdown>
                </div>
              </div>
              <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end">
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowChatSummaryModal(false)} 
                  className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  {t.close}
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {confirmRequest && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setConfirmRequest(null)}
              className="absolute inset-0 bg-indigo-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white rounded-2xl shadow-2xl border border-indigo-100 max-w-sm w-full overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className={cn(
                    "p-3 rounded-xl",
                    confirmRequest.isDestructive ? "bg-red-50 text-red-600" : "bg-indigo-50 text-indigo-600"
                  )}>
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900">
                    {state.language === 'th' ? 'ยืนยันการดำเนินการ' : 'Confirmation'}
                  </h3>
                </div>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {confirmRequest.message}
                </p>
              </div>
              <div className="flex border-t border-indigo-50">
                {confirmRequest.cancelText !== "" && (
                  <button 
                    onClick={() => setConfirmRequest(null)}
                    className="flex-1 px-4 py-3.5 text-sm font-bold text-gray-400 hover:text-gray-600 hover:bg-gray-50/50 transition-colors"
                  >
                    {confirmRequest.cancelText || (state.language === 'th' ? 'ยกเลิก' : 'Cancel')}
                  </button>
                )}
                <button 
                  onClick={() => {
                    confirmRequest.onConfirm();
                    setConfirmRequest(null);
                  }}
                  className={cn(
                    "flex-1 px-4 py-3.5 text-sm font-bold transition-all",
                    confirmRequest.isDestructive 
                      ? "text-red-600 hover:bg-red-50" 
                      : (confirmRequest.cancelText === "" ? "text-indigo-600 hover:bg-indigo-50/50" : "text-indigo-600 hover:bg-indigo-50")
                  )}
                >
                  {confirmRequest.confirmText || (state.language === 'th' ? 'ยืนยัน' : 'Confirm')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
    </MotionConfig>
  );
};

export default App;
