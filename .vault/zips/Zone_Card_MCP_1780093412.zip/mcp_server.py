"""
mcp_server.py — ZoneCard MCP Server (FastAPI + SSE)
====================================================
Exposes RouteRuleCache + FusionTable as MCP tools.
Cross-session persistent via JSON files.
Compatible with any MCP client (Claude, OpenAI, custom).

Endpoints:
  GET  /sse                    — SSE stream (MCP handshake)
  POST /tools/get_zone_card    — fetch ZoneCard by zone/shape/model
  POST /tools/resolve_route    — card → route decision
  POST /tools/get_fusion_peer  — find best peer model
  POST /tools/store_decision   — cache LLM decision
  GET  /tools/cache_stats      — hit/miss stats
  POST /admin/reset            — clear state (test use)

Persistence:
  ./mcp_state/exact_cache.json   — hash → decision
  ./mcp_state/fusion_table.json  — zone/shape → entries
  ./mcp_state/zone_cards.json    — card metadata store
"""

from __future__ import annotations

import asyncio
import json
import os
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel

# ── State dir ──
STATE_DIR = Path(os.environ.get("MCP_STATE_DIR", "./mcp_state"))
STATE_DIR.mkdir(exist_ok=True)

EXACT_CACHE_FILE  = STATE_DIR / "exact_cache.json"
FUSION_TABLE_FILE = STATE_DIR / "fusion_table.json"
ZONE_CARDS_FILE   = STATE_DIR / "zone_cards.json"

# ── In-memory state (loaded from disk on startup) ──
_lock = threading.RLock()

exact_cache: Dict[str, dict] = {}    # str(hash) → decision dict
fusion_table: Dict[str, dict] = {}   # "zone:shape" → {model_key → entry}
zone_cards: Dict[str, dict] = {}     # "zone:shape:model" → card dict

_hits = 0
_misses = 0


# ── Persistence helpers ──

def _load_state():
    global exact_cache, fusion_table, zone_cards
    for path, target, name in [
        (EXACT_CACHE_FILE,  "exact_cache",  "exact_cache"),
        (FUSION_TABLE_FILE, "fusion_table", "fusion_table"),
        (ZONE_CARDS_FILE,   "zone_cards",   "zone_cards"),
    ]:
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                globals()[name].update(data)
                print(f"[MCP] loaded {name}: {len(data)} entries")
            except Exception as e:
                print(f"[MCP] warn: could not load {path}: {e}")


def _save_state():
    with _lock:
        for path, name in [
            (EXACT_CACHE_FILE,  "exact_cache"),
            (FUSION_TABLE_FILE, "fusion_table"),
            (ZONE_CARDS_FILE,   "zone_cards"),
        ]:
            try:
                with open(path, "w") as f:
                    json.dump(globals()[name], f, indent=2)
            except Exception as e:
                print(f"[MCP] warn: could not save {path}: {e}")


# ── Route resolution (mirrors RouteRuleCache logic, stateless) ──

CARD_SPARSE = 0
CARD_BATCH  = 1
CARD_LZ     = 2

# Minimal rule table — same priority order as route_cache.py
RULES = [
    # entropy cliff
    dict(priority=85, card_type=-1, ent_min=220, st_max=30,
         decision="crash-plan", action="full_decode"),
    # sparse
    dict(priority=83, card_type=0, ent_max=30, st_min=200,
         decision="skip", action="noop"),
    dict(priority=82, card_type=0, ent_max=30, st_min=100,
         decision="sparse-skip", action="noop"),
    dict(priority=81, card_type=0, ent_max=30,
         decision="sparse-verify", action="sparse_verify"),
    dict(priority=80, card_type=0, ent_min=31, ent_max=127, st_min=200,
         decision="sparse-route", action="sparse_decode"),
    dict(priority=79, card_type=0, ent_min=31, ent_max=127,
         decision="sparse-verify", action="verify_decode"),
    dict(priority=78, card_type=0, ent_min=128,
         decision="sparse-full", action="sparse_decode"),
    dict(priority=77, card_type=0, loc_max=50,
         decision="sparse-fresh", action="fresh_route"),
    # batch
    dict(priority=76, card_type=1, ent_max=30, st_min=200,
         decision="batch-skip", action="noop"),
    dict(priority=75, card_type=1, ent_max=127, st_min=150,
         decision="batch-route", action="batch_read"),
    dict(priority=74, card_type=1, ent_max=127,
         decision="batch-verify", action="batch_verify"),
    dict(priority=73, card_type=1, ent_min=128, st_min=200,
         decision="batch-full", action="batch_read"),
    dict(priority=72, card_type=1, ent_min=128,
         decision="batch-verify-fresh", action="batch_verify_fresh"),
    dict(priority=71, card_type=1, loc_max=50,
         decision="batch-remote", action="remote_batch"),
    # lz
    dict(priority=70, card_type=2, ent_max=30, st_min=200,
         decision="lz-skip", action="noop"),
    dict(priority=69, card_type=2, ent_max=127, st_min=150,
         decision="lz-route", action="lz_decompress"),
    dict(priority=68, card_type=2, ent_min=200, st_max=100,
         decision="full", action="full_decode"),
    dict(priority=65, card_type=2, ent_max=199, st_min=200,
         decision="lz-route", action="lz_decompress"),
    dict(priority=64, card_type=2, ent_max=199,
         decision="lz-verify", action="lz_verify"),
    # locality cascade
    dict(priority=87, card_type=-1, loc_min=220,
         decision="cascade-reuse", action="reuse_state"),
    dict(priority=86, card_type=-1, loc_min=180, st_min=200,
         decision="cascade-merge", action="merge_state"),
    # catch-all
    dict(priority=1, card_type=-1,
         decision="fallback", action="full_read"),
]
RULES.sort(key=lambda r: -r["priority"])


def _resolve_single(card_type: int, entropy: int,
                    locality: int, stability: int,
                    hash_val: int = 0) -> dict:
    global _hits, _misses

    # Exact cache first
    hk = str(hash_val)
    if hash_val and hk in exact_cache:
        _hits += 1
        return {**exact_cache[hk], "cache": "exact"}

    for r in RULES:
        ct = r.get("card_type", -1)
        if ct >= 0 and card_type != ct:
            continue
        if not (r.get("ent_min", 0) <= entropy <= r.get("ent_max", 255)):
            continue
        if not (r.get("loc_min", 0) <= locality <= r.get("loc_max", 255)):
            continue
        if not (r.get("st_min", 0) <= stability <= r.get("st_max", 255)):
            continue
        _hits += 1
        return {
            "decision": r["decision"],
            "action": r["action"],
            "cache": "rule",
            "priority": r["priority"],
        }

    _misses += 1
    return {
        "decision": "planner",
        "action": "call_llm",
        "cache": "miss",
        "reason": f"no rule ct={card_type} ent={entropy} loc={locality} st={stability}",
    }


def _card_similarity(a: dict, b: dict) -> float:
    score = 0.0
    if a.get("card_type") == b.get("card_type"):
        score += 0.35
    ent_diff = abs(a.get("entropy", 128) - b.get("entropy", 128))
    if ent_diff <= 10:
        score += 0.20
    elif ent_diff <= 50:
        score += 0.20 * (1 - (ent_diff - 10) / 40)
    pa, pb = a.get("pattern", 0), b.get("pattern", 0)
    if pa == 0 and pb == 0:
        score += 0.20
    else:
        inter = bin(pa & pb).count("1")
        union = bin(pa | pb).count("1")
        score += 0.20 * inter / max(union, 1)
    loc_diff = abs(a.get("locality", 128) - b.get("locality", 128))
    if loc_diff <= 20:
        score += 0.15
    elif loc_diff <= 100:
        score += 0.15 * (1 - (loc_diff - 20) / 80)
    st_diff = abs(a.get("stability", 128) - b.get("stability", 128))
    if st_diff <= 20:
        score += 0.10
    elif st_diff <= 100:
        score += 0.10 * (1 - (st_diff - 20) / 80)
    return min(score, 1.0)


# ── FastAPI app ──

app = FastAPI(title="ZoneCard MCP Server", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    _load_state()


@app.on_event("shutdown")
async def shutdown():
    _save_state()


# ── MCP manifest ──

MCP_MANIFEST = {
    "schema_version": "2024-11-05",
    "name": "zonecard-mcp",
    "description": "ZoneCard LUT routing — context-free MCP for geometry-addressed models",
    "tools": [
        {
            "name": "get_zone_card",
            "description": "Fetch cached ZoneCard metadata for a zone/shape/model coordinate.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "zone": {"type": "integer"},
                    "shape": {"type": "string"},
                    "model_key": {"type": "string"},
                },
                "required": ["zone", "shape", "model_key"],
            },
        },
        {
            "name": "resolve_route",
            "description": "Resolve route decision from ZoneCard fields via rule cache.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "card_type": {"type": "integer", "description": "0=sparse 1=batch 2=lz"},
                    "entropy": {"type": "integer", "minimum": 0, "maximum": 255},
                    "locality": {"type": "integer", "minimum": 0, "maximum": 255},
                    "stability": {"type": "integer", "minimum": 0, "maximum": 255},
                    "hash_val": {"type": "integer", "default": 0},
                },
                "required": ["card_type", "entropy", "locality", "stability"],
            },
        },
        {
            "name": "get_fusion_peer",
            "description": "Find best peer model for cross-model weight sharing.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "zone": {"type": "integer"},
                    "shape": {"type": "string"},
                    "model_key": {"type": "string"},
                    "threshold": {"type": "number", "default": 0.75},
                },
                "required": ["zone", "shape", "model_key"],
            },
        },
        {
            "name": "store_decision",
            "description": "Cache a routing decision (LLM or planner result) for future lookup.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "hash_val": {"type": "integer"},
                    "decision": {"type": "string"},
                    "action": {"type": "string"},
                    "reason": {"type": "string", "default": ""},
                    "zone": {"type": "integer", "default": -1},
                    "shape": {"type": "string", "default": ""},
                    "model_key": {"type": "string", "default": ""},
                    "card": {"type": "object", "default": {}},
                },
                "required": ["hash_val", "decision", "action"],
            },
        },
        {
            "name": "store_zone_card",
            "description": "Store/update ZoneCard metadata for a coordinate.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "zone": {"type": "integer"},
                    "shape": {"type": "string"},
                    "model_key": {"type": "string"},
                    "card_type": {"type": "integer"},
                    "entropy": {"type": "integer"},
                    "locality": {"type": "integer"},
                    "stability": {"type": "integer"},
                    "pattern": {"type": "integer", "default": 0},
                    "hash_val": {"type": "integer", "default": 0},
                },
                "required": ["zone", "shape", "model_key",
                             "card_type", "entropy", "locality", "stability"],
            },
        },
    ],
}


# ── SSE endpoint (MCP handshake) ──

@app.get("/sse")
async def sse_endpoint(request: Request):
    """MCP SSE stream — sends manifest then keeps alive."""
    async def event_stream():
        # Send manifest as first event
        yield f"event: endpoint\ndata: /messages\n\n"
        yield f"event: manifest\ndata: {json.dumps(MCP_MANIFEST)}\n\n"
        # Keepalive
        while True:
            if await request.is_disconnected():
                break
            yield f": keepalive\n\n"
            await asyncio.sleep(15)

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ── Tool: get_zone_card ──

class GetZoneCardRequest(BaseModel):
    zone: int
    shape: str
    model_key: str

@app.post("/tools/get_zone_card")
async def get_zone_card(req: GetZoneCardRequest):
    key = f"{req.zone}:{req.shape}:{req.model_key}"
    with _lock:
        card = zone_cards.get(key)
    if card is None:
        return JSONResponse({"found": False, "key": key})
    return JSONResponse({"found": True, "key": key, "card": card})


# ── Tool: resolve_route ──

class ResolveRouteRequest(BaseModel):
    card_type: int
    entropy: int
    locality: int
    stability: int
    hash_val: int = 0

@app.post("/tools/resolve_route")
async def resolve_route(req: ResolveRouteRequest):
    result = _resolve_single(
        req.card_type, req.entropy,
        req.locality, req.stability,
        req.hash_val,
    )
    return JSONResponse(result)


# ── Tool: get_fusion_peer ──

class GetFusionPeerRequest(BaseModel):
    zone: int
    shape: str
    model_key: str
    threshold: float = 0.75

@app.post("/tools/get_fusion_peer")
async def get_fusion_peer(req: GetFusionPeerRequest):
    fk = f"{req.zone}:{req.shape}"
    with _lock:
        entries = fusion_table.get(fk, {})

    best_key = None
    best_sim = 0.0
    best_entry = None
    for owner_key, entry in entries.items():
        if owner_key == req.model_key:
            continue
        sim = entry.get("similarity", 0.0)
        if sim > best_sim and sim >= req.threshold:
            best_sim = sim
            best_key = owner_key
            best_entry = entry

    if best_key is None:
        return JSONResponse({"found": False, "zone": req.zone, "shape": req.shape})

    return JSONResponse({
        "found": True,
        "peer_key": best_key,
        "similarity": best_sim,
        "route_decision": best_entry.get("route_decision", ""),
        "route_action": best_entry.get("route_action", ""),
    })


# ── Tool: store_decision ──

class StoreDecisionRequest(BaseModel):
    hash_val: int
    decision: str
    action: str
    reason: str = ""
    zone: int = -1
    shape: str = ""
    model_key: str = ""
    card: dict = {}

@app.post("/tools/store_decision")
async def store_decision(req: StoreDecisionRequest):
    entry = {"decision": req.decision, "action": req.action, "reason": req.reason}
    with _lock:
        exact_cache[str(req.hash_val)] = entry

        # Also update fusion table if zone/shape/model_key provided
        if req.zone >= 0 and req.shape and req.model_key:
            fk = f"{req.zone}:{req.shape}"
            if fk not in fusion_table:
                fusion_table[fk] = {}
            if req.model_key not in fusion_table[fk]:
                fusion_table[fk][req.model_key] = {}
            fusion_table[fk][req.model_key]["route_decision"] = req.decision
            fusion_table[fk][req.model_key]["route_action"] = req.action

    _save_state()
    return JSONResponse({"stored": True, "hash_val": req.hash_val})


# ── Tool: store_zone_card ──

class StoreZoneCardRequest(BaseModel):
    zone: int
    shape: str
    model_key: str
    card_type: int
    entropy: int
    locality: int
    stability: int
    pattern: int = 0
    hash_val: int = 0

@app.post("/tools/store_zone_card")
async def store_zone_card(req: StoreZoneCardRequest):
    key = f"{req.zone}:{req.shape}:{req.model_key}"
    card = {
        "zone": req.zone,
        "shape": req.shape,
        "model_key": req.model_key,
        "card_type": req.card_type,
        "entropy": req.entropy,
        "locality": req.locality,
        "stability": req.stability,
        "pattern": req.pattern,
        "hash_val": req.hash_val,
        "updated_at": int(time.time()),
    }
    with _lock:
        zone_cards[key] = card

        # Update fusion table similarity vs all peers at same zone/shape
        fk = f"{req.zone}:{req.shape}"
        if fk not in fusion_table:
            fusion_table[fk] = {}

        for peer_key, peer_card_key in [
            (k.split(":")[2], k)
            for k in zone_cards
            if k.startswith(f"{req.zone}:{req.shape}:") and not k.endswith(f":{req.model_key}")
        ]:
            peer_card = zone_cards.get(peer_card_key)
            if peer_card:
                sim = _card_similarity(card, peer_card)
                if sim >= 0.75:
                    # Store for model_key
                    if req.model_key not in fusion_table[fk]:
                        fusion_table[fk][req.model_key] = {}
                    fusion_table[fk][req.model_key]["similarity"] = sim
                    fusion_table[fk][req.model_key]["peer_key"] = peer_key
                    # Store for peer
                    if peer_key not in fusion_table[fk]:
                        fusion_table[fk][peer_key] = {}
                    fusion_table[fk][peer_key]["similarity"] = sim
                    fusion_table[fk][peer_key]["peer_key"] = req.model_key

    _save_state()
    return JSONResponse({"stored": True, "key": key})


# ── Stats ──

@app.get("/tools/cache_stats")
async def cache_stats():
    total = _hits + _misses
    with _lock:
        return JSONResponse({
            "hits": _hits,
            "misses": _misses,
            "hit_rate": round(_hits / max(total, 1) * 100, 1),
            "exact_cache_size": len(exact_cache),
            "fusion_table_zones": len(fusion_table),
            "zone_cards_stored": len(zone_cards),
        })


# ── Admin reset ──

@app.post("/admin/reset")
async def admin_reset():
    global exact_cache, fusion_table, zone_cards, _hits, _misses
    with _lock:
        exact_cache.clear()
        fusion_table.clear()
        zone_cards.clear()
        _hits = 0
        _misses = 0
    _save_state()
    return JSONResponse({"reset": True})


# ── MCP message handler (POST /messages) ──

@app.post("/messages")
async def mcp_messages(request: Request):
    """Generic MCP message dispatcher."""
    body = await request.json()
    tool = body.get("tool") or body.get("name")
    params = body.get("input") or body.get("params") or {}

    if tool == "get_zone_card":
        r = GetZoneCardRequest(**params)
        return await get_zone_card(r)
    elif tool == "resolve_route":
        r = ResolveRouteRequest(**params)
        return await resolve_route(r)
    elif tool == "get_fusion_peer":
        r = GetFusionPeerRequest(**params)
        return await get_fusion_peer(r)
    elif tool == "store_decision":
        r = StoreDecisionRequest(**params)
        return await store_decision(r)
    elif tool == "store_zone_card":
        r = StoreZoneCardRequest(**params)
        return await store_zone_card(r)
    else:
        return JSONResponse({"error": f"unknown tool: {tool}"}, status_code=400)


# ── Run ──

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("MCP_PORT", 8765))
    print(f"[MCP] ZoneCard server starting on port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port)
