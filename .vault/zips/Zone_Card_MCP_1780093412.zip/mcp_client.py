"""
mcp_client.py — ZoneCard MCP Client helper
==========================================
Drop-in adapter: existing code calls this instead of route_cache/fusion directly.
Automatically falls back to local resolve if server unreachable.

Usage:
    from mcp_client import MCPClient
    
    mcp = MCPClient("http://localhost:8765")
    
    # Store a card (call after engine produces ZoneCard)
    mcp.store_zone_card(zone=0, shape="I", model_key="qwen25coder",
                        card_type=2, entropy=234, locality=128, stability=0, pattern=0x410c)
    
    # Resolve route (replaces cache.resolve(card))
    route = mcp.resolve_route(card_type=2, entropy=234, locality=128, stability=0)
    
    # Cross-model fusion peer
    peer = mcp.get_fusion_peer(zone=0, shape="I", model_key="qwen25coder")
"""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from typing import Optional


class MCPClient:
    def __init__(self, base_url: str = "http://localhost:8765",
                 timeout: float = 2.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._online = True

    def _post(self, path: str, payload: dict) -> Optional[dict]:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            url, data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                self._online = True
                return json.loads(resp.read())
        except Exception:
            self._online = False
            return None

    def _get(self, path: str) -> Optional[dict]:
        url = f"{self.base_url}{path}"
        try:
            with urllib.request.urlopen(url, timeout=self.timeout) as resp:
                self._online = True
                return json.loads(resp.read())
        except Exception:
            self._online = False
            return None

    # ── Tools ──

    def store_zone_card(self, zone: int, shape: str, model_key: str,
                        card_type: int, entropy: int, locality: int,
                        stability: int, pattern: int = 0,
                        hash_val: int = 0) -> bool:
        result = self._post("/tools/store_zone_card", {
            "zone": zone, "shape": shape, "model_key": model_key,
            "card_type": card_type, "entropy": entropy,
            "locality": locality, "stability": stability,
            "pattern": pattern, "hash_val": hash_val,
        })
        return bool(result and result.get("stored"))

    def get_zone_card(self, zone: int, shape: str,
                      model_key: str) -> Optional[dict]:
        result = self._post("/tools/get_zone_card", {
            "zone": zone, "shape": shape, "model_key": model_key,
        })
        if result and result.get("found"):
            return result["card"]
        return None

    def resolve_route(self, card_type: int, entropy: int,
                      locality: int, stability: int,
                      hash_val: int = 0) -> dict:
        result = self._post("/tools/resolve_route", {
            "card_type": card_type, "entropy": entropy,
            "locality": locality, "stability": stability,
            "hash_val": hash_val,
        })
        if result:
            return result
        # Offline fallback
        return {"decision": "fallback", "action": "full_read",
                "cache": "offline", "reason": "MCP server unreachable"}

    def get_fusion_peer(self, zone: int, shape: str,
                        model_key: str,
                        threshold: float = 0.75) -> Optional[dict]:
        result = self._post("/tools/get_fusion_peer", {
            "zone": zone, "shape": shape,
            "model_key": model_key, "threshold": threshold,
        })
        if result and result.get("found"):
            return result
        return None

    def store_decision(self, hash_val: int, decision: str, action: str,
                       reason: str = "", zone: int = -1,
                       shape: str = "", model_key: str = "") -> bool:
        result = self._post("/tools/store_decision", {
            "hash_val": hash_val, "decision": decision,
            "action": action, "reason": reason,
            "zone": zone, "shape": shape, "model_key": model_key,
        })
        return bool(result and result.get("stored"))

    def stats(self) -> dict:
        return self._get("/tools/cache_stats") or {}

    @property
    def online(self) -> bool:
        return self._online


# ── Convenience: patch GeometryModelPool to use MCP ──

def patch_pool(pool, mcp: MCPClient):
    """
    Monkey-patch an existing GeometryModelPool to mirror
    plan_and_resolve decisions to MCP server.
    
    Usage:
        pool = GeometryModelPool()
        mcp  = MCPClient()
        patch_pool(pool, mcp)
        # All subsequent plan_and_resolve calls auto-sync to MCP
    """
    _orig = pool.plan_and_resolve

    def _patched(coord):
        result = _orig(coord)
        card = result.get("card") or {}
        route = result.get("route") or {}

        # Mirror card to MCP
        if card and mcp.online:
            mcp.store_zone_card(
                zone=coord.zone,
                shape=coord.shape,
                model_key=pool.resolve_coord(coord),
                card_type=card.get("card_type", -1),
                entropy=card.get("entropy", 128),
                locality=card.get("locality", 128),
                stability=card.get("stability", 128),
                pattern=card.get("pattern", 0),
                hash_val=card.get("hash_val", 0),
            )

        # Mirror decision to MCP if it came from LLM/planner
        hv = card.get("hash_val", 0)
        if hv and route.get("cache") in ("miss", "fusion") and mcp.online:
            mcp.store_decision(
                hash_val=hv,
                decision=route.get("decision", "fallback"),
                action=route.get("action", "full_read"),
                reason=route.get("reason", ""),
                zone=coord.zone,
                shape=coord.shape,
                model_key=pool.resolve_coord(coord),
            )

        return result

    pool.plan_and_resolve = _patched
    return pool
