#ifndef GEO_RADIAL_CAPTURE_H
#define GEO_RADIAL_CAPTURE_H

#include <stdint.h>

#define N_ANGLES 30   // ปรับตามจำนวน slot ใน angular array จริง

typedef struct {
    int32_t dx;
    int32_t dy;
} offset_t;

typedef struct {
    int32_t x;
    int32_t y;
} point_t;

// เก็บ offset แบบ integer ล้วน precompute ตอน init ครั้งเดียว (ไม่มี float ใน runtime)
static offset_t geo_table[N_ANGLES];

#define ORIGIN_KEY 0xA5A5A5A5A5A5A5A5ULL  // ค่าคงที่ตายตัว ห้ามเปลี่ยนตาม seed

// node = seed + offset (การ "กางครอบ" geometry รอบจุด trigger)
static inline point_t geo_translate(point_t seed, int slot) {
    point_t p;
    p.x = seed.x + geo_table[slot].dx;
    p.y = seed.y + geo_table[slot].dy;
    return p;
}

// address = XOR กับ origin key คงที่ -> reproducible: seed เดิม -> address เดิมทุกครั้ง
static inline uint64_t geo_address(point_t p, uint64_t origin_key) {
    uint64_t packed = ((uint64_t)(uint32_t)p.x << 32) | (uint32_t)p.y;
    return packed ^ origin_key;
}

// capture ทั้ง N_ANGLES slot รอบ seed point เดียว
static inline void geo_capture(point_t seed, uint64_t *out_addrs) {
    for (int i = 0; i < N_ANGLES; i++) {
        point_t node = geo_translate(seed, i);
        out_addrs[i] = geo_address(node, ORIGIN_KEY);
    }
}

// เรียกครั้งเดียวตอน init เพื่อ fill geo_table จาก integer angle set
// (ตัวอย่าง: seed มุมจาก array {12,42,42,60,60,54,36,54,...} scaled เป็น int radius)
static inline void geo_table_init(const int32_t *dx_vals, const int32_t *dy_vals, int count) {
    int n = count < N_ANGLES ? count : N_ANGLES;
    for (int i = 0; i < n; i++) {
        geo_table[i].dx = dx_vals[i];
        geo_table[i].dy = dy_vals[i];
    }
}

#endif // GEO_RADIAL_CAPTURE_H
