#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <stdlib.h>
#include "geo_radial_capture.h"

#define ITERS 10000000

static inline uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

int main(void) {
    // init table ด้วยค่า offset ตัวอย่าง (แทนด้วย dummy integer values)
    int32_t dx_vals[N_ANGLES], dy_vals[N_ANGLES];
    for (int i = 0; i < N_ANGLES; i++) {
        dx_vals[i] = (i * 7) % 101 - 50;
        dy_vals[i] = (i * 13) % 97 - 48;
    }
    geo_table_init(dx_vals, dy_vals, N_ANGLES);

    uint64_t addrs[N_ANGLES];
    point_t seed = {100, 200};

    volatile uint64_t sink = 0;
    uint32_t rng = 0x12345678u;

    uint64_t t0 = now_ns();
    for (int it = 0; it < ITERS; it++) {
        // xorshift เพื่อทำ seed unpredictable ป้องกัน compiler const-fold/vectorize ข้าม call
        rng ^= rng << 13;
        rng ^= rng >> 17;
        rng ^= rng << 5;
        seed.x = (int32_t)(rng & 0xFFFF);
        seed.y = (int32_t)((rng >> 16) & 0xFFFF);

        geo_capture(seed, addrs);

        // บังคับอ่านทุก node ไม่ใช่แค่ 1 ตัว กัน dead-code elimination ของ loop ภายใน
        for (int k = 0; k < N_ANGLES; k++) sink ^= addrs[k];
    }
    uint64_t t1 = now_ns();

    double total_ns = (double)(t1 - t0);
    double ns_per_call = total_ns / ITERS;          // ต่อ 1 ครั้ง geo_capture (30 nodes)
    double ns_per_node = ns_per_call / N_ANGLES;     // ต่อ node เดียว (เทียบ apples-to-apples กับ tw_capture_int.h)

    printf("Total: %.2f ms for %d calls\n", total_ns / 1e6, ITERS);
    printf("geo_capture(): %.3f ns/call (%d nodes each)\n", ns_per_call, N_ANGLES);
    printf("Per-node cost: %.3f ns/op\n", ns_per_node);
    printf("sink=%llu (anti-optimize)\n", (unsigned long long)sink);

    printf("\n--- Comparison ---\n");
    printf("Old system (tw_capture_int.h): 180 ns/op\n");
    printf("New system (geo_radial_capture): %.3f ns/op\n", ns_per_node);
    if (ns_per_node > 0)
        printf("Speedup: %.2fx\n", 180.0 / ns_per_node);

    return 0;
}
